<?php
require"mailer/class.phpmailer.php";
class mail{


function Sendmail($email,$name){


$mail = new PHPMailer(true);
 
//Send mail using gmail
// if($send_using_gmail){
    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->SMTPAuth = true; // enable SMTP authentication
    $mail->Host = "smtp.gmail.com"; // sets GMAIL as the SMTP server
    $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;  
    $mail->Username = "respinho2014@gmail.com"; // GMAIL username
    $mail->Password = "bottom123456"; // GMAIL password
// }
 
//Typical mail data
$mail->AddAddress($email, $name);
$mail->SetFrom('respinho2014@gmail.com', 'ganza');
$mail->Subject = "My Subject";
$mail->Body = "Mail contents";
 $mail->isHTML(true);  // Set email format to HTML
try{
    if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
} catch(Exception $e){
    //Something went bad
    echo "Fail :(";
}
 
}
}