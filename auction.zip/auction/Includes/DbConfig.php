<?php

 defined("DB_SERVE")? NULL : DEFINE("DB_SERVE","localhost");
 defined("DB_USER")? NULL : DEFINE("DB_USER","root");
 defined("DB_PASS")? NULL : DEFINE("DB_PASS","");
 defined("DB_NAME")? NULL : DEFINE("DB_NAME","auctiondb");
 defined("CHARSET")? NULL : DEFINE("CHARSET","UTF-8");
 defined("Url")? NULL : DEFINE("Url","http://localhost/auction/");

 ?>
