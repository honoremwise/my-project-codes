<?php
require('Databases.php');
class Authenticate extends Databases{
    private $session;
    private $username;
    private $password;
    private $position;
    private $session_id;
    private $session_name;
    private $session_postion;
    private $session_date;
    private $check_user;
    private $table;
    private $query_results;
    private $encryptPass;
    private $row;
    public $ip;
    private $db;
    function Authenticate($username=null,$password=null)
    {      $this->db= new Databases();
            $this->table='users';
            $this->username = $this->db->escape($username);
            $this->password = $this->db->escape($password);
            //$this->postion = $this->escape($position);
            $this->encryptPass = md5($this->password);
            $this->session=$this->sessionSet();
            $this->ip = preg_replace('#[^0-9.]#', '', getenv('REMOTE_ADDR'));
            
    }

    function sessionSet()
    {
        return session_start();
        
    }


    function login()
    {
   
        if($this->username == null || $this->password == null)
        {
             return 'empty'; 

                    exit();
        }else if($this->verifyloggedUser() == null){
                    return 'error';
                    exit();
                }else {
                    $this->row = $this->db->fetch_all_array($this->verifyloggedUser());
                    $this->session_id   = $this->row['id'];
                    $this->session_name = $this->row['users_username'];
                    $this->session_postion = $this->row['position'];
                   
                    $this->row['lastlogindate'] = strtotime($this->row['lastlogindate']);
                    $this->session_date=date('l jS \of F Y h:i:s A',$this->row['lastlogindate']);
  

                    // CREATE THEIR SESSIONS AND COOKIES
                    $_SESSION['Auth_id'] = $this->session_id;
                    $_SESSION['Auth_name'] = $this->session_name;
                    $_SESSION['Auth_date'] = $this->session_date;
                    
                    $_SESSION['Auth_position'] = $this->session_postion;
                    setcookie("Auth_id", $this->session_id, strtotime( '+5 days' ), "/", "", "", TRUE);
                    setcookie("Auth_name", $this->session_name, strtotime( '+5 days' ), "/", "", "", TRUE);
                    setcookie("Auth_position", $this->session_postion, strtotime( '+5 days' ), "/", "", "", TRUE);
                   setcookie("Auth_date", $this->session_date, strtotime( '+5 days' ), "/", "", "", TRUE);
                  if($this->update_logon()==false){
                     return'Auth';
                  }
                  else{
                      return'Non_Auth';
                  }
                  
                }
        //}
    }

    function verifyloggedUser()
    {   
        //$this->encryptPass;
        $condition="(users_username='{$this->username}' OR users_email='{$this->username}') AND users_password='{$this->password}' LIMIT 1";
        //="(users_username='{$this->username}' OR users_email='{$this->username}' OR users_phone='{$this->username}') AND users_password='{$this->password}' LIMIT 1"
        $this->query_results= $this->db->query_display($this->table,$column_name='', $condition);
        $this->check_user   = $this->db->num_rows($this->query_results);
                if($this->check_user > 0){
                return $this->query_results;
            }else{
            return null; 
            }
    }

//     function getUsername()
//     {
//  $condition="users_id=".$_SESSION['Auth_id']." LIMIT 1";
//  $this->query_results= $this->db->query_display($this->table,$column_name='', $condition);
//  $row=$this->db->fetch_all_array($this->query_results);
//  $username=ucfirst($row['users_fname'])." ".$row['users_lname'];
//     }

   
            function update_logon()
            {
            $updateTask = array( //just an array [colum_name] => [values]
            'online' => '1',
            'lastlogindate' => 'now()'
            ); 
            $update = $this->db->updateData($this->table,$updateTask,$condition="id=".$_SESSION['Auth_id']);
            if($update==true){
                  return true;          
            }else{
                return false;
            }
            
            
            
            }

       

    function getMessage($msg='',$user="")
    {
    switch ($msg) {
		case 'Auth':
			return'<div class="alert alert-success">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                              
                            User [ '.ucfirst($user).' ] Authenticated successfully!
                             
                          </div>';
			break;
        case 'Non_Auth':
			return'<div class="alert alert-danger">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                              
                            User [ '.ucfirst($user).' ] not Authenticated. error!!
                             
                          </div>';
			break;
		case 'error':
			return'<div class="alert alert-danger">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                              
                            User [ '.ucfirst($user).' ] not logged in Incorrect credential ,try again.Thanks!
                             
                          </div>';
			break;
        case 'empty':
			return'<div class="alert alert-warning">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                             Check and enter username or password.Thanks!
                             
                          </div>';
			break;
        
		default:
			return'';
			//exit;
	};
    }
    
}