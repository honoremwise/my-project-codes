<?php
require('Databases.php');
class Auth extends Databases{
    private $session;
    private $username;
    private $password;
    private $position;
    private $sess_id=null;
    private $session_name;
    private $session_postion;
    private $session_date;
    private $check_user;
    private $table;
    private $query_results;
    private $encryptPass;
    private $row;
    public $ip;
    private $db;
    function Auth()
    {      $this->db= new Databases();
            $this->table='students';
            
            //$this->postion = $this->escape($position);
            $this->encryptPass =$this->password;
            $this->session=$this->sessionSset();
            $this->ip = preg_replace('#[^0-9.]#', '', getenv('REMOTE_ADDR'));
            
    }

    function sessionSset()
    {
        return session_start();
        
    }


    function login1($username='',$password='')
    {
            $this->username = $this->db->escape($username);
            $this->password = $this->db->escape($password);

        if($this->username == null || $this->password == null)
        {
             return 'empty'; 

                    exit();
        }else if($this->verifyloggedUser1() == null){
                    return 'error';
                    exit();
                }else {
                    $this->row = $this->db->fetch_all_array($this->verifyloggedUser1());
                    
                    // CREATE THEIR SESSIONS AND COOKIES
                    $_SESSION['stcode'] = $this->row['st_code'];
                    $this->sess_id = $_SESSION['stcode'];
//                    $x=$this->init();
//                    print "<script>alert($x);</script>";
                    setcookie("stcode", $_SESSION['stcode'], strtotime( '+5 days' ), "/", "", "", TRUE);
                   
                  if($this->update_logon1()==false){
                     return'sAuth';
                  }
                  else{
                      return'sNon_Auth';
                  }
                  
                }
        //}
    }
    function init(){
        if(isset($_SESSION['stcode'])){
            return array('auth'=>$_SESSION['stcode'],'authorize'=>true);
        }else{
            return array('auth'=>$_SESSION['stcode'],'authorize'=>false);
        }

        
    }
    function verifyloggedUser1()
    {   
        //$this->encryptPass;
        $condition="(st_code='{$this->username}' OR guadian_phone='{$this->username}') AND password='{$this->password}' LIMIT 1";
        //="(users_username='{$this->username}' OR users_email='{$this->username}' OR users_phone='{$this->username}') AND users_password='{$this->password}' LIMIT 1"
        $this->query_results= $this->db->query_display($this->table,$column_name='', $condition);
        $this->check_user   = $this->db->num_rows($this->query_results);
                if($this->check_user > 0){
                return $this->query_results;
            }else{
            return null; 
            }
    }

     function getUserInfo($uid)
     {
  $condition="st_code=".$uid." LIMIT 1";
  $this->query_results= $this->db->query_display('students',$column_name='', $condition);
  $row=$this->db->fetch_all_array($this->query_results);
  return ucfirst($row['st_full_name'])." Your guadian name:".$row['guadian_name'].'  your session has been started at:'.$row['lastlogindate'];
     }

   
            function update_logon1()
            {
            $updateTask = array( //just an array [colum_name] => [values]
            'online' => '1',
            'lastlogindate' => 'now()'
            ); 
            $id=$_SESSION['stcode'];
            $update = $this->db->updateData($this->table,$updateTask,$condition="st_code='".$id."'");
            if($update==true){
                  return true;          
            }else{
                return false;
            }
            
            
            
            }

       

    function getMessage1($msg='',$user="")
    {
    switch ($msg) {
		case 'Auth':
			return'<div class="alert alert-success">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                              
                            Student [ '.ucfirst($user).' ] Authenticated successfully!
                             
                          </div>';
			break;
        case 'Non_Auth':
			return'<div class="alert alert-danger">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                              
                            Student [ '.ucfirst($user).' ] not Authenticated. error!!
                             
                          </div>';
			break;
		case 'error':
			return'<div class="alert alert-danger">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                              
                            Student [ '.ucfirst($user).' ] not logged in Incorrect credential ,try again.Thanks!
                             
                          </div>';
			break;
        case 'empty':
			return'<div class="alert alert-warning">
                             <strong><i class="fa fa-info"> Login Message :</i></strong> 
                             Check and enter username or password.Thanks!
                             
                          </div>';
			break;
        
		default:
			return'';
			//exit;
	};
    }
    
}