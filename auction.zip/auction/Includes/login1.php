<?php
 require('Auth.php');
if(isset($_POST['onLogin1'])){

$username=  $_POST['username1'];
$password = sha1($_POST['pass1']);
$Auth1 = new Auth();
    if($Auth1->login1($username,$password)=='empty')
    {
 echo $Auth1->getMessage1('empty',$username);
    }else if($Auth1->login1($username,$password)=='error')
    {
        
echo $Auth1->getMessage1('error',$username);
?>
<script>function redirct(){window.location='studentLogin.php';}setInterval(redirct,500);</script>
    <?php }else{
       
        if($Auth1->login1($username,$password) == 'sAuth'){
        echo $Auth1->getMessage1('Auth',$username);
       ?>
        <script>function redirct(){window.location='student_home/';} function hide(){$(".login").hide();} setInterval(redirct,2000); setInterval(hide,100); </script>
        <?php
        }
        else{
        echo $Auth1->getMessage1('sNon_Auth',$username);?>
        <script>function redirct(){window.location='studentLogin.php';}setInterval(redirct,1500);</script>
        <?php }
        

    }
}
?>