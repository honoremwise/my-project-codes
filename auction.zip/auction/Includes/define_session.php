<?php
 defined("Auth_id")? NULL : DEFINE("Auth_id",$_SESSION['Auth_id']);
 defined("Auth_position")? NULL : DEFINE("Auth_position",$_SESSION['Auth_position']);
 defined("Auth_date")? NULL : DEFINE("Auth_date",$_SESSION['Auth_date']);
