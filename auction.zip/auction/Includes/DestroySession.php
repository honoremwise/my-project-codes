<?php
require('Authenticate.php');
class DestroySession extends Authenticate
{
     private $db;
     private $table;

function DestroySession()
	{
		 $this->sessionSet();
         $this->db= new Databases();
        $this->table='users';
	}

    
 function sessionDestry()
    {
        return session_destroy();
        
    }
 function logoff()
    {
        // Set Session data to an empty array
        
        $offline = $this->update_logoff();
        if($offline == true)
        {
        $this->sessionDestry();
        // Expire their cookie files
        if(isset($_COOKIE["Auth_id"]) && isset($_COOKIE["Auth_name"]) && isset($_COOKIE["Auth_position"])) {
            setcookie("Auth_id", $_COOKIE["Auth_id"], strtotime( '-5 days' ), '/');
            setcookie("Auth_name", $_COOKIE["Auth_name"], strtotime( '-5 days' ), '/');
            setcookie("Auth_position", $_COOKIE["Auth_position"], strtotime( '-5 days' ), '/');
        }
        // Destroy the session variables
       
        // Double check to see if their sessions exists
                    if(isset($_SESSION['Auth_id'])){
                    return 'set';
                    } else{
                    return 'unset';
                        exit();
                    } 
            }
        
    }

          function update_logoff()
            {
            $updateTask = array( //just an array [colum_name] => [values]
            'online' => '0',
            'lastlogindate' => 'now()'
            ); 
           $update = $this->db->updateData($this->table,$updateTask,$condition="id=".$_SESSION['Auth_id']);
            if($update == true){
                return true;
            }else{
                return false;
            }
            
            }

}