<?php
class DateTimeFormat{

public $duration;
public $value;

    function DateTimeFormat($duration)
    {
        // set the default timezone to use. Available since PHP 5.1
 date_default_timezone_set('UTC');

 $this->duration=$duration;
  $this->value=$duration;
 $this->duration = strtotime($this->duration);
    }
    

    
    function onlyDay($type=null){
                if($type=='short'){
        return date('D',$this->duration);
                }else if($type=='long'){
        return date('l',$this->duration);
            }
    }
  

   function onlyMonth($type=null){
                      if($type=='short'){
      return date('M',$this->duration);
                }else if($type=='long'){
       return date('F',$this->duration);
            }
}
   function onlyYear(){
return date('Y',$this->duration);
   
    }

// Prints something like: Wednesday 1st of February 2017 11:17:52 AM

function day_month_year_time()
    {
return date('l jS \of F Y h:i:s A',$this->duration);
    }
       // Prints something like: on Monday ,feb, 21,2016 03:12:46 PM
function Onday_month_year_at()
    {
return date('\O\n  F jS, Y \A\t H:i:s A',$this->duration);
    }
function Onday_month_year_atWith_short()
    {
return date('F jS, y \A\t H:i:s A',$this->duration);
    }


function time_sec_format(){
		// $date = substr($this->value,0,10);
		// $time = substr($this->value,11,8);
		// $h = substr($time,0,2);
		// $m = substr($time,3,2);
		// $s = substr($time,6,2);
		// $sec1 =($h*3600)+($m*60)+$s;
// 		
		// $time1= time();
// 		
		// $times =$sec1 + strtotime($date);
		
		$var = new DateTime($this->value);
		$now = new DateTime();
		$this->value = $var->format('U') - $now->format('U');
		$secMe = time()- strtotime($this->value);
		//$sec = $time1-$times;
		//$sec = $sec1+$sec2;
		return $this->age();
    }

function age(){
	$this->value =abs($this->value);
	
		if($this->value<60){
		$c_time = $this->value;
		$c_time .=" Sec";
		return $c_time;
		}
		if(($this->value>=60)&&($this->value<3600)){
		$c_time = floor($this->value/60);
		if($c_time >1)
		$c_time .=" Min ";
		else $c_time .=" Min ";
		//$sec =$this->value%60;
		//if (($sec !=0)&&($sec>1)){
		//$c_time .=$sec;
		//$c_time .=" Seconds ";
		//if ($sec ==1){
		//$c_time .=$sec;
		//$c_time .=" Second ";
		//}
		return $c_time;
		}
		
		if(($this->value>=3600)&&($this->value<86400)){
		$c_time = floor($this->value/3600);
		if($c_time >1)
		$c_time .=" Hrs ";
		else $c_time .=" Hr ";
		//$min = floor(($this->value%3600)/60);
		//if (($min !=0)&&($min>1)){
		//$c_time .=$min;
		//$c_time .=" Minutes ";
		//}
		//if ($min ==1){
		//$c_time .=$min;
		//$c_time .=" Minute ";
		//}
		return $c_time;
		}
		if(($this->value>=86400)&&($this->value<604800)){
		$c_time = floor($this->value/86400);
		if($c_time >1)
		$c_time .=" Days ";
		else $c_time .=" Day ";
		// $h = floor(($this->value%86400)/3600);
		// if (($h !=0)&&($h>1)){
		// $c_time .=$h;
		// $c_time .=" Hrs ";
		// }
		// if ($h ==1){
		// $c_time .=$h;
		// $c_time .=" Hr ";
		// }
		return $c_time;
		}
		if(($this->value>=604800)&&($this->value<2592000)){
		$c_time = floor($this->value/604800);
		if($c_time >1)
		$c_time .=" Weeks ";
		else $c_time .=" Week ";
		// $d = floor(($this->value%604800)/86400);
		// if (($d !=0)&&($d>1)){
		// $c_time .=$d;
		// $c_time .=" Days ";
		// }
		// if ($d ==1){
		// $c_time .=$d;
		// $c_time .=" Day ";
		// }
		return $c_time;
		}
		if(($this->value>=2592000)&&($this->value<31536000)){
		$c_time = floor($this->value/2592000);
		if($c_time >1)
		$c_time .=" Months ";
		else $c_time .=" Month ";
		// $w = floor(($this->value%2592000)/604800);
		// if (($w !=0)&&($w>1)){
		// $c_time .=$w;
		// $c_time .=" Weeks ";
		// }
		// if ($w ==1){
		// $c_time .=$w;
		// $c_time .=" Week ";
		// }
		return $c_time;
		}
		if($this->value>=31536000){
		$c_time = floor($this->value/31536000);
		if($c_time >1)
		$c_time .=" Years ";
		else $c_time .=" Year "; 
		$m = floor(($this->value%30240000)/2592000);
		if (($m !=0)&&($m>1)){
		$c_time .=$m;
		$c_time .=" Months ";
		}
		if ($m ==1){
		$c_time .=$m;
		$c_time .=" Month ";
		}
		return $c_time;
		}
		}
 

  
}