<?php
require('Authenticate.php');
class CheckSession extends Authenticate{

	function CheckSession()
	{
		$this->session=$this->sessionSet();
	}

			function verifySession()
			{
				
						
		if(isset($_SESSION['Auth_id']) && isset($_SESSION['Auth_name']) && isset($_SESSION['Auth_position'])) {
		$Auth_id = preg_replace('#[^0-9]#', '', $_SESSION['Auth_id']);
		$log_Auth_name = preg_replace('#[^a-z0-9\_\-]#i', '', $_SESSION['Auth_name']);
		$log_Auth_position = preg_replace('#[^a-z0-9\_\-]#i', '', $_SESSION['Auth_position']);
		$log_Auth_position = preg_replace('#[^a-z0-9\_\-]#i', '', $_SESSION['Auth_date']);
		// Verify the user
	return true; 
	
	} else if(isset($_COOKIE["Auth_id"]) && isset($_COOKIE["Auth_name"]) && isset($_COOKIE["Auth_position"])){
		$_SESSION['Auth_id'] = preg_replace('#[^0-9]#', '', $_COOKIE['Auth_id']);
		$_SESSION['Auth_name'] = preg_replace('#[^a-z0-9\_\-]#i', '', $_COOKIE['Auth_name']);
		$_SESSION['Auth_position'] = preg_replace('#[^a-z0-9\_\-]#i', '', $_COOKIE['Auth_position']);
		$_SESSION['Auth_date'] = preg_replace('#[^a-z0-9\_\-]#i', '', $_COOKIE['Auth_date']);

		$Auth_id = preg_replace('#[^0-9]#', '', $_SESSION['Auth_id']);
		$log_Auth_name = preg_replace('#[^a-z0-9\_\-]#i', '', $_SESSION['Auth_name']);
		$log_Auth_position = preg_replace('#[^a-z0-9\_\-]#i', '', $_SESSION['Auth_position']);
		$log_Auth_date = preg_replace('#[^a-z0-9\_\-]#i', '', $_SESSION['Auth_date']);
		// Verify the user
	
	return true;  
		}
			return false;  		
		}
}
