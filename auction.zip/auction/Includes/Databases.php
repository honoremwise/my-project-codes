<?php
# Name: Databases.class.php
# File Description: MySQL Class to allow easy and clean access to common mysql commands
# Author: Ganza respice
# Web: http://www.idarecords.com/
# Update: 2017-17-01
# Version: 1.1.0
# Copyright 2016 www.idarecords.com

require('DbConfig.php');
//namespace Admin;
class Databases {

#######################
//internal info
var $error = "";
var $errno = 0;

//number of rows affected by SQL query
var $affected_rows = 0;

var $connection = 0;
var $query_id = 0;
private $magic_quotes_active;
private $new_enough_php;
public $gets;
public $rows;
public $runQuery;
public $projectName;
public $projectWeb;
public $projectlogo;

#-#############################################
# desc: constructor
function Databases(){
    $this->open_connection();
    $this->magic_quotes_active = get_magic_quotes_gpc();
    $this->new_enough_php = function_exists("mysql_real_escape_string");
   
}#-#constructor()


#-#############################################
# desc: connect and select database using vars above
# Param: $new_link can force connect() to open a new link, even if mysql_connect() was called before with the same parameters
function open_connection() {
    $this->connection=mysqli_connect(DB_SERVE,DB_USER,DB_PASS,DB_NAME);

    if (!$this->connection) {//open failed
        $this->oops("Could not connect to server: <b>".DB_SERVE."</b>.");
        //exit();
        }

    if(!mysqli_select_db($this->connection,DB_NAME)) {//no database
        $this->oops("Could not open database: <b>".DB_NAME."</b>.");
    exit();    
    }

}#-#connect()


#-#############################################
# desc: close the connection
function close_connection() {
    if(!mysqli_close($this->connection)){
        $this->oops("Could not open database: <b>".$this->connection."</b>.");
    }
}#-#close()

  public function getData(){

return $this->gets;
    }

#-#############################################
# Desc: escapes characters to be mysql ready
# Param: string
# returns: string
function Input($string)
{
   return (is_numeric($string))?$_POST[$string]:$_POST[$string]; 
    
}
    function File($file){
      $f=isset($_FILES[$file]);    
        return array($f['name'],$f['tmp_name'],$f['size']);
    }
    function isFile(){
       return isset($_FILES[$file]); 
    }
    function Save($string){
   return isset($_POST[$string]); 
    
}
   function Request($string){
     return (is_numeric($string))?$_GET[$string]:$_GET[$string]; 
   }
    

function escape($string) {
if($this->new_enough_php){
// undo any magic quotes effect so mysql_real_escape_string can do the work
if($this->magic_quotes_active)
{
    $string = stripslashes($string);
}
$string = mysqli_real_escape_string($this->connection,$string);
 $string = trim($string);
 //$string = strip_tags($string);//function strips a string from HTML, XML, and PHP tags.
//$string = htmlspecialchars ($string);
    
}else{// before php v4.3.0
if(! $this->magic_quotes_active){$string = addslashes($string);}
}
return $string;
}

public function escape_value($value){

if($this->new_enough_php){
// undo any magic quotes effect so mysql_real_escape_string can do the work
if($this->magic_quotes_active)
{$value = stripslashes($value);}
    
$value =mysqli_real_escape_string($this->connection,trim($value));}
else{// before php v4.3.0
if(! $this->magic_quotes_active){$value = addslashes($value);}
}
return $value;
}

public function html_entities($string){
    $flags       =null;
   $flags        =$flags?$flags:(ENT_QUOTES);
   $encode_decode=true;
   $charset      =CHARSET;
    return  htmlspecialchars($string, $flags, $charset ,$encode_decode);
}
    public function html_entity_decodes($string){
       $flags         =null;
       $flags         =$flags?$flags:(ENT_QUOTES);
       $encode_decode =true;
       $charset       =CHARSET;
       return htmlspecialchars_decode($string);
    }
    
function removeFile($dir=array()){
    $count=count($dir);
           for ($i=0;$i<$count;$i++){
         if(file_exists($dir[$i])){
          return unlink($dir[$i],true);  
        }else{
       return false;
       }  
   }
}
  


#-#############################################
# Desc: executes SQL query to an open connection
# Param: (MySQL query) to execute
# returns: (query_id) for fetching results etc
function query($sql) {
    // do query
    $this->query_id = mysqli_query($this->connection,$sql);

    if (!$this->query_id) {
        $this->oops("<b>MySQL Query fail:</b> $sql");
        return 0;
    }
    
    $this->affected_rows = $this->affected_rows($this->connection);

    return $this->query_id;
}#-#query()


public function num_rows($result){
return mysqli_num_rows($result);
}


public function insert_id(){
return mysqli_insert_id($this->connection);
}



public function affected_rows(){
return mysqli_affected_rows($this->connection);
}

#-#############################################
# desc: fetches and returns results one line at a time
# param: query_id for mysql run. if none specified, last used
# return: (array) fetched record(s)

function fetch_array($query_id) {
    // retrieve row
   // if ($query_id!=-1) {
        $this->query_id=$query_id;
    //}

    if (isset($this->query_id)) {
        $record = mysqli_fetch_array($this->query_id);
    }else{
        $this->oops("Invalid query_id: <b>$this->query_id</b>. Records could not be fetched.");
    }

    return $record;
}
#-#fetch_array()


#-#############################################
# desc: returns all the results (not one row)
# param: (MySQL query) the query to run on server
# returns: assoc array of ALL fetched results

function fetch_all_array($sql) {
   
    
    $f= $this->fetch_array($sql);
  return $f;
    //$this->free_result($query_id);
    
}#-#fetch_all_array()


#-#############################################
# desc: frees the resultset
# param: query_id for mysql run. if none specified, last used
    
function free_result($query_id=-1) {
    if ($query_id!=-1) {
        $this->query_id=$query_id;
    }
    if($this->query_id!=0 && !mysqli_free_result($this->query_id)) {
        $this->oops("Result ID: <b>$this->query_id</b> could not be freed.");
    }
}#-#free_result()


#-#############################################
# desc: does a query, fetches the first row only, frees resultset
# param: (MySQL query) the query to run on server
# returns: array of fetched results
function query_first($query_string) {
    $query_id = $this->query($query_string);
    $out = $this->fetch_array($query_id);
    $this->free_result($query_id);
    return $out;
}#-#query_first()


#-#############################################
# desc: does an update query with an array
# param: table (no prefix), assoc array with data (doesn't need escaped), where condition
# returns: (query_id) for fetching results etc
    
    public function query_display($table,$column_name = '', $condition = ''){
        
        
        // $this->open_connection();
       // $condition       = filter_var($this->escape($condition),FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
        $tableName       = $this->escape($table);
       // $column_name     =filter_var($this->escape($column_name),FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
        
        if(!empty($tableName) && empty($column_name) && !empty($condition)){
            $sql_query ="SELECT * FROM $tableName WHERE {$condition}";
           
             $result=$this->query($sql_query);
            
            return $result; 
            
        }else if(!empty($tableName) && !empty($column_name) && empty($condition)){
            $sql_query = "SELECT $column_name FROM $tableName";
            
             $result=$this->query($sql_query);
            
            return $result;  
            
        }else if(!empty($tableName) && !empty($column_name) && !empty($condition)){
            $sql_query = "SELECT $column_name FROM $tableName WHERE {$condition}";
           
             $result=$this->query($sql_query);
            
            return $result;  
            
        }else{
            $sql_query = "SELECT * FROM $tableName ";
           
            $result=$this->query($sql_query);
            
            return $result; 
                
        }
        //$this->close_connection();
    }

function updateData($table, $data, $condtion=''){
    $v='';
    $q="UPDATE $table SET ";

    foreach($data as $key=>$val) {
        if(strtolower($val)=='null')
            $v.="$key = NULL, ";
        elseif(strtolower($val)=='now()')
         $v.="$key = NOW(), ";
        else  $v.= "$key='".$this->html_entities($val)."', ";
    }

    $q.="". rtrim($v, ', ') . " WHERE $condtion";
   
   if($qry=$this->query($q)){
       $affected=$this->affected_rows();
        if($affected==1)
                return true;
                else
                return false;
    }
    return false;
}#-#query_update()


#-#############################################
# desc: does an insert query with an array
# param: table (no prefix), assoc array with data
# returns: id of inserted record, false if error
//    function includes($path=array()){
//        //return 'hello';
//       foreach($path as $key => $value) { 
//        $tmp_path[]= $value;
//       }
//     $Path_joined = join('/', $tmp_path).'.php'; 
//       // if(file_exists($Path_joined.'.php')){
//            include($Path_joined); 
////        }else{
////             echo $Path_joined; 
////        }
//      
//        
//    }
    
    function addData($table, $data_array) { 
        foreach ($data_array as $key => $value) { 
         $tmp_col[] = $key;
        
         if(strtolower($value)=='null') $tmp_dat[] ="NULL";
        elseif(strtolower($value)=='now()') $tmp_dat[]="NOW()";
        else $tmp_dat[] = "'".$this->html_entities($value)."'"; // <-- escape against SQL injections
    } 
    $columns = join(',', $tmp_col); 
    $data    = join(',', $tmp_dat);

    // Create and execute SQL command 
$sql = 'INSERT INTO '.$table.'('.$columns.')VALUES('. $data.')'; 
  
if($this->query($sql)){
        //$this->free_result();
        if($this->insert_id())
            return true;
    }
    else return false; 
}

 public function deleteData($table,$condition=null){
 
        if(is_null($condition))
        {
        $sql_query = "DELETE FROM $table";
      
        }else{
        $sql_query = "DELETE FROM $table WHERE $condition";
       
        }

        if($this->query($sql_query)){
       $affected=$this->affected_rows();
        if($affected==1)
                return true;
                else
                return false;
    }
    return false;

    }
   
  function maxid($table,$id){
            $max=$this->query_display($table,$id, $cond=$id."!=0 ORDER BY ".$id." DESC LIMIT 1");
            $nums=$this->num_rows($max);
            $row=$this->fetch_all_array($max);
             if($row > 0){
                 $ids=$row[$id]+1;
                return $ids;
             }else{
                return 1;
             }
           

            }

     function generateID($table){
            $max=$this->query_display($table,$column_name = 'id, MAX(id) as maxid', $cond='');
            $nums=$this->num_rows($max);
            $row=$this->fetch_all_array($max);

            if($row['maxid']==0)
            {
            $day=date("d");$month=date("m"); $year=date("y"); $id=1;
            return $day.$month.$year.$id;
            }
            else
            {
                $day=date("d");$month=date("m"); $year=date("y");
                $ids=$row['maxid']+1;
                return $day.$month.$year.$ids;

            }
      // }
    }
      function maxrecords($table){
            $max=$this->query_display($table,$column_name = 'refers_id', $cond='refers_id!=0 ORDER BY id DESC LIMIT 1');
            $nums=$this->num_rows($max);
            $row=$this->fetch_all_array($max);
             if($row > 0){
                 $ids=$row['refers_id'];
                return $ids;
             }
           

            }
     
    
    function project(){
         $r=$this->query_display("project",$column_name = '', $cond='');
            $nums=$this->num_rows($r);
        if($nums > 0){
             $row=$this->fetch_all_array($r); 
            return array($this->html_entity_decodes($row['project_name']),$this->html_entity_decodes($row['website']),$this->html_entity_decodes($row['full_contact']),$this->html_entity_decodes($row['full_address']),$this->html_entity_decodes($row['full_location']),$this->html_entity_decodes($row['logo']),$this->html_entity_decodes($row['dates']));
        }
           
    }
    
     function count_cmts($id){
         $r=$this->query_display("comments",$column_name = '', $cond='comment_post'.$id);
            $nums=$this->num_rows($r);
        
             return $nums;
        }
    
    function getUsername($user_id)
    {
 $condition="id=".$user_id." LIMIT 1";
 $this->runQuery= $this->query_display('users',$column_name='', $condition);
 $row=$this->fetch_all_array($this->runQuery);
 $username=ucfirst($this->html_entity_decodes($row['users_fname']))." ".$this->html_entity_decodes($row['users_lname']);
 return $username;
    }

#-#############################################
# desc: throw an error message
# param: [optional] any custom error to display
function oops($msg='') {
    if($this->connection>0){
        $this->error=mysqli_error($this->connection);
        $this->errno=mysqli_errno($this->connection);
    }
    else{
        $this->error=mysqli_error();
        $this->errno=mysqli_errno();
    }
    ?>
        <table align="center" border="1" cellspacing="0" style="background:white;color:black;width:80%;">
        <tr><th colspan=2>Database Error</th></tr>
        <tr><td align="right" valign="top">Message:</td><td><?php echo $msg; ?></td></tr>
        <?php if(strlen($this->error)>0) echo '<tr><td align="right" valign="top" nowrap>MySQL Error:</td><td>'.$this->error.'</td></tr>'; ?>
        <tr><td align="right">Date:</td><td><?php echo date("l, F j, Y a\t g:i:s A"); ?></td></tr>
        <tr><td align="right">Script:</td><td><a href="<?php echo @$_SERVER['REQUEST_URI']; ?>"><?php echo @$_SERVER['REQUEST_URI']; ?></a></td></tr>
        <?php if(strlen(@$_SERVER['HTTP_REFERER'])>0) echo '<tr><td align="right">Referer:</td><td><a href="'.@$_SERVER['HTTP_REFERER'].'">'.@$_SERVER['HTTP_REFERER'].'</a></td></tr>'; ?>
        </table>
    <?php
}#-#oops()
    
    
    function messges($msg='',$info='',$action='')
    {
        switch ($msg) {
		case 'success':
			return'<div class="alert alert-success">
                             <strong><i class="fa fa-info"> Successfuly Message :</i></strong> 
                              <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">OK</button>
                             This '.$info.' has '.$action.' successfuly.Thanks!
                             
                          </div>';
			break;
		case 'error':
			return'<div class="alert alert-danger">
                             <strong><i class="fa fa-info"> error Message :</i></strong> 
                              <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>
                             This '.$info.' has not '.$action.' in database ,try again.Thanks!
                             
                          </div>';
			break;
        case 'exist':
			return'<div class="alert alert-warning">
                             <strong><i class="fa fa-info"> extisting Message :</i></strong> 
                             <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>
                             This '.$info.' is already exist in database ,not saved.Thanks!
                             
                          </div>';
			break;
        
		default:
			return'';
			//exit;
	};
    
    }


}//CLASS Database
###################################################################################################

?>