<?php
require('DestroySession.php');
$logout = new DestroySession();

if(isset($_POST['Onlogout'])){

    if($logout->logoff()=='unset'){
 ?>
        <script>function redirct(){window.location='../'; }  setInterval(redirct,5000); </script>
        <?php
        print('<div class="alert alert-info">
                             <strong><i class="fa fa-info"> Login Message:</i></strong> 
                              
                        <center><img src="../img/book.gif"> <h3> Wait! Logout proccessing.....</h3></center>
                             
                          </div>');
    }else{
       ?>
        <script>function redirct(){window.location='./'; }  setInterval(redirct,5000); </script>
        <?php  
         print('<div class="alert alert-info">
                             <strong><i class="fa fa-info"> Login Message:</i></strong> 
                              
                            <center><img src="../img/book.gif"> <h3> Wait! Logout proccessing.....</h3></center>
                             
                          </div>');
    }

}
?>