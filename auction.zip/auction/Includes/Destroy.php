<?php
require('Auth.php');
class Destroy extends Auth
{
     private $db;
     private $table;

function Destroy()
	{
		 $this->sessionSset();
         $this->db= new Databases();
        $this->table='students';
	}

    
 function sessDestry()
    {
        return session_destroy();
        
    }
 function logoff()
    {
        // Set Session data to an empty array
        
        $offline = $this->update_logoff();
        if($offline == true)
        {
            $this->sessDestry();
        // Expire their cookie files
        if(isset($_COOKIE["stcode"])) {
            setcookie("stcode", $_COOKIE["stcode"], strtotime( '-5 days' ), '/');
        }
        // Destroy the session variables
        
        // Double check to see if their sessions exists
                    if(isset($_SESSION['stcode'])){
                    return 'set';
                    } else{
                    return 'unset';
                        exit();
                    } 
            }
        
    }

          function update_logoff()
            {
            $updateTask = array( //just an array [colum_name] => [values]
            'online' => '0',
            'lastlogindate' => 'now()'
            ); 
           $update = $this->db->updateData($this->table,$updateTask,$condition="st_code=".$_SESSION['stcode']."");
            if($update == true){
                return true;
            }else{
                return false;
            }
            
            }

}