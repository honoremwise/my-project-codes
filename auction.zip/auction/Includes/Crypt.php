<?php

class Crypt {

    //private $secretkey = 'this is a string used as a key';
 private $secretkey;

    //Encrypts a string

    function __construct()
    {
$this->secretkey ="ganza respice";

    }
    public function encrypt($text) {
        $data = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $this->secretkey, $text, MCRYPT_MODE_ECB, "keeeeeeeeee");
        return base64_encode($data);
    }

    //Decrypts a string
    public function decrypt($text) {
        $text = base64_decode($text);
        return mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $this->secretkey, $text, MCRYPT_MODE_ECB, "keeeeeeeeee");
    }

}