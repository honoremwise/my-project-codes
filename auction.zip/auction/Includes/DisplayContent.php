<?php 
//require('Databases.php');
require('DateTimeFormat.php');
require('pagination.php');

class DisplayContent{
public $runQuery;
public $nums;
public $rows;
private $db;
public $Postdir;
    function DisplayContent(){
        $this->db= new Databases;
    }

    

//        function previewContent($table,$id){
//        $this->runQuery=$this->db->query_display($table,$column_name = '', $condition="refers_id=".$id);
//        $this->nums=$this->db->num_rows($this->runQuery);
//   
//  
//        if($this->nums> 0){ 
//            $this->rows=$this->db->fetch_all_array($this->runQuery);
//            
//            $title      =$this->db->html_entity_decodes($this->rows['title']);
//            $summary    =$this->db->html_entity_decodes($this->rows['summary']);
//            $body       =$this->db->html_entity_decodes($this->rows['body']);
//            $photo      =$this->db->html_entity_decodes($this->rows['photo']);
//        
//            
//            
//            $refers_id  =$this->db->html_entity_decodes($this->rows['refers_id']);
//            $format     =$this->db->html_entity_decodes($this->rows['format']);
//            $duration   =$this->rows['updated_at'];
//            $category  =$this->db->html_entity_decodes($this->rows['category']);
//            $pathPost   ='../upload/img_posts/thumb449x330/'.$photo;
//           $formatDate= new DateTimeFormat($duration);
//            
//                    if($format=='0'){
//            echo '
//        <div class="row">
//        <h3>'.$title.'</h3>
//         <br /><div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
//         <img src="'.$pathPost.'" id="previewing" alt=" Photo        480x260" style=" font-size: 30px;
//        text-align: center; width: 96%;
//        height: 45%;  text-align: center;line-height: 180px; left: 0px; font-weight: bold;
//        color: #C0C0C0; background-color: #FFFFFF;overflow: auto; border:solid;">
//        <h5><i class="fa fa-user"></i>'.$this->getUsername($this->rows['users_id']).', <i class="fa fa-clock"></i> '.$formatDate->Onday_month_year_at().', <i class="fa fa-tag"></i> '.$category.'</h5>
//                    </div>
//
//             <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
//            '.$summary.'
//            </div>
//            
//             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:4%">
//            '.$body.'
//            </div>
//      
//    </div> ';
//            }else{
//               
//                 echo '
//        <div class="row">
//        <h3>'.$title.'</h3>
//<br />
//         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
//            '.$summary.'
//            </div>
//                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:2%">
//                <img src="'.$pathPost.'" id="previewing" alt="Photo        480x260" style="
//        font-size: 30px;
//        text-align: center;
//        width: 96%;
//        height: 55%;
//        text-align: center;
//        line-height: 189px;
//        left: 0px;
//        font-weight: bold;
//        color: #C0C0C0;
//        background-color: #FFFFFF;
//        overflow: auto;
//        border:solid;">
//         <h4>'.$this->getUsername($this->rows['users_id']).' , '.$formatDate->Onday_month_year_at().'</h4>
//                    </div>
//
//            
//             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:4%">
//            '.$body.'
//            </div>
//      
//    </div> ';
//
//
//            }
//            
//
//        }else{
//
//echo '<div class="alert alert-info">
//                             <strong><i class="fa fa-info"> error Message :</i></strong> 
//                              
//                                Please! No article to preview in database .Thanks!
//                             
//                          </div>';
//        }
//    }


      function getUsername($user_id)
    {
 $condition="id=".$user_id." LIMIT 1";
 $this->runQuery= $this->db->query_display('users',$column_name='', $condition);
 $this->rows=$this->db->fetch_all_array($this->runQuery);
 $username=ucfirst($this->db->html_entity_decodes($this->rows['users_fname']))." ".$this->db->html_entity_decodes($this->rows['users_lname']);
 return $username;
    }

    
    

 
    
    function getCategories($option){
        // $option="";
    $this->runQuery= $this->db->query_display('categories',$column_name='', $condition="");
            echo"<option>".$option."</option>";
            while($this->rows=$this->db->fetch_all_array($this->runQuery))
            {
            echo'<option>'.ucfirst($this->db->html_entity_decodes($this->rows['categories'])).'</option>';
          
            }
    
    }
   

}