<?php
require('Authenticate.php');
if(isset($_POST['onLogin'])){

$username=$_POST['username'];
$password = md5($_POST['pass']);
$Auth = new Authenticate($username,$password);
    if($Auth->login()=='empty')
    {
 echo $Auth->getMessage('empty',$username);
    }else if($Auth->login()=='error')
    {
        
echo $Auth->getMessage('error',$username);
?>
<script>function redirct(){window.location='index.php';}setInterval(redirct,500);</script>
    <?php }else{
       
        if($Auth->login() == 'Auth'){
        echo $Auth->getMessage('Auth',$username);
       ?>
        <script>function redirct(){window.location='home/';} function hide(){$(".login").hide();} setInterval(redirct,500); setInterval(hide,100); </script>
        <?php
        }
        else{
        echo $Auth->getMessage('Non_Auth',$username);?>
        <script>function redirct(){window.location='./';}setInterval(redirct,1500);</script>
        <?php }
        

    }
}

?>