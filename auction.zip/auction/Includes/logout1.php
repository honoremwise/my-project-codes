<?php
require('Destroy.php');
$logout = new Destroy();

if(isset($_POST['Onlogout1'])){

    if($logout->logoff()=='unset'){
 ?>
        <script>window.location='../studentLogin.php'; </script>
        <?php
    }else{
       ?>
        <script>window.location='./'; </script>
        <?php  
    
    }

}
?>