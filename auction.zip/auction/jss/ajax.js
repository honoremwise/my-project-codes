
function ajaxObj( meth, url ) {
    try{
	var x = new XMLHttpRequest();
	x.open( meth, url, true );
	x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	return x;
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
    }

function ajaxReturn(x){
    try{
	if(x.readyState == 4 && x.status == 200){
	    return true;	
	}
  }catch ( e ){
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}

function ajaxJs(method, url, myData) {
    try{
    var ajaxResponse;
    allTypes = "*/".concat("*");
    jQuery.ajax({
        type: method, // HTTP method POST or GET
        url: url, //Where to make Ajax calls
        dataType: "text", // Data type, HTML, json etc.
        processData: true,
        async: false,
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        data: myData, //Form variables
        accepts: {
            "*": allTypes,
            text: "text/plain",
            html: "text/html",
            xml: "application/xml, text/xml",
            json: "application/json, text/javascript"
        },

        contents: {
            xml: /xml/,
            html: /html/,
            json: /json/
        },

        responseFields: {
            xml: "responseXML",
            text: "responseText",
            json: "responseJSON"
        },
        success: function (response) {

            ajaxResponse = response;

        },
        error: function (xhr, ajaxOptions, thrownError) {

            ///ajaxResponse = alert(thrownError);
//'connection to server failed'
        }
    });

    return ajaxResponse;

        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}

// $(document).ready(function () {
//     //Disable cut copy paste
//     $('html').bind('cut copy paste', function (e) {
//         e.preventDefault();
//     });
   
//     //Disable mouse right click
//     $("html").on("contextmenu",function(e){
//         return false;
//     });
// });