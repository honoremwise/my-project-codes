var _URL = window.URL || window.webkitURL;

function _(x) {
    return document.getElementById(x);
}
function $Id(x) {
    return $("#"+x);
}

function $Class(x){
    return $("."+x);
}

function _values(x) {
    return _(x).value;
}
function _files(x) {
    return _(x).files[0];
}

_Show:function(){
     return _(x).style.display="block";
}

_Hide:function(){

     return _(x).style.display="none";
}
function AddyoutubeLink(){
    try{
    var urltext= $("#addYlink").val();
   // alert("urltext");
   viewYoutubeUrl(urltext);
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        } 
}

viewYoutubeUrl=function(urltext){
   try{
     var myData = 'viewYoutubeUrl='+urltext;
    var url = "Tasks/Setlayouts.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $(".preivewUrl").html(_ajax);
} }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        } 
}


function bannerDemension() {
        //window.preventDefault();
      $("#demension").show();
     
     var bsider = _("bsider").value;

if(bsider === 'On_Top_side'){
 $("#dmsiondisplay").html("1285 x 70 <input type='hidden' value='1285' id='bwidth'><input type='hidden' value='70' id='bheight'>");
  
}else if(bsider === 'On_Left_of_Log_side'){
$("#dmsiondisplay").html("728 x 90 <input type='hidden' value='728' id='bwidth'><input type='hidden' value='90' id='bheight'>");
}
else if(bsider === 'On_Below_Menus_side'){
 $("#dmsiondisplay").html("1285 x 70 <input type='hidden' value='1285' id='bwidth'><input type='hidden' value='70' id='bheight'>");
}else if(bsider === 'On_Left_Quotes_side'){
 $("#dmsiondisplay").html("300 x 270 <input type='hidden' value='300' id='bwidth'><input type='hidden' value='270' id='bheight'>");
}else if(bsider === 'On_Below_Slideshow_side'){
  $("#dmsiondisplay").html("983 x 120 <input type='hidden' value='983' id='bwidth'><input type='hidden' value='120' id='bheight'>");
}else if(bsider === 'On_RightPart_Side'){
  $("#dmsiondisplay").html("160 x 400 <input type='hidden' value='160' id='bwidth'><input type='hidden' value='400' id='bheight'>");
}else if(bsider === 'On_Footer_Side'){
   $("#dmsiondisplay").html("983 x 120 <input type='hidden' value='983' id='bwidth'><input type='hidden' value='120' id='bheight'>");
}

        
    }




function bagopen() {

    $("#test").show();
    $("#bagclose").show();
    $("#bagopen").hide();
}
function bagclose() {
    $("#test").hide();
    $("#bagclose").hide();
    $("#bagopen").show();
}
//function layouts() {
//    $("#viewLayouts").show();
//    $("#layouts").hide();
//};
function closelayouts() {
    $("#viewLayouts").hide();
    $("#layouts").show();
}

function word_counts() {
try{
    var word_count = _("summary").value;
    var words = _("summary").value.match(/\S+/g).length;
    if (words > 90) {
        // alert('ganza');
        // Split the string on first 200 words and rejoin on spaces
        var trimmed = _("summary").value.split(/\s+/, 90).join(" ");
        // Add a space at the end to keep new typing making new words
        _("summary").value = trimmed + " ";
        // $(word_count).val(trimmed + " ");
        $("#limits1").css('color', 'red');
        _("limits1").innerHTML = "typing of new words is no long continue! Limited to 30 words";
    }
    else {
        $('#display_count').text(words);
        $('#word_left').text(90 - words);
    }
}catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function word_counts_hder() {
try{
    var word_count = _("title").value;
    var words = _("title").value.match(/\S+/g).length;
    if (words > 30) {
        // alert('ganza');
        // Split the string on first 200 words and rejoin on spaces
        var trimmed = _("title").value.split(/\s+/, 30).join(" ");
        // Add a space at the end to keep new typing making new words
        _("title").value = trimmed + " ";
        $("#limits").css('color', 'red');
        _("limits").innerHTML = "typing of new words is no long continue! Limited to 30 words";
        // $(word_count).val(trimmed + " ");
    }
    else {
        $('#display_count_hder').text(words);
        $('#word_left_hder').text(30 - words);
    }
    
     }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function generated() {
    try{
    var type_id = _("type_id").value;
   
    
    var myData = 'type_id=' + type_id + '&Ongenerated=Ongenerated';
    var url = "Tasks/generater.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
         $("#getgenerated_id").html(_ajax);
      } else {
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

//addOrupdateArticle =  function(){
//    //alert('jih');
// //SetNewsUpdates();
//
//}

function BeforeUpdateArticle(id,token) {
    try{
        
   window.location="./Article.php?Modify=1&refer="+id+"&token="+token;
     }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }

}
function DeleteArticle(ev,picsname) {
    try{
     var myData = 'Setdelete=' + ev+'&picsname='+picsname;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#" + ev + "Setdeletemsg").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function removeToslidshow(ev) {
    try{
     var myData = 'removeToslidshow=' + ev;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#" + ev + "Setdeletemsg").html(_ajax);
} else {
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function removeTadverts(ev) {
    try{
     var myData = 'removeTadverts=' + ev;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#" + ev + "Setdeletemsg").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function SetToSlidshow(ev) {
    try{
     var myData = 'SetToSlidshow=' + ev;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#" + ev + "Setdeletemsg").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function SetAsAdverts(ev) {
    try{
     var myData = 'SetAsAdverts=' + ev;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#" + ev + "Setdeletemsg").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function deletComment(ev){
    try{
     var myData = 'deletComment=' + ev;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      
      $("#" + ev + "cmtsmsg").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
//function SetapproveComment(ev){
//    try{
//     var myData = 'SetapproveComment=' + ev;
//    var url = "Tasks/Setoption.php";
//    var metthod = 'GET';
//    //build a post data structure
//    var _ajax = ajaxJs(metthod, url, myData);
//    if (_ajax != null) {
//      
//      $("#" + ev + "cmtsmsg").html(_ajax);
//} else {
//    }
//        }catch ( e ) {
//          // IE8,9 Will throw exceptions on certain host objects #9897
//          return false;
//      }
//}

function OnDeleteArticle(id,picsname) {
    try{
    $("#dltbtn").hide();
    var myData = 'OnDeleteArticle=' + id +'&picsname='+picsname;
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $("#deleted").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function OnRemoveToslidhowArticle(id) {
    try{
    $("#dltbtn").hide();
    var myData = 'RemovetoSlideshow=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $("#deleted").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function OnRemoveTAdvertsArticle(id){
    try{
    $("#dltbtn").hide();
    var myData = 'RemovetoAdverts=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $("#deleted").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function OnSetToslidshow(id){
    try{
    $("#dltbtn").hide();
    var myData = 'AddtoSlideshow=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $("#deleted").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function OnSetToAdvertss(id) {
    try{
    $("#dltbtn").hide();
    var myData = 'AddtoAdverts=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $("#deleted").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}


function OnDeleteCmmt(id) {
    try{
     $("#"+id+"cmtsmsg").hide();
   $("#"+id+"cmtsmsg").html('Loading');
    var myData = 'OnDeleteCmmt=' + id;
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
       $("#"+id+"cmtsmsg").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
       // $("#"+id+"cmtsmsg").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function approveCmments(id) {
    try{
   $("#"+id+"cmtsmsg").hide();
   $("#"+id+"cmtsmsg").html('Loading');
    var myData = 'approveCmments=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
     $("#"+id+"cmtsmsg").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        //$("#dltbtn").show();
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}


function UnsetPublic(id) {
try{
    var myData = 'UnsetPublic=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'publishing').html(ajax.responseText);

        }
    };
    ajax.send(myData);
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function SetPublic(id) {
try{
    var myData = 'SetPublic=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'publishing').html(ajax.responseText);

         }
};
    ajax.send(myData);
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function AddtoAdverts(id) {
try{
    var myData = 'AddtoAdverts=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'Advertsing').html(ajax.responseText);

            //_("append").innerHTML = ajax.responseText;
        }
};
    ajax.send(myData);
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function RemovetoAdverts(id) {
try{
    var myData = 'RemovetoAdverts=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'Advertsing').html(ajax.responseText);
}
};
    ajax.send(myData);
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function AddtoSlideshow(id) {
try{
    var myData = 'AddtoSlideshow=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'Slidshowing').html(ajax.responseText);

            //_("append").innerHTML = ajax.responseText;
        }
 };
    ajax.send(myData);
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function RemovetoSlideshow(id) {
try{
    var myData = 'RemovetoSlideshow=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'Slidshowing').html(ajax.responseText);

            //_("append").innerHTML = ajax.responseText;
        }


    };
    ajax.send(myData);
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
//function setlayoutImg1(id) {
//    try{
//    $("#ly1").css("border", "red");
//    $("#ly1").css("border", "solid");
//
//    $("#ly2").css("border", "gray");
//    $("#ly2").css("border", "solid");
//
//    var myData = 'setlayoutImg1=' + id;
//    var url = "Tasks/Updatedata.php";
//    var metthod = 'POST';
//    //build a post data structure
//
//    var ajax = ajaxObj(metthod, url);
//    ajax.onreadystatechange = function () {
//        if (ajaxReturn(ajax) == true) {
//
//            $('#' + id + 'setlayouts').html(ajax.responseText);
//
//            //_("append").innerHTML = ajax.responseText;
//        }
//
//
//    };
//    ajax.send(myData);
//        }catch ( e ) {
//          // IE8,9 Will throw exceptions on certain host objects #9897
//          return false;
//      }
//}
//function setlayoutImg2(id) {
//    try{
//    $("#ly2").css("border", "red");
//    $("#ly2").css("border", "solid");
//
//    $("#ly1").css("border", "gray");
//    $("#ly1").css("border", "solid");
//    var myData = 'setlayoutImg2=' + id;
//    var url = "Tasks/Updatedata.php";
//    var metthod = 'POST';
//    //build a post data structure
//
//    var ajax = ajaxObj(metthod, url);
//    ajax.onreadystatechange = function () {
//        if (ajaxReturn(ajax) == true) {
//
//            $('#' + id + 'setlayouts').html(ajax.responseText);
//
//            //_("append").innerHTML = ajax.responseText;
//        }
//
//
//    };
//    ajax.send(myData);
//        }catch ( e ) {
//          // IE8,9 Will throw exceptions on certain host objects #9897
//          return false;
//      }
//}
function Artfinish(type,token) {
    try{
    $('#loader').show();
    var arid = $("#arid").val();
    var myData = 'Artfinish=' + arid;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#finish').html(ajax.responseText);

            window.location="./?Modify=0&type="+type+"&token="+token;
            //_("append").innerHTML = ajax.responseText;
            $('#loader').hide();
        }


    };
    ajax.send(myData);
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function publishing() {
try{
    var arid = $("#arid").val();
    var myData = 'publishing=' + arid;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $('#' + arid + 'publishing').html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $('#' + arid + 'publishing').show();
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function Advertsing() {
try{
    var arid = $("#arid").val();
    var myData = 'Advertsing=' + arid;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $('#' + arid + 'Advertsing').html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $('#' + arid + 'Advertsing').show();
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function Slidshowing() {
try{
    var arid = $("#arid").val();
    var myData = 'Slidshowing=' + arid;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
        $('#' + arid + 'Slidshowing').html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        $('#' + arid + 'Slidshowing').show();
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
//function setlayouts() {
//try{
//    var arid = $("#arid").val();
//    var myData = 'setlayouts=' + arid;
//    var url = "Tasks/Setoption.php";
//    var metthod = 'GET';
//    //build a post data structure
//    var _ajax = ajaxJs(metthod, url, myData);
//    if (_ajax != null) {
//        //alert(_ajax);
//
//        //_("SetNewsUpdates").innerHTML=_ajax;
//        $('.' + arid + 'setlayouts').html(_ajax);
//        // return SetNewsUpdates();
//        //console.log(_ajax);
//
//    } else {
//        $('.' + arid + 'setlayouts').show();
//    }
//    }catch ( e ) {
//          // IE8,9 Will throw exceptions on certain host objects #9897
//          return false;
//      }
//}
//setInterval(Slidshowing, 1000);
//setInterval(Advertsing, 1000);
//setInterval(publishing, 1000);
//setInterval(generated, 1000);
//setInterval(SetNewsUpdates,1000);

function imageIsLoaded(e) {
    $Id("addfiles").css("color", "green");
    $Id('ipreviewing').attr('src', e.target.result);
    $Id('ipreviewing').attr('width', '250px');
    $Id('ipreviewing').attr('height', '230px');
};


 Addfiles:function(){
    alert("ok");
}
_Addfiless = function(){
    try{
    $Id("messages").empty(); // To remove the previous error message
    var imgs = new Image();
    var file = _files('addfiles');
         var imgwidth = 0;
         var imgheight = 0;
    
         var maxwidth  = _values('widths');
         var maxheight = _values('heights');
    
    var imagefile = file.type;
  
    var match = ["image/jpeg", "image/png", "image/jpg"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
         _Show("messages");
         $Id('ipreviewing').attr('src', 'noimage.png');
         $Id("messages").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
        return false;
    } else {
             imgs.src = _URL.createObjectURL(file);
             imgs.onload = function() {
             imgwidth = this.width;
             imgheight = this.height;

        if(maxwidth <= imgwidth && maxheight <= imgheight){
         _Hide("messages");
        var reader = new FileReader();
        reader.onload = imageIsLoaded;
        reader.readAsDataURL(file);
             }else{
            _Show("messages");
            $Id("messages").text("Image size must be "+maxwidth+"X"+maxheight+" Or greater than "+maxwidth+"X"+maxheight);
             }
        }
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

Chooseaudio=function(){
    try{
    $("#messageAudio").show(); // To remove the previous error message
    $("#okformat1").hide(); //show submit button
    $("#setinfo1").hide(); //show submit button
    $("#YesUploadwithSave").hide(); //show submit button
    $('#adesc').val('');
        $('#auprogress-bar').hide();
        $('#aucomplete').hide();
    var file = _('Chooseaudio').files[0];
    
    
    var audiofile = file.type;
    var audiosizefile = file.size;
      
    var match = ["audio/mp3"];

    if (!((audiofile == match[0]))) {
        $("#YesUploadwithSave").hide(); //show submit button
         $("#idesc").hide(); //show submit button
        $("#okformat1").hide(); //show submit button
         $("#messageAudio").show(); //show submit button
        $("#setinfo1").hide(); //show submit button
        $('#previewing2').attr('src', 'noimage.png');
        $("#messageAudio").html("<p id='error'>Please Select A valid Audio File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only MP3 Audio type allowed</span>");
        return false;
    }else if (audiosizefile < 60000) {
        $("#YesUploadwithSave").hide(); //show submit button
         $("#idesc").hide(); //show submit button
        $("#okformat1").hide(); //show submit button
         $("#messageAudio").show(); //show submit button
        $("#setinfo1").hide(); //show submit button
        $('#previewing2').attr('src', 'noimage.png');
        $("#messageAudio").html("<h4>Note</h4>" + "<span id='error_message'>Only 6 Megabytes allowed</span>");
        return false;
    } else {
           $("#YesUploadwithSave").show(); //show submit button
             $("#messageAudio").hide(); //show submit button
            $("#setinfo1").hide(); //show submit button
            $("#okformat1").show(); //show submit button 
            $("#adesc").show(); //show submit button
        var reader = new FileReader();
        reader.onload = AudioIsLoaded;
        reader.readAsDataURL(_('Chooseaudio').files[0]);
             
        }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
GetPhtoUploaded=function(){
    try{
    var type_id=$("#referid").val();
       // alert(type_id);
    var myData = 'GetPhtoUpload=photo&type_id='+type_id;
    var url = "Tasks/Uploaddata.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#viewPhoto").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
GetAudioUploaded=function(){
       try{
    var type_id=$("#referid").val();
       // alert(type_id);
    var myData = 'GetAudioUpload=audio&type_id='+type_id;
    var url = "Tasks/Uploaddata.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#viewAudio").html(_ajax);
} else {
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
deletefile=function(id,format){
     try{
    
    var filename=$("#"+id+"filename").val();
    var myData ='deletefile='+id+'&filename='+filename+'&format='+format;
    var url = "Tasks/Deletedata.php";
    var metthod = 'POST';
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        return true;
} else {
    return false;
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }  
}
//setInterval(GetPhtoUploaded, 1000);
//setInterval(GetAudioUploaded, 1000);
Choosephoto=function() {
    try{
    $("#messagePhoto").show(); // To remove the previous error message
    $("#okformat").hide(); //show submit button
    $("#setinfo").hide(); //show submit button
     $("#YesUploadwithSave").hide(); //show submit button
           $("#idesc").show(); //show submit button
           $("#idesc").val(""); //show submit button

           $('#iprogress-bar').hide();
           $('#icomplete').hide();
    var img = new Image();
    var file = _('Choosephoto').files[0];
         var imgwidth = 0;
         var imgheight = 0;
    
         var maxwidth = 450;
         var maxheight = 330;
    
    var imagefile = file.type;
  
    var match = ["image/jpeg", "image/png", "image/jpg"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
        $("#YesUploadwithSave").hide(); //show submit button
         $("#idesc").hide(); //show submit button
        $("#okformat").hide(); //show submit button
         $("#messagePhoto").show(); //show submit button
        $("#setinfo").hide(); //show submit button
        $('#previewing1').attr('src', 'noimage.png');
        $("#messagePhoto").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
        return false;
    } else {
             img.src = _URL.createObjectURL(file);
             img.onload = function() {
             imgwidth = this.width;
             imgheight = this.height;

        if(maxwidth <= imgwidth && maxheight <= imgheight){
            $("#YesUploadwithSave").show(); //show submit button
             $("#messagePhoto").hide(); //show submit button
            $("#setinfo").hide(); //show submit button
            $("#okformat").show(); //show submit button
            $("#idesc").show(); //show submit button
        var reader = new FileReader();
        reader.onload = PhotoIsLoaded;
        reader.readAsDataURL(_('Choosephoto').files[0]);
             }else{
                 $("#YesUploadwithSave").hide(); //show submit button
                  $("#idesc").hide(); //show submit button
                 $("#okformat").hide(); //show submit button
                 $("#setinfo").hide(); //show submit button
                 $("#messagePhoto").show(); //show submit button
                 $("#messagePhoto").text("Image size must be "+maxwidth+"X"+maxheight+" Or greater than "+maxwidth+"X"+maxheight);
             }
        }
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function PhotoIsLoaded(e) {
    $("#Choosephoto").css("color", "green");
    //$('#image_preview').css("display", "block");
    $('#previewing1').attr('src', e.target.result);
    $('#previewing1').attr('width', '80%');
    $('#previewing1').attr('height', '80%');
};

function AudioIsLoaded(e) {
    $("#Chooseaudio").css("color", "green");
    //$('#image_preview').css("display", "block");
    $('#previewing2').attr('src', e.target.result);
 
};

YesUploadwithSave=function(type_id,format){
    try{
        if(format=='photo'){
             $("#idesc").show(); //show submit button
             $('#iprogress-bar').show();
            $('#icomplete').show();
    var files = document.getElementById('Choosephoto').files[0];
    var desc = document.getElementById('idesc').value;
    var formData = new FormData();
    formData.append("Choosephoto", files);
    formData.append("type_id", type_id);
    formData.append("format", format);
    formData.append("desc", desc);
        }else{
    var files = document.getElementById('Chooseaudio').files[0];
    var desc = document.getElementById('adesc').value;
     $('#auprogress-bar').show();
     $('#aucomplete').show();
            
    var formData = new FormData();
    formData.append("Chooseaudio", files);
    formData.append("type_id", type_id);
    formData.append("format", format);  
    formData.append("desc", desc);
        }
     var url = "Tasks/Uploaddata.php";
     var metthod = 'POST';
    var aj = new XMLHttpRequest();
        
    aj.upload.addEventListener("progress", (format=='photo')?progress:progressAudio, false);
    aj.addEventListener("load", (format=='photo')?complete:completeAudio, false);
    aj.addEventListener("error", (format=='photo')?error:errorAudio, false);
    aj.addEventListener("abort", (format=='photo')?abort:abortAudio, false);
    aj.open(metthod, url);
    aj.send(formData);
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function progress(event) {
    
       $("#YesUploadwithSave").hide(); //show submit button
             $("#messagePhoto").show(); //show submit button
             $("#setinfo").hide(); //show submit button
             $("#okformat").hide(); //show submit button
             $("#YesUploadwithSave").hide(); //show submit button
             $("#idesc").hide(); //show submit button
             $("#idesc").val(""); //show submit button
            document.getElementById("messagePhoto").innerHTML = 'File Uploaded successfully';      
            
}
function progressAudio(event) {
    
       $("#YesUploadwithSave").hide(); //show submit button
             $("#messageAudio").show(); //show submit button
             $("#setinfo1").hide(); //show submit button
             $("#okformat1").hide(); //show submit button
               $("#adesc").hide(); //show submit button
             $("#adesc").val(""); //show submit button
            document.getElementById("messageAudio").innerHTML = 'File Uploaded successfully';      
            
}
function complete(event) {
    
     $("#YesUploadwithSave").hide(); //show submit button
             $("#messagePhoto").show(); //show submit button
             $("#setinfo").hide(); //show submit button
             $("#okformat").hide(); //show submit button
             $("#idesc").hide(); //show submit button
             $("#idesc").val(""); //show submit button
    var percent = (event.loaded / event.total) * 100;
    //document.getElementById("image_progress").value = Math.round(percent);
    $('#iprogress-bar').css('width', Math.round(percent) + '%');
    _("icomplete").innerHTML = Math.round(percent) + "% Uploading ....";
 }
function completeAudio(event) {
    
     $("#YesUploadwithSave").hide(); //show submit button
             $("#messageAudio").show(); //show submit button
             $("#setinfo1").hide(); //show submit button
             $("#okformat1").hide(); //show submit button
             $("#adesc").hide(); //show submit button
             $("#adesc").val(""); //show submit button
    var percent = (event.loaded / event.total) * 100;
    //document.getElementById("image_progress").value = Math.round(percent);
    $('#auprogress-bar').css('width', Math.round(percent) + '%');
    _("aucomplete").innerHTML = Math.round(percent) + "% Uploading ....";
 }
function error(event) {
          $("#YesUploadwithSave").hide(); //show submit button
             $("#messagePhoto").show(); //show submit button
             $("#setinfo").hide(); //show submit button
             $("#okformat").hide(); //show submit button
    document.getElementById("messagePhoto").innerHTML = "Upload failed";


}
function errorAudio(event) {
          $("#YesUploadwithSave").hide(); //show submit button
             $("#messageAudio").show(); //show submit button
             $("#setinfo1").hide(); //show submit button
             $("#okformat1").hide(); //show submit button
    document.getElementById("messageAudio").innerHTML = "Upload failed";


}
function abort(event) {
          $("#YesUploadwithSave").hide(); //show submit button
             $("#messagePhoto").show(); //show submit button
             $("#setinfo").hide(); //show submit button
             $("#okformat").hide(); //show submit button
    document.getElementById("messagePhoto").innerHTML = "Upload aborted";
}
function abortAudio(event) {
          $("#YesUploadwithSave").hide(); //show submit button
             $("#messageAudio").show(); //show submit button
             $("#setinfo1").hide(); //show submit button
             $("#okformat2").hide(); //show submit button
    document.getElementById("messageAudio").innerHTML = "Upload aborted";
}


function AddQuotesfile()
{
    try{
     $("#uploadimg").show(); //show submit button
     $("#message").empty(); // To remove the previous error message
    var image;
    image = new Image();
    var file = _('addqtsfile').files[0];
    var naturewidth = _('addqtsfile').width;
    var natureheight = _('addqtsfile').height;
    var imagefile = file.type;
    var width = 200;
    var match = ["image/jpeg", "image/png", "image/jpg"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
        $('#previewing').attr('src', 'noimage.png');
        $("#message").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
        return false;
    } else {
       
        var reader = new FileReader();
        reader.onload = imageIsLoaded;
        reader.readAsDataURL(_('addqtsfile').files[0]);
        
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function AddBannerfile()
{
    try{
    var _URL = window.URL || window.webkitURL;
     $("#uploadimg").show(); //show submit button
     $("#message").empty(); // To remove the previous error message
    
    var file = _('addbnerfile').files[0];
  
    img = new Image();
    var imagefile = file.type;
    var match = ["image/jpeg", "image/png", "image/jpg", "image/gif"];
    var imgwidth = 0;
    var imgheight = 0;
    var maxwidth = _('bwidths').value;
    var maxheight = _('bheights').value;
  //  img.src = _URL.createObjectURL(file);
    
    //img.onload = function() {
    imgwidth = file.width;
    imgheight = file.height;
   // alert(imgwidth);
    //  $("#width").text(imgwidth);
    //  $("#height").text(imgheight);

if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]) || (imagefile == match[3]))) {
        $('#previewing').attr('src', 'noimage.png');
        $("#message").html("<span id='error'>Please Select A valid Image File</span>" + "<span> Note </span>" + "<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
        $("#uploadimg").hide(); //show submit button
        return false;

//     } else if(imgwidth != maxwidth && imgheight != maxheight){
//        $("#message").html("Image size must be "+maxwidth+"X"+maxheight +" Not "+imgwidth+"x"+imgheight);
//        $("#uploadimg").hide(); //show submit button
//         return false;
 }else {
       
        var reader = new FileReader();
        reader.onload = imageIsLoaded;
        reader.readAsDataURL(_('addbnerfile').files[0]);
        
    }
    // };
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function uploadquatesimg(id)
{
return  uploadquotesPhoto(id);

}
function uploadbannersimg(id)
{
return  uploadbannersPhoto(id);

}

function changeQuatesimgbtn(id,path,n) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-photo fa-2x"></i> Add Photo');
    $(".collapsed").css('color', 'gray');

   
    if(n==1){
    $("#update-box").html('<button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button><div class="col-md-12"><button style="display:none;" id="uploadimg" class="btn btn-info btn-lg btn-block fa fa-upload pull-right" type="button" onclick="uploadquatesimg('+id+')"> Upload</button> <h2><center><span class="label label-success" id="message"></span></center></h2></div><br /> <br /><div class="col-md-2"></div><div class="col-md-8"><img src="" id="previewing" alt="Add Photo   480x260" style="font-size: 30px;font-weight: bold;text-align: center;width: 96%;height: 38%;text-align: center;line-height: 180px;left: 0px;color: #C0C0C0;background-color: #FFFFFF;overflow:auto;border:solid;"> <input type="file" id="addqtsfile" style="margin-top:5px;margin-left:7px" name="file"  onchange=AddQuotesfile('+id+') /></div><i id="loading" style="display:none">Loading....</i><div class="progress" style="width: 96%;"> <div class="progress-bar progress-bar-info" id="progress-bar" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:0%;height:120%"><span id="counting" style="font-size: 10px;padding-top:-10px;font-weight: bold;"></span></div><div><div class="col-md-2"></div>');
}else{
   $("#update-box").html('<button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button><div class="col-md-12"><button style="display:none;" id="uploadimg" class="btn btn-info btn-lg btn-block fa fa-upload pull-right" type="button" onclick="uploadquatesimg('+id+')"> Upload</button> <h2><center><span class="label label-success" id="message"></span></center></h2></div><br /> <br /><div class="col-md-2"></div><div class="col-md-8"><img src='+path+' id="previewing" alt="Update Photo   480x260" style="font-size: 30px;font-weight: bold;text-align: center;width: 96%;height:auto;text-align: center;line-height:auto; left: 0px;color: #C0C0C0;background-color: #FFFFFF;overflow:auto;border:solid;"> <input type="file" id="addqtsfile" style="margin-top:5px;margin-left:7px" name="file"  onchange=AddQuotesfile('+id+') /></div><i id="loading" style="display:none">Loading....</i><div class="progress" style="width: 96%;"> <div class="progress-bar progress-bar-info" id="progress-bar" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:0%;height:120%"><span id="counting" style="font-size: 10px;padding-top:-10px;font-weight: bold;"></span></div><div><div class="col-md-2"></div>');  
}
}

function changeBannerimgbtn(id,path,width,height,n) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-photo fa-2x"></i> Upload Photo');
    $(".collapsed").css('color', 'gray');

   
    if(n==1){
    $("#update-box").html('<button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button><br /><div class="col-md-12"><button style="display:none;" id="uploadimg" class="btn btn-info btn-lg btn-block fa fa-upload pull-right" type="button" onclick="uploadbannersimg('+id+')"> Upload</button> <br /><br /><h2><center><span class="label label-danger" id="message"></span></center></h2></div><br /> <br /><div class="col-md-12"><img src="" id="previewing" alt="Upload Photo   '+width+'x'+height+'" style="font-size: 30px;font-weight: bold;text-align: center;width:'+width+'px;height: '+height+'px;text-align: center;line-height: auto;left: 0px;color: #C0C0C0;background-color: #FFFFFF;overflow:auto;border:solid;"> <input type="file" id="addbnerfile" style="margin-top:5px;margin-left:7px" name="file"  onchange=AddBannerfile() /><input type="hidden" id="bwidths" value='+width+'><input type="hidden" value='+height+' id="bheights"><br /><br /><br /></div><i id="loading" style="display:none">Loading....</i><div class="progress" style="width: 96%;"> <div class="progress-bar progress-bar-info" id="progress-bar" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:0%;height:120%"><span id="counting" style="font-size: 10px;padding-top:-10px;font-weight: bold;"></span></div><div>');
}else{
  $("#update-box").html('<button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button><br /><div class="col-md-12"><button style="display:none;" id="uploadimg" class="btn btn-info btn-lg btn-block fa fa-upload pull-right" type="button" onclick="uploadbannersimg('+id+')"> Upload</button> <br /><br /><h2><center><span class="label label-danger" id="message"></span></center></h2></div><br /> <br /><div class="col-md-12"><img src='+path+' id="previewing" alt="Upload Photo   '+width+'x'+height+'" style="font-size: 30px;font-weight: bold;text-align: center;width:'+width+'px;height: '+height+'px;text-align: center;line-height: auto;left: 0px;color: #C0C0C0;background-color: #FFFFFF;overflow:auto;border:solid;"> <input type="file" id="addbnerfile" style="margin-top:5px;margin-left:7px" name="file"  onchange=AddBannerfile() /><input type="hidden" id="bwidths" value='+width+'><input type="hidden" value='+height+' id="bheights"><br /><br /><br /></div><i id="loading" style="display:none">Loading....</i><div class="progress" style="width: 96%;"> <div class="progress-bar progress-bar-info" id="progress-bar" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:0%;height:120%"><span id="counting" style="font-size: 10px;padding-top:-10px;font-weight: bold;"></span></div><div>');
}
}

function uploadquotesPhoto(fid) {
    try{
    var files = document.getElementById('addqtsfile').files[0];
   
    var formData = new FormData();
    formData.append("addqtsfile", files);
    formData.append("fid", fid);
     var url = "Tasks/Adddata.php";
     var metthod = 'POST';
    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler, false);
    aj.addEventListener("load", completeHandler, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
    aj.send(formData);

     $("#uploadimg").hide(); //show submit button
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }

}

function uploadbannersPhoto(fid) {
    try{
    var files = document.getElementById('addbnerfile').files[0];
   
    var formData = new FormData();
    formData.append("addbnerfile", files);
    formData.append("bid", fid);
     var url = "Tasks/Adddata.php";
     var metthod = 'POST';
    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler, false);
    aj.addEventListener("load", completeHandler, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
    aj.send(formData);

     $("#uploadimg").hide(); //show submit button
        
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }

}

function uploadArticlePhoto(metthod, url, type_id) {
    try{
    var files = document.getElementById('addfiles').files[0];

    var formData = new FormData();
    formData.append("addfiles", files);
    formData.append("type_id", type_id);

    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler, false);
    aj.addEventListener("load", completeHandler, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
    aj.send(formData);
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }

}
function completeHandler(event) {
    document.getElementById("messages").innerHTML = 'File Uploaded successfully';
    // $("#progress-bar").hide();
}
function progressHandler(event) {
    // document.getElementById("upTotal").innerHTML = "Uploaded "+event.loaded+" Bytes of "+event.total;
    var percent = (event.loaded / event.total) * 100;
    //document.getElementById("image_progress").value = Math.round(percent);
    $('#progress-bar').css('width', Math.round(percent) + '%');
    _("counting").innerHTML = Math.round(percent) + "% Uploading ....";
    
}
function errorHandler(event) {
    document.getElementById("messages").innerHTML = "Upload failed";


}
function abortHandler(event) {
    document.getElementById("messages").innerHTML = "Upload aborted";
}

SaveArticles=function(){
    try{

    if ($("#title").val() === '' || $("#summary").val() === '' || $("#body").val() === '' || $("#addfiles").val() === '' || $("#category").val() === 'Choose Category' || $("#location").val() === 'Choose Location') {
        alert("Please,check if field submission are empty !");

        $("#displaymsg").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        return false;
    } else {
        $("#displaymsg").html('');
                                
        var referid = $("#referid").val();
        var menu_id = $("#menu_id").val();
        var title   = $("#title").val();
        var summary = $("#summary").val();
        var body     = tinyMCE.activeEditor.getContent();
        var category = $("#category").val();
        var location = $("#location").val();
        console.log(body);
       
       //build a post data structure
          $("#SaveArticle").hide(); //hide submit button
        $("#Loadingbtn").show(); //show loading image
        var myData = 'menu_id=' + menu_id + '&type_id=' + referid + '&title=' + title + '&summary=' + summary + '&body=' + body + '&category=' + category + '&location='+location+'&OnaddArticle=OnaddArticle';
        var url = "Tasks/Adddata.php";
        var metthod = 'POST';
        
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            //alert(_ajax);
           uploadArticlePhoto(metthod, url, referid);
            $("#displaymsg").append(_ajax);
            $("#SaveArticle").show(); //show submit button
            $("#Loadingbtn").hide(); //hide loading image
            $("#addPanel").hide(); //hide loading image
            

        } else {

            $("#SaveArticle").show(); //show submit button
            $("#Loadingbtn").hide(); //hide loading image
        }



    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function UpdateArticle(id) {
    try{

    //var img = $('#previewing').attr('src',"");

    if ($("#title").val() === '' || $("#summary").val() === '' || $("#body").val() === '' || $("#category").val() === 'Choose Category' || $("#category").val() === '' || $("#location").val() === 'Choose Location' || $("#location").val() === '') {
        alert("Please,check if field submission are empty !");

        $("#displaymsg").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        return false;
    } else {
        $("#displaymsg").html('');

        $("#UpdateArticle").hide(); //hide submit button
        $("#Loadingbtn").show(); //show loading image
        var title = $("#title").val();
        var summary = $("#summary").val();
        var body = $("#body").val();
        var category = $("#category").val();
        var location = $("#location").val();
        
//console.log(body);

        var myData = 'type_id=' + id + '&title=' + title + '&summary=' + summary + '&body=' + body + '&category=' + category + '&location='+location+'&OnUpdateArticle=OnUpdateArticle';
        var url = "Tasks/Updatedata.php";
        var metthod = 'POST';
        uploadArticlePhoto(metthod, "Tasks/Adddata.php", id);
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            //alert(_ajax);
            $("#displaymsg").append(_ajax);
            $("#UpdateArticle").show(); //show submit button
            $("#Loadingbtn").hide(); //hide loading image

        } else {

            $("#UpdateArticle").show(); //show submit button
            $("#Loadingbtn").hide(); //hide loading image
        }

    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function updatesQuotes(id)
{
try{
 $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-pencil fa-2x"></i> Modify Quotes');
    $(".collapsed").css('color', 'green');
    //var files = document.getElementById('addfile').files[0];

    //console.log(lang, country);
    var myData = "id=" + id +"&settoUpdateQuotes=settoUpdateQuotes";
    $("#Loading").show(); //show loading image
    var url = "Tasks/Setoption.php";
    var metthod = 'POST';
    //build a post data structure
   var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").html(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}


function updatesBanners(id,url,sider,width,height,date,createby,avertsstatus)
{
try{
 $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-pencil fa-2x"></i> Modify Banner');
    $(".collapsed").css('color', 'green');
    //var files = document.getElementById('addfile').files[0];

    //console.log(lang, country);
    var myData = "id=" + id + "&url=" + url + "&sider=" + sider + "&width=" + width + "&height=" + height + "&date=" + date + "&createby=" + createby + "&avertsstatus=" + avertsstatus + "&updatesBanners=updatesBanners";
    $("#Loading").show(); //show loading image
    var url = "Tasks/Setlayouts.php";
    var metthod = 'POST';
    //build a post data structure
   var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function deleteQuatesbtn(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-trash fa-2x"></i> Delete Quotes');
    $(".collapsed").css('color', 'red');
    $("#update-box").html('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteQuotes(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this Quotes, if yes click OK</div>');
}
function deleteBannersbtn(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-trash fa-2x"></i> Delete Banner');
    $(".collapsed").css('color', 'red');
    $("#update-box").html('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteBanners(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this Banner, if yes click OK</div>');
}





function OnDeleteQuotes(id)
{
    try{
       $("#Loading").show();
    var myData = 'id=' + id + '&OnDeleteQuotes=OnDeleteQuotes';
    $("#Loading").show(); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").html(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function OnDeleteBanners(id)
{
    try{
       $("#Loading").show();
    var myData = 'id=' + id + '&OnDeleteBanners=OnDeleteBanners';
    $("#Loading").show(); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").html(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function updateQuatesbtn(id) {

    try{
    if ($("#title").val() === '' || $("#quotes").val() === '') {
        alert("Please,check if field submission are empty !");

        $("#responds").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        //return false;
    } else {
        $("#responds").html('');

        $("#updateqoutes").hide(); //hide submit button
        $("#LoadingImage").show(); //show loading image

        $("#responds").val();
        var title = $("#title").val();
        var quotes = tinyMCE.activeEditor.getContent();
        var status = $("#status").val();

        var myData = 'id='+id+'&title=' + title + '&quotes=' + quotes + '&status=' + status + '&updateqoutes=updateqoutes';
        var url = "Tasks/Updatedata.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            //alert(_ajax);
            $("#responds").html(_ajax);
            $("#updateqoutes").show(); //show submit button
            $("#LoadingImage").hide(); //hide loading image
            $("#title").val('');
            $("#quotes").val('');
            $("#status").val('');
        } else {
            $("#title").val('');
            $("#quotes").val('');
            $("#status").val('');
        }
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function updateBannerbtn(id) {
try{
   if ($("#burl").val() === '' || $("#bsider").val() === '') {
        alert("Please,check if field submission are empty !");

        $("#responds").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        //return false;
    } else {
        $("#responds").html('');

        $("#updatebanner").hide(); //hide submit button
        $("#LoadingImage").show(); //show loading image

        $("#responds").val();
        var burl    = $("#burl").val();
        var bsider  = $("#bsider").val();
        var bstatus = $("#bstatus").val();
        var bwidth  = $("#bwidth").val();
        var bheight = $("#bheight").val();
       var myData = 'id='+id+'&burl=' + burl + '&bsider=' + bsider + '&bstatus=' + bstatus + '&bwidth=' + bwidth + '&bheight=' + bheight + '&updatebanner=updatebanner';
        var url = "Tasks/Updatedata.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            //alert(_ajax);
            $("#responds").html(_ajax);
            $("#updatebanner").show(); //show submit button
            $("#LoadingImage").hide(); //hide loading image
            $("#burl").val('');
            $("#bsider").val('');
            $("#bstatus").val('');
        } else {
           $("#burl").val('');
            $("#bsider").val('');
            $("#bstatus").val('');
        }
  }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}


function saveQuatesbtn() {
try{
    if ($("#title").val() === '' || $("#body").val() === '') {
        alert("Please,check if field submission are empty !");

        $("#responds").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        //return false;
    } else {
        $("#responds").html('');

        $("#saveqoutes").hide(); //hide submit button
        $("#LoadingImage").show(); //show loading image

        $("#responds").val();
        var title = $("#title").val();
        var quotes = tinyMCE.activeEditor.getContent();
        var status = $("#status").val();

       var myData = 'title=' + title + '&quotes=' + quotes + '&status=' + status + '&saveqoutes=saveqoutes';
        var url = "Tasks/Adddata.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            //alert(_ajax);
            $("#responds").html(_ajax);
            $("#saveqoutes").show(); //show submit button
            $("#LoadingImage").hide(); //hide loading image
            $("#title").val('');
            $("#quotes").val('');
            $("#status").val('');
        } else {
            $("#title").val('');
            $("#quotes").val('');
            $("#status").val('');
        }
  }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function saveBannersbtn() {
try{
    if ($("#burl").val() === '' || $("#bsider").val() === '') {
        alert("Please,check if field submission are empty !");

        $("#responds").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        //return false;
    } else {
        $("#responds").html('');

        $("#savebanners").hide(); //hide submit button
        $("#LoadingImage").show(); //show loading image

        $("#responds").val();
        var burl    = $("#burl").val();
        var bsider  = $("#bsider").val();
        var bstatus = $("#bstatus").val();
        var bwidth  = $("#bwidth").val();
        var bheight = $("#bheight").val();
       var myData = 'burl=' + burl + '&bsider=' + bsider + '&bstatus=' + bstatus + '&bwidth=' + bwidth + '&bheight=' + bheight + '&savebanners=savebanners';
        var url = "Tasks/Adddata.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            //alert(_ajax);
            $("#responds").html(_ajax);
            $("#savebanners").show(); //show submit button
            $("#LoadingImage").hide(); //hide loading image
            $("#burl").val('');
            $("#bsider").val('');
            $("#bstatus").val('');
        } else {
           $("#burl").val('');
            $("#bsider").val('');
            $("#bstatus").val('');
        }
  }
    }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
function OnUpdateMenu(id) {
try{
    if ($("#lang").val() === '' || $("#menu").val() === '') {
        alert("Please,check if field submission are empty !");
        return false;
    }

    $("#OnUpdateMenu").hide(); //hide submit button
    $("#LoadingImage").show(); //show loading image

    $("#responds").val();
    var lang = $("#lang").val();
    var menu = $("#menu").val();
    var setacts = $("#setacts").val();

    var myData = 'id=' + id + '&lang=' + lang + '&menu=' + menu + '&setacts=' + setacts + '&OnUpdateMenu=OnUpdateMenu';
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);
        $("#responds").append(_ajax);
        $("#OnUpdateMenu").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image

    } else {

        $("#OnUpdateMenu").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    }
}catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}

function OnUpdateLang(id) {
    if ($("#lang").val() === '' || $("#country").val() === '') {
        alert("Please,check if field submission are empty!");
        return false;
    }

    $("#OnUpdateLang").hide(); //hide submit button
    $("#LoadingImage").show(); //show loading image
    $("#responds").val('');
    var lang = $("#lang").val();
    var country = $("#country").val();

    var myData = 'id=' + id + '&lang=' + lang + '&country=' + country + '&OnUpdateLang=OnUpdateLang';
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);
        $("#responds").append(_ajax);
        $("#OnUpdateLang").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    } else {
        $("#lang").val('');
        $("#country").val('');//empty text field on successful
        $("#OnUpdateLang").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    }

}
function OnUpdateCat(id) {
    if ($("#lang").val() === '' || $("#categ").val() === '') {
        alert("Please,check if field submission are empty!");
        return false;
    }

    $("#OnUpdateCat").hide(); //hide submit button
    $("#LoadingImage").show(); //show loading image
    $("#responds").val('');
    var lang = $("#lang").val();
    var categ = $("#categ").val();

    var myData = 'id=' + id + '&lang=' + lang + '&categ=' + categ + '&OnUpdateCat=OnUpdateCat';
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);
        $("#responds").append(_ajax);
        $("#OnUpdateCat").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    } else {
        $("#OnUpdateCat").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    }

}

function OnDeleteMenu(id) {
    $("#Loading").show();
    var myData = 'id=' + id + '&OnDeleteMenu=OnDeleteMenu';
    $("#Loading").show(); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
}
function OnDeleteLang(id) {
    $("#Loading").show();
    var myData = 'id=' + id + '&OnDeleteLang=OnDeleteLang';
    $("#Loading").show(); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
}
function OnDeleteCat(id) {
    $("#Loading").show();
    var myData = 'id=' + id + '&OnDeleteCat=OnDeleteCat';
    $("#Loading").show(); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
}
function deleteMenu(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-trash fa-2x"></i> Delete Language');
    $(".collapsed").css('color', 'red');
    $("#update-box").html('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteMenu(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this menu, if yes click OK</div>');
}
function deleteCat(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-trash fa-2x"></i> Delete Language');
    $(".collapsed").css('color', 'red');
    $("#update-box").html('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteCat(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this category, if yes click OK</div>');
}

function deleteLang(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-trash fa-2x"></i> Delete Language');
    $(".collapsed").css('color', 'red');
    $("#update-box").html('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteLang(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this Language, if yes click OK</div>');
}

function updatesMenu(id, menu, lang, acts) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-pencil fa-2x"></i> Modify Language');
    $(".collapsed").css('color', 'green');

    var myData = 'id=' + id + '&menu=' + menu + '&lang=' + lang + '&acts=' + acts + '&settoUpdate=settoUpdate';
    $("#Loading").show(); //show loading image
    var url = "Tasks/Setlayouts.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
}

function updatesLang(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-pencil fa-2x"></i> Modify Language');
    $(".collapsed").css('color', 'green');
    var lang = $("#" + id + "lang").val();
    var country = $("#" + id + "country").val();
    //console.log(lang, country);
    var myData = "id=" + id + "&lang=" + lang + "&country=" + country + "&settoUpdateLang=settoUpdateLang";
    $("#Loading").show(); //show loading image
    var url = "Tasks/Setlayouts.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
}

function updatesCateg(id) {
    $("#update-box").show(); //show submit button
    $("#addnew-box").hide(); //hide loading image
    $(".collapsed").html('<i class="fa fa-pencil fa-2x"></i> Modify Category');
    $(".collapsed").css('color', 'green');
    var lang = $("#" + id + "lang").val();
    var categ = $("#" + id + "categ").val();

    var myData = "id=" + id + "&cat=" + categ + "&lang=" + lang + "&settoUpdateCat=settoUpdateCat";
    $("#Loading").show(); //show loading image
    var url = "Tasks/Setlayouts.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#update-box").append(_ajax);
        $("#Loading").hide(); //hide loading image
    } else {
        $("#Loading").hide(); //hide loading image
    }
}

$(document).ready(function () {
$("#responds").val('');
   
$("#logout").click(function (e) {
        e.preventDefault();
        var myData = 'Onlogout=Onlogout';
        var url = "../Includes/logout.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);

        if (_ajax != null) {
            //alert(_ajax);
            $("#logoutbox").append(_ajax);

        } else {
            $("#logoutbox").append(_ajax);
        }
    });

 

     $(".collapsedq").click(function (e) {
        e.preventDefault();
         $("#update-box").hide(); //show submit button
        $("#addnew-box").show(); //hide loading image
    }); 


});

function loadComments(){
    try{
    //var article  = $('#article').val();
   // $('#loading').show();
    var myData = 'loadComments=loadComments'; 
            $.ajax({
                url : 'Activity/appendComment.php',
                method: 'GET',
                data:myData,
                success: function( data ) {
            
                   
                    $('#commentsbox').html( data);
                    
                   // console.log(seconds);
                 //     if(beep=='0' && seconds == '59 mins'){
                 //        //
                 // $('#beep').html("<video controls autoplay='true'><source src=\"Activity/beep.mp3\"></video>");  
        
                 //    }else{
                 //        $('#beep').html('');
                 //    }
                },
                error: function( data ){
                    //flag = true;
                    //no_data = false;
                    $("#commentsbox").html('<div class="alert alert-danger"><strong><i class="fa fa-info">warning :</i></strong><button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Something went wrong, Please try again!</div>');
                }
            });
  //  setTimeout(loadComments, 1000); // Change image every 2 seconds
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
setInterval(loadComments, 1000);


setUpload=function(id,format){
     try{
     var myData = 'Setuploadid=' + id+'&Setuploadformat='+format;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      $("#Setformat").html(_ajax);
} }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
    
}


function SearchInTable() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}


   