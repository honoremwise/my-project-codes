var _URL = window.URL || window.webkitURL;
function _(x) {
    return document.getElementById(x);
}
function forms(name,field) {
    return document.forms[name][field];
}

function _values(x) {
    return _(x).value;
}
function _files(x) {
    return _(x).files[0];
}


exit = function(ex){
  $(ex).hide(); 
}
$('document').ready(function()
{
    $(".select-all").click(function ()
    {
        $('.chk-box').attr('checked', this.checked)
    });
        
    $(".chk-box").click(function()
    {
        if($(".chk-box").length == $(".chk-box:checked").length)
        {
            $(".select-all").attr("checked", "checked");
        }
        else
        {
            $(".select-all").removeAttr("checked");
        }
    });
});

function output(x,ev){
    return _(x).innerHTML=ev;
}
function loadingBtn(a){
    return output(a,'<br /><button type="button"class="btn btn-primary btn-block"> <i class="fa fa-refresh fa-1x"></i>  loading .....</button>');
}
function loadingImg(a){
    
     return output(a,'<center><img src="../img/book.gif" style="width:auto;margin-top:3px;"/></center>');
}
function is_Empty(a){
    return output(a,'<div class="alert alert-warning" onclick="exit(this)"><strong><i class="fa fa-info">Message :</i></strong><button type="button"  class="btn btn-danger pull-right close" onclick="exit(this)">close</button>Fill submission field, No thanks</div>'); 
}




 var entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;',
    '`': '&#x60;',
    '=': '&#x3D;'
  };

  function escapeHtml (string) {
    return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap (s) {
      return entityMap[s];
    });
  }

function htmlDecode(html) {
    var txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}

OnSavingArtcle=function(){
  $('#body_extend').val(htmlDecode(tinyMCE.get('body').getContent()));
SaveArticles();
}
OnUpdateArticle=function(){
  $('#body_extend').val(htmlDecode(tinyMCE.get('body').getContent()));
EditArticles();
}
OnAboutsbtn=function(){
  $('#body_extend').val(htmlDecode(tinyMCE.get('body').getContent()));
Aboutsbtn();
}
OnaddServices=function(){
  $('#body_extend').val(htmlDecode(tinyMCE.get('body').getContent()));
addServices();
}
OnupdateServices=function(id){
  $('#body_extend').val(htmlDecode(tinyMCE.get('body').getContent()));
updateServices(id);
}

function word_counts() {

    var word_count = _("summary").value;
    var words = _("summary").value.match(/\S+/g).length;
    if (words > 90) {
        // alert('ganza');
        // Split the string on first 200 words and rejoin on spaces
        var trimmed = _("summary").value.split(/\s+/, 90).join(" ");
        // Add a space at the end to keep new typing making new words
        _("summary").value = trimmed + " ";
        // $(word_count).val(trimmed + " ");
        $("#limits1").css('color', 'red');
        _("limits1").innerHTML = "typing of new words is no long continue! Limited to 30 words";
    }
    else {
        $('#display_count').text(words);
        $('#word_left').text(90 - words);
    }
};
function word_counts_hder() {

    var word_count = _("title").value;
    var words = _("title").value.match(/\S+/g).length;
    if (words > 30) {
        // alert('ganza');
        // Split the string on first 200 words and rejoin on spaces
        var trimmed = _("title").value.split(/\s+/, 30).join(" ");
        // Add a space at the end to keep new typing making new words
        _("title").value = trimmed + " ";
        $("#limits").css('color', 'red');
        _("limits").innerHTML = "typing of new words is no long continue! Limited to 30 words";
        // $(word_count).val(trimmed + " ");
    }
    else {
        $('#display_count_hder').text(words);
        $('#word_left_hder').text(30 - words);
    }
};

//function generated() {
//    try{
//    var type_id = _("type_id").value;
//   
//    
//    var myData = 'type_id=' + type_id + '&Ongenerated=Ongenerated';
//    var url = "Tasks/generater.php";
//    var metthod = 'GET';
//    //build a post data structure
//    var _ajax = ajaxJs(metthod, url, myData);
//    if (_ajax != null) {
//         $("#getgenerated_id").html(_ajax);
//      } else {
//    }
//    }catch ( e ) {
//			// IE8,9 Will throw exceptions on certain host objects #9897
//			return false;
//		}
//}



function OnDeleteArticles(id) {
    try{
    $("#dltbtn").hide();
    var myData = 'OnDeleteArticles=' + id;
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {

        $("#deleted").html(_ajax);

      setInterval(redirect('./?Blog'),2000);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}

function closed(url){
  return setInterval(redirect(url),1000); 
}
function redirect(url){
  return window.location=url;
}

function deletComment(ev){
    try{
     var myData = 'deletComment=' + ev;
    var url = "Tasks/Setoption.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
      
      $("#" + ev + "cmtsmsg").html(_ajax);
} else {
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}


function OnDeleteCmmt(id) {
    try{
     $("#"+id+"cmtsmsg").hide();
   $("#"+id+"cmtsmsg").html('Loading');
    var myData = 'OnDeleteCmmt=' + id;
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
       $("#"+id+"cmtsmsg").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
       // $("#"+id+"cmtsmsg").show();
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}
function approveCmments(id) {
    try{
   $("#"+id+"cmtsmsg").hide();
   $("#"+id+"cmtsmsg").html('Loading');
    var myData = 'approveCmments=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);

        //_("SetNewsUpdates").innerHTML=_ajax;
     $("#"+id+"cmtsmsg").html(_ajax);
        // return SetNewsUpdates();
        //console.log(_ajax);

    } else {
        //$("#dltbtn").show();
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}


function UnsetPublic(id) {
try{
    var myData = 'UnsetPublic=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'publishing').html(ajax.responseText);

        }
    };
    ajax.send(myData);
    }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}

function SetPublic(id) {
try{
    var myData = 'SetPublic=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure

    var ajax = ajaxObj(metthod, url);
    ajax.onreadystatechange = function () {
        if (ajaxReturn(ajax) == true) {

            $('#' + id + 'publishing').html(ajax.responseText);

         }
};
    ajax.send(myData);
    }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}


//setInterval(SetNewsUpdates,1000);
function efileIsLoaded(e) {
             $('#epreviewing').show();
            $("#ephotoname").css("color", "green");
            //$('#image_preview').css("display", "block");
            $('#epreviewing').attr('src', e.target.result);
            $('#epreviewing').attr('width', '250px');
            $('#epreviewing').attr('height', '230px');
    
};
function fileIsLoaded(e) {
             $('#previewing').show();
            $("#photoname").css("color", "green");
            //$('#image_preview').css("display", "block");
            $('#previewing').attr('src', e.target.result);
            $('#previewing').attr('width', '250px');
            $('#previewing').attr('height', '230px');
    
};
function fileAudioIsLoaded(e) {
             $('#Apreviewing').show();
            $("#audioname").css("color", "green");
            $('#Apreviewing').attr('src', e.target.result);
         
  };

function fileIsLoaded1(e) {
             $('#previewing1').show();
            $("#photonames").css("color", "green");
            //$('#image_preview').css("display", "block");
            $('#previewing1').attr('src', e.target.result);
            $('#previewing1').attr('width', '250px');
            $('#previewing1').attr('height', '230px');
              $("#uploadPhoto").show(); //show submit button
                $("#desc").show();
};

function efileIsLoaded(e) {
             $('#epreviewing').show();
            $("#ephotonames").css("color", "green");
            //$('#image_preview').css("display", "block");
            $('#epreviewing').attr('src', e.target.result);
            $('#epreviewing').attr('width', '250px');
            $('#epreviewing').attr('height', '230px');
            $("#euploadPhoto").show(); //show submit button
               
};

function fileAudioIsLoaded1(e) {
             $('#Apreviewing1').show();
            $("#audionames").css("color", "green");
            $('#Apreviewing1').attr('src', e.target.result);
         
  };
  function fileAudioIsLoaded2(e) {
             $('#eApreviewing').show();
            $("#eaudionames").css("color", "green");
            $('#eApreviewing').attr('src', e.target.result);
         
  };

choosePhoto=function() {
    try{
    $("#pmessage").empty(); // To remove the previous error message
    var img = new Image();
    var file = _('photoname').files[0];
         var imgwidth = 0;
         var imgheight = 0;
    
         var maxwidth = _('widths').value;
         var maxheight = _('heights').value;
    
    var imagefile = file.type;
  
    var match = ["image/jpeg", "image/png", "image/jpg", "image/ico"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]) || (imagefile == match[3]))) {
        $('#previewing').show();
         $("#pmessage").show(); //show submit button
        $('#previewing').attr('src', 'noimage.png');
        $("#pmessage").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg ,ico and png Images type allowed</span>");
        return false;
    } else {
             img.src = _URL.createObjectURL(file);
             img.onload = function() {
             imgwidth = this.width;
             imgheight = this.height;

        if(maxwidth <= imgwidth && maxheight <= imgheight){
             $("#pmessage").hide(); //show submit button
        var reader = new FileReader();
        reader.onload = fileIsLoaded;
        reader.readAsDataURL(_('photoname').files[0]);
             }else{
                $('#previewing').hide();
                 $("#pmessage").show(); //show submit button
                 $("#pmessage").text("Image size must be "+maxwidth+"X"+maxheight+" Or greater than "+maxwidth+"X"+maxheight);
             }
        }
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}
echoosePhoto=function() {
    try{
    $("#epmessage").empty(); // To remove the previous error message
    var img = new Image();
    var file = _('ephotoname').files[0];
         var imgwidth = 0;
         var imgheight = 0;
    
         var maxwidth = _('ewidths').value;
         var maxheight = _('eheights').value;
    
    var imagefile = file.type;
  
    var match = ["image/jpeg", "image/png", "image/jpg", "image/ico"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]) || (imagefile == match[3]))) {
        $('#epreviewing').show();
         $("#epmessage").show(); //show submit button
        $('#epreviewing').attr('src', 'noimage.png');
        $("#epmessage").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg ,ico and png Images type allowed</span>");
        return false;
    } else {
             img.src = _URL.createObjectURL(file);
             img.onload = function() {
             imgwidth = this.width;
             imgheight = this.height;

        if(maxwidth <= imgwidth && maxheight <= imgheight){
             $("#epmessage").hide(); //show submit button
        var reader = new FileReader();
        reader.onload = efileIsLoaded;
        reader.readAsDataURL(_('ephotoname').files[0]);
             }else{
                $('#epreviewing').hide();
                 $("#pmessage").show(); //show submit button
                 $("#pmessage").text("Image size must be "+maxwidth+"X"+maxheight+" Or greater than "+maxwidth+"X"+maxheight);
             }
        }
    }
        }catch ( e ) {
            // IE8,9 Will throw exceptions on certain host objects #9897
            return false;
        }
}
choosePhoto1=function(){
    try{
    $("#pmessage1").empty(); // To remove the previous error message
    var img = new Image();
    var file = _('photonames').files[0];
         var imgwidth = 0;
         var imgheight = 0;
    
         var maxwidth = _('widths1').value;
         var maxheight = _('heights1').value;
    
    var imagefile = file.type;
  
    var match = ["image/jpeg", "image/png", "image/jpg", "image/ico"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]) || (imagefile == match[3]))) {
        $('#previewing1').show();
         $("#pmessage1").show(); //show submit button
         $("#uploadPhoto").hide(); //show submit button
          $("#desc").hide();
        $('#previewing1').attr('src', 'noimage.png');
        $("#pmessage1").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg ,ico and png Images type allowed</span>");
        return false;
    } else {
             img.src = _URL.createObjectURL(file);
             img.onload = function() {
             imgwidth = this.width;
             imgheight = this.height;

        if(maxwidth <= imgwidth && maxheight <= imgheight){
             $("#pmessage1").hide(); //show submit button
        var reader = new FileReader();
        reader.onload = fileIsLoaded1;
        reader.readAsDataURL(_('photonames').files[0]);
        changePic();
      
             }else{
                $('#previewing1').hide();
                 $("#pmessage1").show(); //show submit button
                 $("#uploadPhoto").hide(); //show submit button
                 $("#desc").hide(); //show submit button
                 
                 $("#pmessage1").text("Image size must be "+maxwidth+"X"+maxheight+" Or greater than "+maxwidth+"X"+maxheight);
             }
        }
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		} 
}

choosePhoto_edit=function(){
    try{
    $("#epmessage").empty(); // To remove the previous error message
    var img = new Image();
    var file = _('ephotonames').files[0];
         var imgwidth = 0;
         var imgheight = 0;
    
         var maxwidth = _('widthz').value;
         var maxheight = _('heightz').value;
    
    var imagefile = file.type;
  
    var match = ["image/jpeg", "image/png", "image/jpg", "image/ico"];

    if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]) || (imagefile == match[3]))) {
        $('#epreviewing').show();
         $("#epmessage").show(); //show submit button
           $("#euploadPhoto").hide(); //show submit button
        $('#epreviewing').attr('src', 'noimage.png');
        $("#epmessage").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg ,ico and png Images type allowed</span>");
        return false;
    } else {
             img.src = _URL.createObjectURL(file);
             img.onload = function() {
             imgwidth = this.width;
             imgheight = this.height;

        if(maxwidth <= imgwidth && maxheight <= imgheight){
             $("#epmessage").hide(); //show submit button
        var reader = new FileReader();
        reader.onload = efileIsLoaded;
        reader.readAsDataURL(_('ephotonames').files[0]);
      //  changePic();
      
             }else{
                $('#epreviewing').hide();
                 $("#epmessage").show(); //show submit button
                 $("#euploadPhoto").hide(); //show submit button
                
                 $("#epmessage").text("Image size must be "+maxwidth+"X"+maxheight+" Or greater than "+maxwidth+"X"+maxheight);
             }
        }
    }
        }catch ( e ) {
      // IE8,9 Will throw exceptions on certain host objects #9897
      return false;
    } 
}



chooseAudio_edit=function() {
    try{
    $("#eAmessage").empty(); // To remove the previous error message
   
    var file = _('eaudionames').files[0];
       
    var audiofile = file.type;
  
    var match = ["audio/mp3"];

    if (audiofile != match[0]) {
        $('#eApreviewing').hide();
         $("#eAmessage").show(); //show submit button
          $("#euploadAudio").hide(); //show submit button
            $("#edesc").hide(); //show submit button
                 
        $('#eApreviewing').attr('poster','../img/audio.png');
        $("#eAmessage").html("<p id='error'>Please Select A valid Audio File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only MP3 audio type allowed</span>");
        return false;
    } else {
             
        $("#eAmessage").hide(); //show submit button
        var reader = new FileReader();
        reader.onload = fileAudioIsLoaded2;
        reader.readAsDataURL(_('eaudionames').files[0]);
         $("#euploadAudio").show(); //show submit button
          $("#edesc").show(); //show submit button
                 
        return true;    
        }
     }catch ( e ) {
      // IE8,9 Will throw exceptions on certain host objects #9897
      return false;
    }
}

chooseAudio1=function() {
    try{
    $("#Amessage1").empty(); // To remove the previous error message
   
    var file = _('audionames').files[0];
       
    var audiofile = file.type;
  
    var match = ["audio/mp3"];

    if (audiofile != match[0]) {
        $('#Apreviewing1').hide();
         $("#Amessage1").show(); //show submit button
          $("#uploadAudio").hide(); //show submit button
            $("#adesc").hide(); //show submit button
                $("#artist").hide();   
        $('#Apreviewing1').attr('poster','../img/audio.png');
        $("#Amessage1").html("<p id='error'>Please Select A valid Audio File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only MP3 audio type allowed</span>");
        return false;
    } else {
             
        $("#Amessage1").hide(); //show submit button
        var reader = new FileReader();
        reader.onload = fileAudioIsLoaded1;
        reader.readAsDataURL(_('audionames').files[0]);
         $("#uploadAudio").show(); //show submit button
          $("#adesc").show(); //show submit button
                $("#artist").show();   
        return true;    
        }
     }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}
// function formData(file){
//      var file=['photonames','audionames'];
//    var fd = new FormData();
//       for(var i=0; i<file.length; i++){
//            var valuess =_files(file[i]); 
//           //fd.append(file[i], valuess);
//       
//         
//        }
//}

function uploadfile(metthod, url) {
    try{
        
    var formData = new FormData();
    formData.append("photoname", document.getElementById('photoname').files[0]);
    formData.append("audioname", document.getElementById('audioname').files[0]);
    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler, false);
    aj.addEventListener("load", completeHandler, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
        
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
           return true;
       }else{
        return false;
       }
    };
        
 aj.send(formData);
       
 }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}

function uploadPhoto(){
   try{
   var formData  = new FormData();
    var url = "Tasks/Uploaddata.php";
    var metthod = 'POST';
   formData.append("photo", document.getElementById('photonames').files[0]);
   formData.append("refers_id",$("#refers_id").val());
    formData.append("desc", $("#desc").val());
   formData.append("uploadPhoto",'uploadPhoto');
   var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler1, false);
    aj.addEventListener("load", completeHandler1, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
        
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
          return toasterBottom('Photo uploaded and saved!','success');
      }else{
       return false;
      }
   };
        
aj.send(formData);
      
}catch ( e ) { return false; }
}

function euploadPhoto(){
   try{
   var formData  = new FormData();
    var url = "Tasks/Uploaddata.php";
    var metthod = 'POST';
   formData.append("photo", document.getElementById('ephotonames').files[0]);
    formData.append("desc", $("#descs").val());
   formData.append("edtuploadPhoto",$("#ids").val());
   var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler2, false);
    aj.addEventListener("load", completeHandler2, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
        
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
          return toasterBottom('Photo uploaded and saved!','success');
      }else{
       return false;
      }
   };
        
aj.send(formData);
      
}catch ( e ) { return false; }
}



function uploadAudio(){
   try{
   var formData  = new FormData();
    var url = "Tasks/Uploaddata.php";
    var metthod = 'POST';
   formData.append("audio", document.getElementById('audionames').files[0]);
   formData.append("refers_id",$("#refers_id").val());
    formData.append("adesc", $("#adesc").val());
       formData.append("artist", $("#artist").val());
   formData.append("uploadAudio",'uploadAudio');
   var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler, false);
    aj.addEventListener("load", completeHandler, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
        
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
          return toasterBottom('Audio uploaded and saved!','success');
      }else{
       return false;
      }
   };
        
aj.send(formData);
      
}catch ( e ) { return false; }
}


function euploadAudio(){
   try{
   var formData  = new FormData();
    var url = "Tasks/Uploaddata.php";
    var metthod = 'POST';
   formData.append("audio", document.getElementById('eaudionames').files[0]);
    formData.append("adesc", $("#eadesc").val());
    formData.append("eartist", $("#eartist").val());
   formData.append("edtuploadAudio",$("#eids").val());
   var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress", progressHandler3, false);
    aj.addEventListener("load", completeHandler3, false);
    aj.addEventListener("error", errorHandler, false);
    aj.addEventListener("abort", abortHandler, false);
    aj.open(metthod, url);
        
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
          loadaudio();
          return toasterBottom('Audio uploaded and saved!','success');
      }else{
       return false;
      }
   };
        
aj.send(formData);
      
}catch ( e ) { return false; }
}


function toasterTop(showtext,toast){
  
    $("#snackbarTop").html(showtext);
    var x = document.getElementById("snackbarTop");
         if(toast=='danger'){
        x.style.background='#a83131'; /* Black background color */
    }else if(toast=='success'){
         x.style.background='#04a2de'; /* Black background color */
    }else{
      x.style.background='#333'; /* Black background color */
    }
 
    x.className = "show"; // Add the "show" class to DIV
       // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
function toasterBottom(showtext,toast){
  
    $("#snackbarBottom").html(showtext);
    var x = document.getElementById("snackbarBottom");
         if(toast=='danger'){
        x.style.background='#a83131'; /* Black background color */
    }else if(toast=='success'){
         x.style.background='#04a2de'; /* Black background color */
    }else{
      x.style.background='#333'; /* Black background color */
    }
 
    x.className = "show"; // Add the "show" class to DIV
       // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

function completeHandler2(event){
    //document.getElementById("message").innerHTML = 'File Uploaded successfully';
    $("#eprogress-barimg").hide();
    $("#euploadPhoto").hide();
    $("#eprogress-barimg").hide();
    $("#eperctage").hide();
    $("#descs").hide();
     return loadphoto();
    
}

          function progressHandler2(event){
               $("#euploadPhoto").hide();
         $("#eprogress-barimg").show();
        var percent = (event.loaded / event.total) * 100;
        $('#eprogress-barimg').css('width', Math.round(percent) + '%');
        _("eperctage").innerHTML = Math.round(percent) + "% complete ....";
        if(percent == 100){
          $("#ephotonames").val('');
              return loadphoto();
        }
    }


     function completeHandler(event){
   //document.getElementById("message").innerHTML = 'File Uploaded successfully';
    $("#progress-baraudio").hide();
    $("#uploadAudio").hide();
    $("#progress-baraudio").hide();
    $("#aperctage").hide();
    $("#adesc").val('');
    $("#adesc").hide();
      $("#artist").val('');
     $("#artist").hide();   
     return loadaudio();
}

          function progressHandler(event){
        $("#uploadAudio").hide();
         $("#progress-baraudio").show();
        var percent = (event.loaded / event.total) * 100;
        $('#progress-baraudio').css('width', Math.round(percent) + '%');
        _("aperctage").innerHTML = Math.round(percent) + "% complete ....";
        if(percent == 100){
          $('#Apreviewing1').attr('src', '../img/photo.png');
          $("#audionames").val('');
             return loadaudio();
           }
  }

  function completeHandler3(event){
   //document.getElementById("message").innerHTML = 'File Uploaded successfully';
    $("#eprogress-baraudio").hide();
    $("#euploadAudio").hide();
    $("#eprogress-baraudio").hide();
    $("#eaperctage").hide();
    $("#eadesc").val('');
    $("#eadesc").hide();
      return loadaudio();
}

          function progressHandler3(event){
        $("#euploadAudio").hide();
         $("#eprogress-baraudio").show();
        var percent = (event.loaded / event.total) * 100;
        $('#eprogress-baraudio').css('width', Math.round(percent) + '%');
        _("eaperctage").innerHTML = Math.round(percent) + "% complete ....";
        if(percent == 100){
          $('#eApreviewing').attr('src', '../img/photo.png');
          $("#eaudionames").val('');
             return loadaudio();

           }
  }



    function completeHandler1(event){
    //document.getElementById("message").innerHTML = 'File Uploaded successfully';
    $("#progress-barimg").hide();
    $("#uploadPhoto").hide();
    $("#progress-barimg").hide();
    $("#perctage").hide();
    $("#desc").val('');
    $("#desc").hide();
     return loadphoto();
    
}

          function progressHandler1(event){
               $("#uploadPhoto").hide();
         $("#progress-barimg").show();
        var percent = (event.loaded / event.total) * 100;
        $('#progress-barimg').css('width', Math.round(percent) + '%');
        _("perctage").innerHTML = Math.round(percent) + "% complete ....";
        if(percent == 100){
          $('#previewing1').attr('src', '../img/photo.png');
          $("#photonames").val('');
              return loadphoto();
        }
    }

function errorHandler(event) {
   // document.getElementById("message").innerHTML = "Upload failed";


}
function abortHandler(event) {
    //document.getElementById("message").innerHTML = "Upload aborted";
}

function loadphoto(){
      try{
      var ids= $("#refers_id").val();
      var myData = 'loadphoto=' + ids;
      var url = "Tasks/Uploaddata.php";
      var metthod = 'GET';
      //build a post data structure
      var _ajax = ajaxJs(metthod, url, myData);
      if (_ajax != null){
          $("#loadphoto").html(_ajax);
       
        }else{
          $("#loadphoto").show();
        }  
    }catch ( e ) {
        // IE8,9 Will throw exceptions on certain host objects #9897
        return false;
      }
  
}

function loadaudio(){
      try{
      var ids= $("#refers_id").val();
      var myData = 'loadaudio=' + ids;
      var url = "Tasks/Uploaddata.php";
      var metthod = 'GET';
      //build a post data structure
      var _ajax = ajaxJs(metthod, url, myData);
      if (_ajax != null){
          $("#loadaudio").html(_ajax);
       
        }else{
          $("#loadaudio").show();
        }  
    }catch ( e ) {
        // IE8,9 Will throw exceptions on certain host objects #9897
        return false;
      }
  
}


addEventListener("load",function(){
    loadphoto();
    loadaudio();
});

function deletefile(id,type){
 try{
      var myData = 'deletephoto='+ id+'&type='+type;
      var url = "Tasks/DeleteData.php";
      var metthod = 'POST';
      //build a post data structure
      var _ajax = ajaxJs(metthod, url, myData);
      if (_ajax != null){
         toasterBottom('Photo removed successfully!','danger');
         loadphoto();
         loadaudio();
       
        }else{
          loadaudio();
         loadphoto();
        }  
    }catch ( e ) {
        // IE8,9 Will throw exceptions on certain host objects #9897
        return false;
      }
}
function setphotoeditor(id){
 try{
      var myData = 'setphotoeditor='+ id;
      var url = "Tasks/Setoption.php";
      var metthod = 'GET';
      //build a post data structure
      var _ajax = ajaxJs(metthod, url, myData);
      if (_ajax != null){
         $("#getoption").html(_ajax);
       
        }else{
         return loadphoto();
        }  
    }catch ( e ) {
        // IE8,9 Will throw exceptions on certain host objects #9897
        return false;
      }
}

function setaudioeditor(id){
 try{
      var myData = 'setaudioeditor='+ id;
      var url = "Tasks/Setoption.php";
      var metthod = 'GET';
      //build a post data structure
      var _ajax = ajaxJs(metthod, url, myData);
      if (_ajax != null){
         $("#getoptions").html(_ajax);
       
        }else{
         return loadaudio();
        }  
    }catch ( e ) {
        // IE8,9 Will throw exceptions on certain host objects #9897
        return false;
      }
}

function EditArticles() {
    try{

   if ($("#Etitle").val() === '' || $("#Esummary").val() === '' || $("#body").val() === '' || $("#Ecategory").val() === 'Choose Category') {
       alert("Please,check if field submission are empty !");

       $("#_displaymsg").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
       return false;
   } else {
        $("#_displaymsg").html('');

        $("#EditArticles").hide(); //hide submit button     
        var title    = $("#Etitle").val();
        var summary  = $("#Esummary").val();
        var body     = $("#body_extend").val();
        var refers_id = $("#refers_id").val();
        var category = $("#Ecategory").val();
    
       // alert(sld+ads+pub);
        var myData = 'refers_id='+refers_id+'&title=' + title + '&summary=' + summary + '&body=' + body + '&category=' + category + '&OnEditArticle=OnEditArticle';
        var url = "Tasks/Updatedata.php";
        var metthod = 'POST';
       var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
               $("#_displaymsg").append(_ajax);
               $("#Etitle").val('');
               $("#Esummary").val(''); 
               $("#Ecategory").val('');
               closed('./?Blog');
                toasterTop(_ajax,'success');

              
         }else {

            $("#EditArticles").show(); //show submit button
            $("#_displaymsg").append('Data not recorded');
        }

   }

        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}



function OnRmvTopublics(id) {
    try{
    $("#dltbtn").hide();
    var myData = 'UnsetPublic=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null){
        $("#deleted").html(_ajax);
        setInterval(redirect('./?Blog'),2000);
      }else{
        $("#dltbtn").show();
         setInterval(redirect('./?Blog'),2000);
    }
  }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}
function OnSetTopublics(id) {
    try{
    $("#dltbtn").hide();
    var myData = 'SetPublic=' + id;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        $("#deleted").html(_ajax);
          setInterval(redirect('./?Blog'),2000);

    } else {
        $("#dltbtn").show();
    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}


function DeleteArticle() {
   try{
  var html;
     var input= $("#postid").val();
     alert(input);
     var image= $("#image").val();
     var title= $("#title").val();
     var summary= $("#summary").val();
     var data = input+',"'+image+'"';
         html+='<div class="panel-body" style="z-index:999999;"><div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">';
             html+=' <div class="modal-dialog"><div class="modal-content">';
                   html+='<div class="modal-header">';
                                           html+=' <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button><h4 class="modal-title" id="myModalLabel">Remove a Blog</h4> </div>';
                                           html+=' <div class="modal-body" id="deleted">Do you want to set on public this articles<span class="btn btn-info" id="articleid">#'+input+'</span>';
                                           html+='<br /><span>'+title+'</span>';
                                           html+='<br /><span><img class="img-responsive img-thumbnail" src="../upload/img_posts/'+ image +'" /></span>';
                                          html+='<br /><span>'+summary+'</span>';
                                           html+='</div>';
                                        
                                          html+='<div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload()">Close</button>';
                                         html+='<button type="button" class="btn btn-danger" id=\'dltbtn\' onclick=\'OnDeleteArticle('+data+')\'>Yes, Delete</button>';
                            html+=' </div> </div> </div></div> </div>';
           var box=input+"Setdeletemsg";
           output(box,html);

        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}


function getArticle(){
  try{
   
    var myData = 'getArticle=getArticle';
    var url = "Tasks/generater.php";
    var metthod = 'GET';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
         return _ajax;
      }
        }catch ( e ) {
      // IE8,9 Will throw exceptions on certain host objects #9897
      return false;
    }
}

function SaveArticles() {
    try{

    if ($("#title").val() === '' || $("#summary").val() === '' || $("#body").val() === '' || $("#audioname").val() === '' || $("#photoname").val() === '' || $("#category").val() === 'Choose Category') {
        alert("Please,check if field submission are empty !");

        $("#displaymsg").html('<div class="alert alert-danger"><strong><i class="fa fa-info"> error Message :</i></strong> <button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Please,check if box submission are not empty or photo is choosen!</div>');
        return false;
    } else {
        $("#displaymsg").html('');

        $("#SaveArticle").hide(); //hide submit button     
        var title    = $("#title").val();
        var summary  = $("#summary").val();
        var body     = $("#body_extend").val();
        var category = $("#category").val();
    
       // alert(sld+ads+pub);
        var myData = 'title=' + title + '&summary=' + summary + '&body=' + body + '&category=' + category + '&OnaddArticle=OnaddArticle';
        
        var url = "Tasks/Adddata.php";
        var metthod = 'POST';
        //build a post data structure

        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {
            closed('./?Blog&editArticle='+getArticle());
            $("#displaymsg").append(_ajax);
           $("#title").val('');
           $("#summary").val(''); 
           $("#category").val('');

        } else {

            $("#SaveArticle").show(); //show submit button
            //$("#Loadingbtn").hide(); //hide loading image
        }



    }
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}



function project()
{
    var file = document.getElementById("photoname").files[0];
    var project = _("project").value;
    var web = _("web").value;
    var contact = _("contact").value;
    var address = _("address").value;
    var location = _("location").value;
    var logo = _("logo").value;
    var description = _("description").value;
    
    var id= _("id").value;
    
//alert(file.name);
if(project=="" || web=="" || contact=="" || address=="" || location==""){
    alert('check if all field are not required');
document.getElementById("editStatuss").innerHTML = "<br /><h3 class='col-md-12 col-lg-12alert alert-danger'>check if all field are not required</h3><br />";
}else{
    var fd = new FormData();
    fd.append("projectlogo",file);
    fd.append("logo",logo);
    fd.append("project",project);
    fd.append("web",web);
    fd.append("contact",contact);
    fd.append("address",address);
    fd.append("location",location);
     fd.append("description",description);
    fd.append("id",id);
    fd.append("onSaveproject",'onSaveproject');
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress",progressHandler,false);
    aj.addEventListener("load",completeHandler,false);
    aj.addEventListener("error",errorHandler,false);
    aj.addEventListener("abort",abortHandler,false);
    
    aj.open(metthod,url);
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
               _("editStatuss").innerHTML = aj.responseText;
       }else{
        return false;
       }
    };
        
 aj.send(fd);
    }  
    
}

editPubAnncs = function(id)
{
    var file = document.getElementById("ephotoname").files[0];
    var title = _("etitle").value;
    var pubcAnnounce = _("epubcAnnounce").value;

if(title=="" || pubcAnnounce==""){
    alert('check if all field are not required');
    document.getElementById("eeditStatuss").innerHTML = "<br /><h3 class='col-md-12 col-lg-12alert alert-danger'>check if all field are not required</h3><br />";
}else{
    var fd = new FormData();
    fd.append("photo",file);
    fd.append("title",title);
    fd.append("id",id);
     fd.append("logo",logo);
    fd.append("pubcAnnounce",pubcAnnounce);
    fd.append("oneditpubAnnounce",'oneditpubAnnounce');
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress",progressHandler,false);
    aj.addEventListener("load",completeHandler,false);
    aj.addEventListener("error",errorHandler,false);
    aj.addEventListener("abort",abortHandler,false);
    
    aj.open(metthod,url);
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
               _("eeditStatuss").innerHTML = aj.responseText;
       }else{
        return false;
       }
    };
        
 aj.send(fd);
    }  
    
}

addPubAnncs = function()
{
    var file = document.getElementById("photoname").files[0];
    var title = _("title").value;
    var pubcAnnounce = _("pubcAnnounce").value;

if(title=="" || pubcAnnounce==""){
    alert('check if all field are not required');
    document.getElementById("editStatuss").innerHTML = "<br /><h3 class='col-md-12 col-lg-12alert alert-danger'>check if all field are not required</h3><br />";
}else{
    var fd = new FormData();
    fd.append("photo",file);
    fd.append("title",title);
    fd.append("pubcAnnounce",pubcAnnounce);
    fd.append("onSavepubAnnounce",'onSavepubAnnounce');
    var url = "Tasks/Adddata.php";
    var metthod = 'POST';
    var aj = new XMLHttpRequest();
    aj.upload.addEventListener("progress",progressHandler,false);
    aj.addEventListener("load",completeHandler,false);
    aj.addEventListener("error",errorHandler,false);
    aj.addEventListener("abort",abortHandler,false);
    
    aj.open(metthod,url);
    aj.onreadystatechange = function () {
        if (ajaxReturn(aj) == true) {
               _("editStatuss").innerHTML = aj.responseText;
       }else{
        return false;
       }
    };
        
 aj.send(fd);
    }  
    
}

function changestudentpass(){
  var user = _("user").value;
    var pass = _("pass").value
    var pass1 = _("pass1").value;
    var status = _("status");
if(pass=="" && pass1==""){
    alert('fill empty field');
}else{
    if(pass != pass1){
        status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-times'></i></button>Your password fields do not match!<a href='#' class='alert-link'></a></div>";
    } else {
        status.innerHTML = '<center><img src="img/status1.gif" style="width:20%;margin-top:3px;"/></center>';
            var url = "Tasks/Updatedata.php";
            var metthod = 'POST';
        var ajax = ajaxObj(metthod, url);
        ajax.onreadystatechange = function() {
            if(ajaxReturn(ajax) == true) {
                if(ajax.responseText != " "){
                    status.innerHTML = ajax.responseText;
                    
                } 
                
            }
        };
        ajax.send("user="+user+"&pass="+pass+"&changestudentpass=changestudentpass");
    }
}
}
function changeuser(){
	var fname = _("fname").value;
	var lname = _("lname").value;
	var gender = _("gender").value;
	var email = _("email").value;
	var user = _("user").value;
	var pass = _("pass").value
    var pass1 = _("pass1").value;

	var status = _("status");
	
	if(fname == ""){
		
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please! Fill out your first name.<a href='#' class='alert-link'></a></div><br />";
		
	}
    	if(gender == ""){
		
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please! Fill out your gender.<a href='#' class='alert-link'></a></div><br />";
		
	}
	  if(lname == "")
	{
			status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please! Fill out your last name.<a href='#' class='alert-link'></a></div><br />";
	}
	if(email== "")
	{
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please fill out your Email Address.!<a href='#' class='alert-link'></a></div>";
		
	}
	if(user == "")
	{
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please fill out your Password<a href='#' class='alert-link'></a></div><br />";
		
	} if(pass  == "")
	{
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismi ss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please fill out your new Password.<a href='#' class='alert-link'></a></div><br />";
		
		
	}
	if(pass1 == "")
	{
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-question'></i></button> Please fill out your confirm Password.<a href='#' class='alert-link'></a></div><br />";

	}
	if(pass != pass1){
		status.innerHTML = "<br /><div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>  <button type='button' class='btn btn-warning btn-circle'><i class='fa fa-times'></i></button>Your password fields do not match!<a href='#' class='alert-link'></a></div>";
	
	// } else if( _("terms").style.display == "none"){
		// status.innerHTML = "Please view the terms of use";
	} else {
		//_("signupbtn").style.display = "none";
		status.innerHTML = '<center><img src="img/status1.gif" style="width:20%;margin-top:3px;"/></center>';
            var url = "Tasks/Updatedata.php";
            var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
	            if(ajax.responseText != " "){
					status.innerHTML = ajax.responseText;
					
				} 
				
	        }
        };
        ajax.send("fname="+fname+"&lname="+lname+"&email="+email+"&user="+user+"&pass="+pass+"&gender="+gender+"&changeusers=changeusers");
	}
}


Aboutsbtn = function(){
           $("#displaymsg").show();
           $("#displaymsg").html('');
           
           var body = tinyMCE.activeEditor.getContent();
    
           if(body==""){
               alert('Fill submission field, No thanks');
                $("#displaymsg").html('<div class="alert alert-warning" onclick="exit(this)">strong><i class="fa fa-info">Message :</i></strong><button type="button"  class="btn btn-danger pull-right close" onclick="exit(this)">close</button>Fill submission field, No thanks</div>');
               
           }else {
               var bdy= $("#body_extend").val();
	          $("#loadingbtn").show();
              $("#Aboutsbtn").hide();
            var url = "Tasks/Updatedata.php";
            var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
	            if(ajax.responseText != " "){
					$("#displaymsg").html( ajax.responseText );
					$("#loadingbtn").hide();
                    $("#Aboutsbtn").show();
				} 
				
	        }
        };
        ajax.send("body="+bdy+"&saveAbouts=saveAbouts");
	}

}

addServices = function(){
           $("#displaymsg").show();
           $("#displaymsg").html('');
           
           var body = tinyMCE.activeEditor.getContent();
           if(body==""){
               alert('Fill submission field, No thanks');
                $("#displaymsg").html('<div class="alert alert-warning" onclick="exit(this)">strong><i class="fa fa-info">Message :</i></strong><button type="button"  class="btn btn-danger pull-right close" onclick="exit(this)">close</button>Fill submission field, No thanks</div>');
               
           }else {
               var bdy= $("#body_extend").val();
	          $("#loadingbtn").show();
              $("#Servicebtn").hide();
            var url = "Tasks/Adddata.php";
            var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
	            if(ajax.responseText != " "){
					$("#displaymsg").html( ajax.responseText );
                     closed('./?Services');
					$("#loadingbtn").hide();
                    $("#Servicebtn").show();
				} 
				
	        }
        };
        ajax.send("body="+bdy+"&addService=addService");
	}

}



updateServices = function(id){
           $("#displaymsg").show();
           $("#displaymsg").html('');
           
           var body = tinyMCE.activeEditor.getContent();
           if(body==""){
               alert('Fill submission field, No thanks');
                $("#displaymsg").html('<div class="alert alert-warning" onclick="exit(this)">strong><i class="fa fa-info">Message :</i></strong><button type="button"  class="btn btn-danger pull-right close" onclick="exit(this)">close</button>Fill submission field, No thanks</div>');
               
           }else {
               var bdy= $("#body_extend").val();
	          $("#loadingbtn").show();
              $("#Servicebtn").hide();
            var url = "Tasks/Updatedata.php";
            var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
	            if(ajax.responseText != " "){
					$("#displaymsg").html( ajax.responseText );
                     closed('./?Services');
					$("#loadingbtn").hide();
                    $("#Servicebtn").show();
				} 
				
	        }
        };
        ajax.send("body="+bdy+"&updateService="+id);
	}

}

function OnUpdateCat(id) {
    if ($("#lang").val() === '' || $("#categ").val() === '') {
        alert("Please,check if field submission are empty!");
        return false;
    }

    $("#OnUpdateCat").hide(); //hide submit button
    $("#LoadingImage").show(); //show loading image
    $("#responds").val('');
    var lang = $("#lang").val();
    var categ = $("#categ").val();

    var myData = 'id=' + id + '&lang=' + lang + '&categ=' + categ + '&OnUpdateCat=OnUpdateCat';
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);
    if (_ajax != null) {
        //alert(_ajax);
        $("#responds").append(_ajax);
        $("#OnUpdateCat").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    } else {
        $("#OnUpdateCat").show(); //show submit button
        $("#LoadingImage").hide(); //hide loading image
    }

} 
function OnrmvServicesbtn(id){
  var url = "Tasks/DeleteData.php";
        var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
         
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
               closed('./?Services');
              }
            
            };
        
        ajax.send("OnrmvServices="+id);   
}
function addcat()
{
	
    var cat= _("cat").value;
    var cteg=escapeHtml(cat);
	if(cat=="")
    {
      alert('Fill submission field, No thanks');
     is_Empty('displaymsg'); 
    }else{
         loadingImg('displaymsg');
        var url = "Tasks/Adddata.php";
        var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
         
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
                output('displaymsg',ajax.responseText); 
              }
            
            };
        
        ajax.send("cat="+cteg+"&savecat=savecat");
    }
}

function Editcat(catid)
{
	
    var cat= _("_cat").value;
    var cteg=escapeHtml(cat);
	if(cat=="")
    {
      alert('Fill submission field, No thanks');
     is_Empty('output'); 
    }else{
         loadingImg("output");
        var url = "Tasks/Updatedata.php";
        var metthod = 'POST';
		var ajax = ajaxObj(metthod, url);
         
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
                output('output',ajax.responseText);   
              }
            
            };
        
        ajax.send('cat='+cteg+'&catid='+catid+'&editcat=editcat');
    }
}

function changecat(catid){
var myData = 'id=' + catid + '&EditPubAnounc=EditPubAnounc';
     loadingImg('output');
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {

        $("#output").html(_ajax); 
     
    } else {
       return false;
    }
}

function hideannance(id){
var hideannance=$('#hideannance'+id).data('id');
var myData = 'hideannance='+hideannance;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {

        $("#output").html(_ajax); 
     
    } else {
       return false;
    }
}
function hidepubannance(id){
var hidepubannance=$('#hidepubannance'+id).data('id');
var myData = 'hidepubannance='+hidepubannance;
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {

        $("#output").html(_ajax); 
     
    } else {
       return false;
    }
}

function readCont(catid,name,email,details,datea){
  var html="";
  var myData = 'id=' + catid + '&makeReadble=makeReadble';
     loadingImg('output');
    var url = "Tasks/Updatedata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {

        $("#output").html(_ajax); 
     
    } else {
       return false;
    }

 
}

function OnDeleteCat(id) {
   
    var myData = 'id=' + id + '&OnDeleteCat=OnDeleteCat';
    $("#output").html('<br /><button type="button"class="btn btn-primary btn-block"> <i class="fa fa-refresh fa-1x"></i>  loading .....</button>'); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#output").html(_ajax);
     
    } else {
       return false;
    }
}

function OnDeleteCont(id) {
   
    var myData = 'id=' + id + '&OnDeleteCont=OnDeleteCont';
    $("#output").html('<br /><button type="button"class="btn btn-primary btn-block"> <i class="fa fa-refresh fa-1x"></i>  loading .....</button>'); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#output").html(_ajax);
     
    } else {
       return false;
    }
}

function OnDelete_allCont() {
   
    var myData = 'OnDelete_allCont=OnDelete_allCont';
    $("#output").html(''); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#output").html(_ajax);
     
    } else {
       return false;
    }
}
        function announce_Type(){
              var type = $("#announce_type").val();
              if(type=="Send To all"){
                 getAllstudent();
              }else if(type=="By Level"){
                 ByLevel();
              }else{
                return getchoosenstudent();
              }
        }
        function getAllstudent()
        {     var myData = 'getAllstudent=getAllstudent';
             var url = "Tasks/generater.php";
                var metthod = 'POST';
                //build a post data structure
                var _ajax = ajaxJs(metthod, url, myData);

                if (_ajax != null) {
                    //alert(_ajax);
                    $("#Announce_typemsg").val(_ajax);
                 
                } else {
                   return false;
                }
        }


addStudentAnnounce = function()
{
    var title = _("title").value;
    var pubcAnnounce = _("pubcAnnounce").value;
    var st_codes =_("Announce_typemsg").value; 
    var send_mode =_("send_mode").value;

    if(title=="" || pubcAnnounce=="" || send_mode=="Choose Send mode"){
        alert('check if all field are not required or [hoose Send mode] not choosen');
        document.getElementById("Statuss").innerHTML = "<br /><h3 class='col-md-12 col-lg-12alert alert-danger'>check if all field are not required</h3><br />";
    }else{
      var myData = 'st_codes='+st_codes +'&title='+title+'&pubcAnnounce='+pubcAnnounce+'&send_mode='+send_mode+'&addStudentAnnounce=addStudentAnnounce';
    var url = "Tasks/Adddata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {

        $("#Statuss").html(_ajax); 
     
    } else {
       return false;
    }

    }
}
  function getchoosenstudent()
        {    
             var myData = 'getchoosenstudent=getchoosenstudent';
              var metthod = 'POST';
               var url = "Tasks/Adddata.php";
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {

        $("#choosenstudents").html(_ajax); 
     
    } else {
       return false;
    }
                   
  }
 function ByLevel(){
     $("#choosenstudents").html('<table><tr><td>  <option>level 1</option><option>level 2</option><option>level 3</option><option>level 4</option><option>level 5</option><option>level 6</option><td></tr></table>'); 
 }
 
  function sendChoosen(){
     //var chk= document.getElementsByTagName('chk').value;
     var chk= $(".chk-box:checked").serialize();
     var ids = [];
$('.chk-box:checked').each(function(i, e) {
    ids.push($(this).val());
});

$("#Announce_typemsg").val(ids.join()); 

    // var myData ='chk='+chk+'&chooseStudent=chooseStudent';
    //           var metthod = 'POST';
    //            var url = "Tasks/Updatedata.php";
    // //build a post data structure
    // var _ajax = ajaxJs(metthod, url, myData);
    //
    // if(_ajax != null){
    //      $("#Announce_typemsg").val(_ajax);
    //
    //   } else {
    //    return false;
    // }

    
  }
function OndeleteSdents(id){
    var myData = 'OndeleteSdents='+id;
    $("#output").html(''); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#output").html(_ajax);
     
    } else {
       return false;
    }
}
function OndeletestudentsAnnouce(sid,nid){
    var myData = 'sid='+sid+'&nid='+nid+'&OndeletestudentsAnnouce=OndeletestudentsAnnouce';
    $("#output").html(''); //show loading image
    var url = "Tasks/DeleteData.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#output").html(_ajax);
     
    } else {
       return false;
    }
}
function addlevel(){
    if($("#levels").val()=="Select Level"){
alert('please, choose level befor submit!');
    }else{
    var myData = 'student='+$("#student").val()+'&levels='+$("#levels").val()+'&addlevel=addlevel';
    $("#output").html(''); //show loading image
    var url = "Tasks/Adddata.php";
    var metthod = 'POST';
    //build a post data structure
    var _ajax = ajaxJs(metthod, url, myData);

    if (_ajax != null) {
        //alert(_ajax);
        $("#output").html(_ajax);
     
    } else {
       return false;
    }
}
}

function deletestudentsAnnouce(sid,nid) {
 
    $("#output").append('<br /><div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OndeletestudentsAnnouce(' + sid + ',' + nid + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this Announcemt #['+ nid +'], with student id #['+ sid +'] if yes click OK</div>');
    
}
function deleteSdents(id) {
 
    $("#output").append('<br /><div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OndeleteSdents(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this students ID #['+ id +'], if yes click OK</div>');
    
}
function deleteCat(id) {
 
    $("#output").append('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteCat(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this Announcement ID #['+ id +'], if yes click OK</div>');
    
}
function deleteCont(id,type) {
    if(type=='all'){
         $("#output").append('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDelete_allCont()" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete all Contacts, if yes click OK</div>');
    }else{
    $("#output").append('<div class="alert alert-warning"><strong><i class="fa fa-info"> Deletion Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"><button type="button" onclick="OnDeleteCont(' + id + ')" class="btn btn-info">OK</button> <button type="button" onclick="window.location.reload()" class="btn btn-danger">close</button></div> Do you want to delete this contact ID #['+ id +'], if yes click OK</div>');
    }
}
Addstudent = function(){
   var st_code= $("#st_code").val(); 
   var st_name= $("#st_name").val(); 
   var st_email= $("#st_email").val(); 
   var guadian_name= $("#guadian_name").val(); 
   var guadian_email= $("#guadian_email").val(); 
   var guadian_phone= $("#guadian_phone").val(); 
    var levels= $("#levels").val(); 
   if(st_code=="" || st_name=="" || st_email=="" || guadian_name=="" || guadian_phone=="" || levels=="Select Level<"){
     alert('Fill submission field');
   }else{
       var myData = 'st_code='+st_code +'&st_name='+st_name+'&st_email='+st_email+'&guadian_name='+guadian_name+'&guadian_email='+guadian_email+'&guadian_phone='+guadian_phone+'&levels='+levels+'&Addstudent=Addstudent';
        var url = "Tasks/Adddata.php";
        var metthod = 'POST';
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {

            $("#status").append(_ajax);

        }else{
            $("#status").append(_ajax);
        }
   }
}

Updatestudent = function(st_code){
if(st_code=='0'){
window.location='./students';
}else{
   var st_name= $("#st_name").val(); 
   var st_email= $("#st_email").val(); 
   var guadian_name= $("#guadian_name").val(); 
   var guadian_email= $("#guadian_email").val(); 
   var guadian_phone= $("#guadian_phone").val(); 
   if(st_name=="" || st_email=="" || guadian_name=="" || guadian_phone==""){
     alert('Fill submission field');
   }else{
       var myData = 'st_code='+st_code +'&st_name='+st_name+'&st_email='+st_email+'&guadian_name='+guadian_name+'&guadian_email='+guadian_email+'&guadian_phone='+guadian_phone+'&Updatestudent=Updatestudent';
        var url = "Tasks/Updatedata.php";
        var metthod = 'POST';
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {

            $("#status").append(_ajax);

        }else{
            $("#status").append(_ajax);
        }
   }
}
}

 function deletelevel(id) {
    var deletelevel=$('#deletelevel'+id).data('id');
   var myData = 'deletelevel='+deletelevel;
        var url = "Tasks/DeleteData.php";
        var metthod = 'POST';
        var _ajax = ajaxJs(metthod, url, myData);
        if (_ajax != null) {

            $("#output").append(_ajax);

        }else{
            $("#output").append(_ajax);
        }
   }

$(document).ready(function () {

$("#responds").val('');
   
 
$("#logout").click(function (e) {
        e.preventDefault();
        var myData = 'Onlogout=Onlogout';
        var url = "../Includes/logout.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);

        if (_ajax != null) {
            //alert(_ajax);
            $("#logoutbox").append(_ajax);

        } else {
            $("#logoutbox").append(_ajax);
        }
    });

$("#logout1").click(function (e) {
        e.preventDefault();
        var myData = 'Onlogout1=Onlogout1';
        var url = "../Includes/logout1.php";
        var metthod = 'POST';
        //build a post data structure
        var _ajax = ajaxJs(metthod, url, myData);

        if (_ajax != null) {
            //alert(_ajax);
            $("#logoutbox").append(_ajax);

        } else {
            $("#logoutbox").append(_ajax);
        }
    });

    $(".collapsed").click(function (e) {
        e.preventDefault();
        return SetNewsUpdates();
    });

     $(".collapsedq").click(function (e) {
        e.preventDefault();
         $("#update-box").hide(); //show submit button
        $("#addnew-box").show(); //hide loading image
    }); 
});

function logout(){

}

function loadComments(){
    try{
    //var article  = $('#article').val();
   // $('#loading').show();
    var myData = 'loadComments=loadComments'; 
			$.ajax({
				url : 'Activity/appendComment.php',
				method: 'GET',
				data:myData,
				success: function( data ) {
			
                   
			        $('#commentsbox').html( data);
					
                   // console.log(seconds);
                 //     if(beep=='0' && seconds == '59 mins'){
                 //        //
                 // $('#beep').html("<video controls autoplay='true'><source src=\"Activity/beep.mp3\"></video>");  
        
                 //    }else{
                 //        $('#beep').html('');
                 //    }
				},
				error: function( data ){
					//flag = true;
					//no_data = false;
					$("#commentsbox").html('<div class="alert alert-danger"><strong><i class="fa fa-info">warning :</i></strong><button type="button" onclick="window.location.reload()" class="btn btn-danger pull-right">close</button>Something went wrong, Please try again!</div>');
				}
			});
  //  setTimeout(loadComments, 1000); // Change image every 2 seconds
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}
//setInterval(loadComments, 15000);


//function formatDatas(format){
//  
//  
//    for (var formats in format) {
//      
//   var fd = new FormData();
//    return fd.append(format[formats]);
//        
//  }
//}

function SearchInTable() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

 
//addEventListener("load",function(){
//    loadingImg('timeline'); 
//    readdata();
//}); 

$('#timeline').ready(function() {
$('#timeline').show();
readdata();
announce_Type();
});

flag = true;
function readdata()
{
    try{
    	
       var myData = 'On_article=On_article';   
		no_data = true;
		if(flag && no_data){
			flag = false;
			loadingImg('timeline'); 
			$.ajax({
				url : 'pages/displays/blog.php',
				method: 'GET',
				data:myData,
				success: function( data ) {
					flag = true;
					if(data.count !=0 ){
						
			        output('timeline',data);
                        
                    }else{
						output('timeline','<li class="heading"><div class="alert alert-warning"><strong><i class="fa fa-info"> Posts Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"> </div> No more data to show</div></li>');
                      no_data = false;
					}
				},
				error: function( data ){
					flag = true;
					no_data = false;
                    output('timeline','<li class="heading"><div class="alert alert-warning"><strong><i class="fa fa-info">Connection Message :</i></strong>&nbsp;&nbsp;<div class="pull-right"> </divSomething went wrong, no connection found</div></li>');
					
				}
			});
		}
        }catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}
}

  