 
<?php 

if(isset($_POST['unset'])){
    $db= new Databases();

        
    $addTask=array('published_at'=>'', 'item_deadlineTopublic'=>'');
                $add=$db->updateData('item_publisher', $addTask,$condition="item_id=".$_GET['rmvPublic']);
                if ($add == true) {
                    echo"<center><img src='img/progressring.gif'><h1> Process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./admin.php?publicproducts'; }, 1000);</script>";
        
                }
    
}
?>
<div class="row">
    <h3 style="text-align: center;color:white">Remove To Public</h3>
<div  class="form-module1">
                        <form action="#" class="form" id="productform" method="post">
                          <div class="clearfix"></div><p />
                            <div class="col-lg-1">
                            </div>
                    
                            <div  class="col-md-24">
                                <div class="clearfix"></div><hr />
                                  <input type="submit" name="unset" value="Remove">
                        <div>
                        
                         
                        </form>
</div>
                    </div>
