<?php include "Includes/DbConfig.php" ?>
<?php include "activity/salrsinfo.php" ?>

<?php include "head.php" ?>
        <?php include "nav.php" ?>

                <div class="banner">
                    <?php include "menu.php" ?>

                    <?php
                    if (isset($_GET['salerLogin'])){
                        include "salersLogin.php";
                    }else if(isset($_GET['salerssLogin'])){

                    }elseif(isset($_GET['productPreviews'])){
                        require'back_productPreviews.php';
                        }else if(isset($_GET['searchbtns'])){
                       
                       require'search.php';

                        }else if(isset($_GET['about'])){
                            echo"<pre>
                            MISSION
We offer the best services for satisfying our client’s needs.
VISION	
Our vision is to see all people access our system in easily way.
OBJECTIVE
To implement online auction system for buyers and sellers.

                            </pre>";
                            }else if(isset($_GET['contact'])){


                         echo"Marketing  :Tuyisenge Solange,  ";    
                         echo"Marketing Phone number:0789619708, ";
                         echo"email:kamatalisolange2020@gmail.com, ";
                         echo"<br />";

                         echo"Manager  :Baganizi Ange,  ";    
                         echo"Manager Phone number:0782228833, ";
                         echo"email:buwange@gmail.com";
                       echo"<br />";

                         echo"Admin :Nyampinga Dinah,  ";    
                         echo"Admin Phone number:078, ";
                         echo"email:nyampingad@gmail.com, ";
                       echo"<br />";
                       echo' <br />map:<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15942.635793349962!2d29.73686935!3d-2.6164514999999997!3m2!1i1024!2i768!4f13.1!4m3!3e6!4m0!4m0!5e0!3m2!1sen!2srw!4v1496876343344" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>';
                        }else{
                        include "banner_nav_right.php";
                    }

                    ?>

                    <div class="clearfix"></div>
                </div>

                <?php include "top-brands.php" ?>

<?php include "footer.php" ?>
