<?php
include('../Includes/Databases.php');
$db= new Databases();

if(isset($_POST['OnDeleteArticles'])){
$msg="";
	
	$table='posts';
	$db->open_connection();
	$id=$_POST['OnDeleteArticles'];
	
	$delete=$db->deleteData($table,"refers_id=".$id."");
	
	if($delete==true){
		echo $db->messges($msg='success',$info='Article info',$action='Deleted');
	}else{
		
		echo $db->messges($msg='error',$info='Article info',$action='Deleted');
	}
	$db->close_connection();
	
	     // $allArrayfile=array('../../upload/img_posts/'.$_POST['picsname'],
        //                    '../../upload/audio_posts/'.$_POST['audio'],
        //                    '../../upload/img_posts/thumb209x140/'.$_POST['picsname'],
        //                    '../../upload/img_posts/thumb449x330/'.$_POST['picsname'],
        //                    );
        // $db->removeFile($allArrayfile);
      
}

if(isset($_POST['deletephoto'])){
	  $table='files';
	 $db->open_connection();
     $cond="files_id=".$_POST['deletephoto'];
        $fetch_file=$db->query_display($table,$column_name='', $cond);
        $rowcount=$db->num_rows($fetch_file);
         if($rowcount > 0){
            $row = $db->fetch_all_array($fetch_file);
                        $filename=$row['file_name'];

if(isset($_POST['type']) && $_POST['type']=='photo'){

         $imgs = "../../upload/img_posts/".$filename;
          $ts=0;
		  while(file_exists($imgs)){
		        unlink($imgs); 
		    $ts++;
		  }
    }else{

    	 $img = "../../upload/audio_posts/".$filename;
          $t=0;
		  while(file_exists($img)){
		        unlink($img); 
		    $t++;
		  }
    }
	    $delete=$db->deleteData($table,"files_id=".$_POST['deletephoto']);
	}
	  $db->close_connection();
}
    if(isset($_POST['deletefile']) && isset($_POST['format']) && isset($_POST['format']))
    {
     $table='files';
	 $db->open_connection();
     $id=$_POST['deletefile'];
	 $delete=$db->deleteData($table,"id=".$id);
	 if($_POST['format']=='photo'){
       if(file_exists('../../upload/img_posts/'.$_POST['filename'])){
          unlink('../../upload/img_posts/'.$_POST['filename']);  
        }
         if(file_exists('../../upload/img_posts/thumb25x20/'.$_POST['filename'])){
          unlink('../../upload/img_posts/thumb25x20/'.$_POST['filename']);  
        }
        if(file_exists('../../upload/img_posts/thumb90x70/'.$_POST['filename'])){
          unlink('../../upload/img_posts/thumb90x70/'.$_POST['filename']);  
        }
        if(file_exists('../../upload/img_posts/thumb209x140/'.$_POST['filename'])){
          unlink('../../upload/img_posts/thumb209x140/'.$_POST['filename']);  
        }
       if(file_exists('../../upload/img_posts/thumb449x330/'.$_POST['filename'])){
          unlink('../../upload/img_posts/thumb449x330/'.$_POST['filename']);  
        }
        }else if($_POST['format']=='audio'){
         if(file_exists('../../upload/audio_posts/'.$_POST['filename'])){
           unlink('../../upload/audio_posts/'.$_POST['filename']); 
        }
          
        }
	if($delete==true){ 
      echo"ok"; 
    }else{echo"wrong"; }
        $db->close_connection();
    }

if(isset($_POST['OnDeleteCmmt'])){
$msg="";
	
	$table='comments';
	
	
	$db->open_connection();
	
	
	$id=$_POST['OnDeleteCmmt'];
	
	
	$delete=$db->deleteData($table,"id=".$id);
	
	if($delete==true){
		echo $db->messges($msg='success',$info='Comment info',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='Comment info',$action='Deleted');
	}
	$db->close_connection();
	
}
if($db->Save('OnDeleteCat')){
$msg="";
	
	$table='notifications';
	$db->open_connection();
	$id=$db->Input('id');
	
	
	$delete=$db->deleteData($table,"notic_id=".$id);
	$delete.=$db->deleteData('public_notics',"notic_id=".$id);
	if($delete==true){
		echo $db->messges($msg='success',$info='Notification',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='Notification',$action='Deleted');
	}
	$db->close_connection();
	
}

if($db->Save('OndeleteSdents')){
$msg="";
	
	$table='students';
	$db->open_connection();
	$id=$db->Input('OndeleteSdents');
	
	
	$delete=$db->deleteData($table,"st_code=".$id);
	$delete.=$db->deleteData('students_notics',"st_code=".$id);
	if($delete==true){
		echo $db->messges($msg='success',$info='Students',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='Students',$action='Deleted');
	}
	$db->close_connection();
	
}
if($db->Save('OndeletestudentsAnnouce')){
$msg="";
	
	$table='students';
	$db->open_connection();
	$sid=$db->Input('sid');
	$nid=$db->Input('nid');
	
	$delete=$db->deleteData('students_notics',"st_code=".$sid." AND notic_id=".$nid);
	if($delete==true){
		echo $db->messges($msg='success',$info='Students Announcemt',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='Students Announcemt',$action='Deleted');
	}
	$db->close_connection();
	
}

if($db->Save('OnDeleteCont')){
$msg="";
	
	$table='contacts';
	$db->open_connection();
	$id=$db->Input('id');
	
	
	$delete=$db->deleteData($table,"id=".$id);
	
	if($delete==true){
		echo $db->messges($msg='success',$info='contact info',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='contact info',$action='Deleted');
	}
	$db->close_connection();
	
}



if($db->Save('OnDelete_allCont')){
$msg="";
	
	$table='contacts';
	$db->open_connection();
	
	$delete=$db->deleteData($table,$condition=null);
	
	if($delete==true){
		echo $db->messges($msg='success',$info='All contacts data',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='All contacts data',$action='Deleted');
	}
	$db->close_connection();
	
}
if($db->Save('OnrmvServices')){
$msg="";
	
	$table='service';
	$db->open_connection();
	$id=$db->Input('OnrmvServices');
	$delete=$db->deleteData($table,"id=".$id);
	
	if($delete==true){
		echo $db->messges($msg='success',$info='Service data',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='Service data',$action='Deleted');
	}
	$db->close_connection();
	
}
if($db->Save('deletelevel')){
$msg="";
	
	$table='students_levels';
	$db->open_connection();
	$id=$db->Input('deletelevel');
	$delete=$db->deleteData($table,"id=".$id);
	
	if($delete==true){
		echo $db->messges($msg='success',$info='students levels',$action='Deleted');
	}
	
	else{
		
		echo $db->messges($msg='error',$info='students levels',$action='Deleted');
	}
	$db->close_connection();
	
}
