<?php include('../../Includes/Databases.php');

$db= new Databases();

if(isset($_GET['setphotoeditor']))
{
      $table='files';
     $db->open_connection();
     $cond="files_id=".$_GET['setphotoeditor'];
        $fetch_file=$db->query_display($table,$column_name='', $cond);
        $rowcount=$db->num_rows($fetch_file);
         //if($rowcount > 0){
                   $row = $db->fetch_all_array($fetch_file);
                        $filename=$row['file_name'];
                        $desc=$row['description'];
                        
                        $path='../upload/img_posts/'.$filename;
    ?>
  <div class="panel-body" style="z-index:999999;">
                         <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Update Photo:</h4>
                                        </div>
                                        <div class="modal-body">

                                          <?php echo" <img  id='epreviewing' style='height:200px' class=\"img-responsive img-thumbnail\" src='".$path."'>";?>
                                         <br /><textarea class="form-control" rows='6' id='descs' placeholder="Add Photo description"> <?php echo $db->html_entity_decodes($desc);?></textarea>
                                      
                                        <input type="hidden" value="<?php echo $row['files_id'];?>"  id='ids'>
                                        <div class="alert alert-danger" id='epmessage' style="display:none">
                                                 <strong>
                                                     <i class="fa fa-info"> alert Message :</i>
                                                </strong>  
                                                </div>
                                                    <dimension style="display:none">
                                                <input type="number" value="400" id="widthz"  />
                                                <input type="number" value="400" id="heightz" />
                                                    </dimension>
                                                      <div class="progress" style='width: 100%;'>
                                                             <div  style="display:none" class="progress-bar progress-bar-info" id='eprogress-barimg' role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:0%">
                                                                </div>
                                                            </div>
                                                             <percentage id="eperctage" style="font-size:18px;color:green"></percentage>
                                        </div>
                                        
                                        <div class="modal-footer"><span class="pull-left"><input type="file" onchange="choosePhoto_edit()"  id='ephotonames' name='file'></span>
                                            <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload()">Close</button>
                                            <button type="button" class="btn btn-primary" id='euploadPhoto' onclick='euploadPhoto()'>Yes Upload and save</button>
                                        </div>
                                    </div>
                                </div>
                        
                        </div>

<?php }elseif(isset($_GET['setaudioeditor']))
{
      $table='files';
     $db->open_connection();
     $cond="files_id=".$_GET['setaudioeditor'];
        $fetch_file=$db->query_display($table,$column_name='', $cond);
        $rowcount=$db->num_rows($fetch_file);
         //if($rowcount > 0){
                   $row = $db->fetch_all_array($fetch_file);
                        $filename=$row['file_name'];
                        $desc=$row['description'];
                        $artist=$row['files_owner'];
                        $path='../upload/audio_posts/'.$filename;
    ?>
  <div class="panel-body" style="z-index:999999;">
                         <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Update Audio:</h4>
                                        </div>
                                        <div class="modal-body">

                                          <?php echo"<video id='eApreviewing' autoplay='true' controls src='".$path."' style='mix-width:100%;max-width:100%;width:255px;height:200px;' poster='../img/audio.gif'> </video>";?>
                                            <br /><label>Add Artist name</label>
                                            <input type="text" class="form-control" id='eartist'value=" <?php echo $db->html_entity_decodes($artist);?>"  placeholder="Add Artist name"/><br />  
                                            <label>Add description</label>
                                            <textarea class="form-control" rows='6' id='eadesc' placeholder="Add Audio description"> <?php echo $db->html_entity_decodes($desc);?></textarea>
                                      
                                        <input type="hidden" value="<?php echo $row['files_id'];?>"  id='eids'>
                                        <div class="alert alert-danger" id='eAmessage' style="display:none">
                                                 <strong>
                                                     <i class="fa fa-info"> alert Message :</i>
                                                </strong>  
                                                </div>
                                                    <dimension style="display:none">
                                                <input type="number" value="400" id="ewidthz"  />
                                                <input type="number" value="400" id="eheightz" />
                                                    </dimension>
                                                      <div class="progress" style='width: 100%;'>
                                                             <div  style="display:none" class="progress-bar progress-bar-info" id='eprogress-baraudio' role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:0%">
                                                                </div>
                                                            </div>
                                                             <percentage id="eaperctage" style="font-size:18px;color:green"></percentage>
                                        </div>
                                        
                                        <div class="modal-footer"><span class="pull-left"><input type="file" onchange="chooseAudio_edit()"  id='eaudionames' name='file'></span>
                                            <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload()">Close</button>
                                            <button type="button" class="btn btn-primary" id='euploadAudio' onclick='euploadAudio()'>Yes Upload and save</button>
                                        </div>
                                    </div>
                                </div>
                        
                        </div>

<?php }
else if(isset($_GET['searchDialog'])){
 echo'                    
                            <div class="col-md-4 col-lg-4 col-sm-24 col-xs-24"></div>
                                <div class="modal-dialog modal-lg col-md-16 col-lg-16 col-sm-24 col-xs-24">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Search for more</h4>
                                        </div>
                                        <div class="modal-body">
                                            <textarea type="text" class="form-control" style="border:none; font-size:16px;font-weight:bold" onkeyup="onsearchArticle()" id="searchInput" placeholder="Searching for more ....."/></textarea>
                                        </div>
                                        
                                        <div class="modal-footer" id="searchingbox">
                                            
                                        </div>
                                      <center><loading id="loading" style="bottom:-20px;display:none"><img src="hanga/img/book.gif"></loading></center>
                                    </div>
                                </div>
                                <div class="col-md-4 col-lg-4 col-sm-24 col-xs-24"></div> ';
}else if(isset($_GET['removeonpublic']))
{?>
  <div class="panel-body" style="z-index:999999;">
                            
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Remove On public:</h4>
                                        </div>
                                        <div class="modal-body" id='deleted'>
                                           Do you want to remove onpublic this articles<span class='btn btn-info' id='articleid'><?php echo"#".$_GET['removeonpublic'];?></span>
                                        </div>
                                        
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload()">Close</button>
                                            <button type="button" class="btn btn-info" id='dltbtn' onclick='OnRmvTopublic(<?php echo $_GET['removeonpublic'];?>)'>Yes Set</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

<?php }else if(isset($_GET['deletComment']))
{ ?>
  <div class="panel-body" style="z-index:999999;">
                            
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Delete Worning:</h4>
                                        </div>
                                        <div class="modal-body" id='deleted'>
                                           Are u sure you want to delete this comments <span class='btn btn-info' id='articleid'><?php echo"#".$_GET['deletComment'];?></span>
                                        </div>
                                        
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload()">Close</button>
                                            <button type="button" class="btn btn-danger" id='dltbtn' onclick='OnDeleteCmmt(<?php echo $_GET['deletComment'];?>)'>Yes Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

<?php }else if(isset($_GET['SetapproveComment']))
{ ?>
  <div class="panel-body" style="z-index:999999;">
                            
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="window.location.reload()">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Delete Worning:</h4>
                                        </div>
                                        <div class="modal-body" id='deleted'>
                                           Are u sure you want to Approve this comments <span class='btn btn-info' id='articleid'><?php echo"#".$_GET['SetapproveComment'];?></span>
                                        </div>
                                        
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload()">Close</button>
                                            <button type="button" class="btn btn-primary" id='dltbtn' onclick='approveCmments(<?php echo $_GET['SetapproveComment'];?>)'>Yes Approve it</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

<?php } 


?>

