<?php
header('Content-type: application/json; charset=UTF-8');
//error_reporting(0);
include('../Includes/Databases.php');
$db= new Databases();
//$mail=new mail;
$response=array();
if($db->Save('btnssignup')){
    $db->open_connection();
        $table='salers';

            $firstname              =$db->Input("firstname");
            $lastname               =$db->Input("lastname");
            $businessname           =$db->Input("businessname");
            $password               =sha1($db->Input("password"));
            $email                  =$db->Input("email");
            $phone                  =$db->Input("phone");
            $email                  =$db->Input("email");
            $address                =$db->Input("address");
            $country                =$db->Input("country");
            $about                  =$db->Input("about");
                if(!empty($firstname) || !empty($lastname) || !empty($businessname) || !empty($email) || !empty($phone) || !empty($password))
                {
                    $addTask = array('fname'=> $firstname, 'lname'=> $lastname, 'email'=> $email, 'phone'=> $phone, 'bussins_name' => $businessname,'password' => $password, 'address' => $address, 'country' => $country, 'about_me' => $about );
                    $add=$db->addData($table,$addTask);
                    if($add==true){
                        $response['status']='success';
                    }else{
                        $response['status']='fail';
                    }

                 }
    print json_encode($response);

$db->close_connection();

}else if($db->Save('find')){
    $db->open_connection();
    $table='salers';
    $verify_business = $db->Input("verify_business");
    $runQuery=$db->query_display($table, $column_name = '', $condition="bussins_name='{$verify_business}'");
    $n=$db->num_rows($runQuery);
        if($n > 0){
            $response['status']='find';
        }else{
            $response['status']='notfind';
        }


    print json_encode($response);

    $db->close_connection();
}
else if($db->Save('btnsignin')){
    $db->open_connection();
    $table='salers';
    $username = $db->Input("username");
    $password = sha1($db->Input("password"));
    $runQuery=$db->query_display($table, $column_name = '', $condition="( email='{$username}' or bussins_name='{$username}' ) AND password='{$password}'");
    $n=$db->num_rows($runQuery);
    if($n > 0){
        $row=$db->fetch_all_array($runQuery);
            $_SESSION['auth_id'] = $row['saler_id'];
            $_SESSION['salers'] ='salers';
            setcookie("auth_id", $_SESSION['auth_id'], strtotime( '+5 days' ), "/", "", "", TRUE);
            setcookie("salers", $_SESSION['salers'], strtotime( '+5 days' ), "/", "", "", TRUE);
                if ( (isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){
                    $update = $db->updateData($table,array('loggedin_at'=>'now()','online'=>'1'),$condition="saler_id=".$_SESSION['auth_id']);
                    if ($update==true) $response['status']='salers_success';
                }

    }else{
        $response['status']='salers_fail';
    }


    print json_encode($response);

    $db->close_connection();
}else if($db->Save('btnsigninadmin')){
    $db->open_connection();
    $table='admin';
    $username = $db->Input("username");
    $password = sha1($db->Input("password"));
    $runQuery=$db->query_display($table, $column_name = '', $condition="username='{$username}' AND password='{$password}'");
    $n=$db->num_rows($runQuery);
    if($n > 0){
        $row=$db->fetch_all_array($runQuery);
            $_SESSION['auth_id1'] = $row['id'];
            $_SESSION['admin'] ='admin';
            setcookie("auth_id1", $_SESSION['auth_id1'], strtotime( '+5 days' ), "/", "", "", TRUE);
            setcookie("admin", $_SESSION['admin'], strtotime( '+5 days' ), "/", "", "", TRUE);
                if ( (isset($_SESSION['auth_id1']) || isset($_COOKIE["auth_id1"])) && (isset($_SESSION['admin']) || isset($_COOKIE["admin"])) ){
                    $update = $db->updateData($table,array('loggedin_at'=>'now()'),$condition="id=".$_SESSION['auth_id1']);
                    if ($update==true) $response['status']='salers_success';
                }

    }else{
        $response['status']='salers_fail';
    }


    print json_encode($response);

    $db->close_connection();
}else if($db->Save('saveprice')){ 
    $db->open_connection();

    // $runQuery=$db->query_display('buyers', $column_name = '', $condition="email='{$email}'");
    // $n=$db->num_rows($runQuery);
    // if($n > 0){
    //     $row=$db->fetch_all_array($runQuery);
    //     $addTask=array('item_id'=>$db->Input("item_id"), 'buyer_id'=> $row['buyer_id'], 'price'=>$db->Input("price"), 'currency'=>$db->Input("currency"));
    //      $add=$db->addData('deals', $addTask);
    //      if ($add==true){
    //             $response['status']='_success';
    //                     }else{
    //                     $response['status']='_fail';
    //                      }
    //         }else{
                    $email=$db->Input("email");
                     $addTask_=array('fullname'=>$db->Input("fullname"), 'phone'=>$db->Input("phone"), 'email'=>$db->Input("email"));
                        $add_=$db->addData('buyers', $addTask_);
                        if ($add_==true){
                                $runQuery_=$db->query_display('buyers', $column_name = '', $condition="email='{$email}' ");
                            $n_=$db->num_rows($runQuery_);
                            if($n_ > 0){
                                $row_=$db->fetch_all_array($runQuery_);
                                   $_addTask=array('item_id'=>$db->Input("item_id"), 'buyer_id'=> $row_['buyer_id'], 'price'=>$db->Input("price"), 'currency'=>$db->Input("currency"));
                                        $_add=$db->addData('deals', $_addTask);
                                           if ($_add==true){
                                                $response['status']='_success';
                                                        } else{
                                                        $response['status']='_fail';
                                                    }
                            }
                        }
                
                 print json_encode($response);

    $db->close_connection();
}
else if($db->Save('addproduct')){
    $db->open_connection();
    $table='items';
    $ds = DIRECTORY_SEPARATOR;
    $dirPic=  'upload/lg_photo/';
    $targetpicPath = $dirPic;
    $phototmp= $_FILES['photo']['tmp_name'];//temp name
    $photoname = $_FILES['photo']['name'];//file name
    $ext = pathinfo($photoname, PATHINFO_EXTENSION);
    $phtofn   = 'auction_photo-'.time().rand(0,10).'.'.$ext;
    $targetFilePic     =  $targetpicPath.$phtofn;

   // if (intval($db->Input("savproduct"))) {
        if (move_uploaded_file($phototmp, $targetFilePic)){

            $addTask=array('saler_id'=>$db->Input("salers_id"), 'item'=>$db->Input("item"), 'type'=>$db->Input("type"), 'size'=>$db->Input("size"), 'post_price'=>$db->Input("post_price"), 'category'=>$db->Input("categories"), 'description'=>$db->Input("desc"), 'photo_view'=> $phtofn, 'currency' => $db->Input("currency"));
            $add=$db->addData($table, $addTask);
            if ($add == true) {
                print 'saved successfull !';
            } else {
                print'addproduct_fail';
            }
        } else {
            print'upload_fail';
        }

    //}

    $db->close_connection();
}else if($db->Save('editproduct')){
    $db->open_connection();
    $table='items';
    $ds = DIRECTORY_SEPARATOR;
    $dirPic=  'upload/lg_photo/';
    $targetpicPath = $dirPic;
    $phototmp= empty($_FILES['photo']['tmp_name'])?"":$_FILES['photo']['tmp_name'];//temp name
    $photoname = empty($_FILES['photo']['name'])?"":$_FILES['photo']['name'];
    $ext = pathinfo($photoname, PATHINFO_EXTENSION);
    $phtofn   = 'auction_photo-'.time().rand(0,10).'.'.$ext;
    $targetFilePic     =  $targetpicPath.$phtofn;

   // if (intval($db->Input("savproduct"))) {
        if (move_uploaded_file($phototmp, $targetFilePic)){
                $file=$phtofn;
             }else{
            $file=$db->Input("latestphoto");
        }

           $updateTask=array('saler_id'=>$db->Input("salers_id"), 'item'=>$db->Input("item"), 'type'=>$db->Input("type"), 'size'=>$db->Input("size"), 'post_price'=>$db->Input("post_price"), 'category'=>$db->Input("categories"), 'description'=>$db->Input("desc"), 'photo_view'=> $file, 'currency' => $db->Input("currency"));
             $update=$db->updateData($table,$updateTask,$condition="item_id=".$db->Input("item_id"));
    if($update==true){
    
                print 'saved successfull !';
            } else {
                print'editproduct_fail';
            }
       

    //}

    $db->close_connection();
}




?>