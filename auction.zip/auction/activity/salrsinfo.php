<?php
/**
 * Created by PhpStorm.
 * User: honore
 * Date: 5/31/2017
 * Time: 4:21 AM
 */
include('Includes/Databases.php');

function salersinfo($auth){
    $db= new Databases();
    $db->open_connection();
    $table='salers';
    $runQuery=$db->query_display($table, $column_name = '', $condition="saler_id=".$auth);
    $n=$db->num_rows($runQuery);
    if($n > 0) {
        $row=$db->fetch_all_array($runQuery);
        return array('fname'=>$row['fname'],
            'lname'=>$row['lname'],
            'email'=>$row['email'],
            'phone'=>$row['phone'],
            'bussins_name'=>$row['bussins_name'],
            'address'=>$row['address'],
            'country'=>$row['country'],
            'about_me'=>$row['about_me'],
            'online'=>$row['online'],
            'loggedin_at'=>$row['loggedin_at']
            );
    }
    $db->close_connection();
}
