<?php
include('../Includes/Databases.php');
$db= new Databases();

    if(isset($_POST['chooseStudent'])){
      $chk=$_POST['chk'];

      for($i=0; $i < count($chk); $i++){
        echo $chk[$i].',';
      }
    }

if($db->Save('Updatestudent')){

  $table='students';
  $db->open_connection();
  
    $st_code         =$db->Input("st_code");
    $st_name            =$db->Input("st_name");
    $st_email           =$db->Input("st_email");
    $guadian_name           =$db->Input("guadian_name");
    $guadian_email           =$db->Input("guadian_email");
    $guadian_phone           =$db->Input("guadian_phone");
    // $pass=rand(0,2);
    // $passwrd=sha1($pass);
    if(!empty($st_code))
  {
          $updateTask = array('st_full_name'=> $st_name, 'st_email' => $st_email,
    'guadian_name' =>$guadian_name,'guadian_email' => $guadian_email,'guadian_phone'=>$guadian_phone);
      $update=$db->updateData($table,$updateTask,$condition="st_code=".$st_code ."");
    if($update==true){
      
         echo $db->messges($msg='error',$info='Students',$action='Updated');
        }else{
            echo $db->messges($msg='success',$info='Students',$action='Updated');
        }
        
    }

$db->close_connection();
}

 if($db->Save('SetPublic')){
      $table='posts';
       $db->open_connection();
       $update=$db->updateData($table,array('pub' => '1'),$condition="refers_id=".$_POST['SetPublic']."");
        
        if($update==true){echo $db->messges($msg='success',$info='publishing info',$action='Updated');}
    else{
        echo $db->messges($msg='error',$info='publishing info',$action='Updated');
    }
    
    $db->close_connection();
}

 if($db->Save('UnsetPublic')){
      $table='posts';
       $db->open_connection();
      $update=$db->updateData($table,array('pub' => '0'),$condition="refers_id=".$_POST['UnsetPublic']."");
        
        if($update==true){echo $db->messges($msg='success',$info='publishing info',$action='Updated');}
    else{
        echo $db->messges($msg='error',$info='publishing info',$action='Updated');
    }
    
    $db->close_connection();
}

if($db->Save('approveCmments')){
      $table='comments';
       $db->open_connection();
      $updateTask = array( //just an array [colum_name] => [values]
    'comment_status' => '1'
    ); 
    //'photo' => $fn,
        
        $update=$db->updateData($table,$updateTask,$condition="id=".$_POST['approveCmments']);
        
        if($update==true){echo $db->messges($msg='success',$info='Aproved info',$action='Updated');}
    else{
        echo $db->messges($msg='error',$info='Aproved info',$action='Updated');
    }
    
    $db->close_connection();
    
}

if($db->Save('oneditpubAnnounce')){

    $format="";
  $filename1=$db->Input('logo');
    if(!empty($_FILES['photo']) && isset($_FILES['photo']))
    {
    $filename=$_FILES['photo']['name'];
    $file=$_FILES['photo'];
    $upload_errors = array(
          UPLOAD_ERR_OK     => "No errors.",
      UPLOAD_ERR_INI_SIZE   => "Larger than upload_max_filesize.",
      UPLOAD_ERR_FORM_SIZE  => "Larger than form MAX_FILE_SIZE.",
      UPLOAD_ERR_PARTIAL  => "Partial upload.",
      UPLOAD_ERR_NO_FILE  => "No file.",
      UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",
      UPLOAD_ERR_CANT_WRITE => "Can't write to disk.",
      UPLOAD_ERR_EXTENSION  => "File upload stopped by extension."
      
      );
  
  if($file["error"] != 0){
    echo $upload_errors[$file["error"]];
    exit();
    }
        
        $file_loc = $_FILES['photo']['tmp_name'];
        $file_size = $_FILES['photo']['size'];
        $file_type = $_FILES['photo']['type'];
        $folder="../../upload/annaunce/";
   
       $new_size = $file_size/1024;  
 
       $new_file_name = strtolower($filename);
       $final_file=str_replace(' ','-',rand(0,9).$new_file_name);
       $target_file =$folder.basename($_FILES["photo"]["name"]);
       $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

 if($new_size > 10000)
{
    echo"<span class='btn btn-warning'>The file uploaded exceeds the allowed size less or equal to 10 MB</span>";
    exit();
}
    
        $imgs = $folder.$filename1;
          $ts=0;
         
      while(file_exists($imgs)){
            unlink($imgs); 
        $ts++;
      }
         move_uploaded_file($file_loc,$folder.$final_file); 
        $fn=$final_file;
    }else{
           $fn=$filename1;
        }
        $title = $db->Input('title');
        $pubcAnnounce= $db->Input('pubcAnnounce'); 
        $id      = $db->Input('id');  
     
       $updateTask = array('title' => $title,'notification' => $pubcAnnounce,'file' => $fn);
        
        $update=$db->updateData('notifications',$updateTask,$condition="notic_id=".$id);
    if($update==true){
         echo $db->messges($msg='success',$info='Notification',$action='Updated');
    }else{
      echo $db->messges($msg='error',$info='Notification',$action='Updated');
    }

}

 //////////////////////////////////////////////////////
if($db->Save('onSaveproject')){

    $format="";
  $filename1=$db->Input('logo');
    if(!empty($_FILES['projectlogo']) && isset($_FILES['projectlogo']))
    {
    $filename=$_FILES['projectlogo']['name'];
    $file=$_FILES['projectlogo'];
    $upload_errors = array(
          UPLOAD_ERR_OK 		=> "No errors.",
		  UPLOAD_ERR_INI_SIZE  	=> "Larger than upload_max_filesize.",
		  UPLOAD_ERR_FORM_SIZE 	=> "Larger than form MAX_FILE_SIZE.",
		  UPLOAD_ERR_PARTIAL 	=> "Partial upload.",
		  UPLOAD_ERR_NO_FILE 	=> "No file.",
		  UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",
		  UPLOAD_ERR_CANT_WRITE => "Can't write to disk.",
		  UPLOAD_ERR_EXTENSION 	=> "File upload stopped by extension."
		  
	    );
	
	if($file["error"] != 0){
		echo $upload_errors[$file["error"]];
		exit();
		}
        
        $file_loc = $_FILES['projectlogo']['tmp_name'];
        $file_size = $_FILES['projectlogo']['size'];
        $file_type = $_FILES['projectlogo']['type'];
        $folder="../../upload/logo/";
   
       $new_size = $file_size/1024;  
 
       $new_file_name = strtolower($filename);
       $final_file=str_replace(' ','-',rand(0,9).$new_file_name);
       $target_file =$folder.basename($_FILES["projectlogo"]["name"]);
       $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

 if($new_size > 10000)
{
    echo"<span class='btn btn-warning'>The file uploaded exceeds the allowed size less or equal to 10 MB</span>";
    exit();
}
    
        $imgs = $folder.$filename1;
          $ts=0;
         
      while(file_exists($imgs)){
            unlink($imgs); 
        $ts++;
      }
         move_uploaded_file($file_loc,$folder.$final_file); 
        $fn=$final_file;
    }else{
           $fn=$filename1;
        }
        $name    = $db->Input('project');
        $web     = $db->Input('web'); 
        $contact = $db->Input('contact');
        $address = $db->Input('address'); 
        $location= $db->Input('location'); 
        $id      = $db->Input('id'); 
        $description = $db->Input('description');   
     
       $updateTask = array('logo' => $fn,'dates' => 'now()','project_name' => $name,
		'website' => $web,'full_contact'=> $contact,'full_address' => $address,'full_location' => $location,'description'=>$description);
		
        $update=$db->updateData('project',$updateTask,$condition="proj_id=".$id);
		if($update==true){
         echo $db->messges($msg='success',$info='Data info',$action='Updated');
		}else{
			echo $db->messges($msg='error',$info='Data info',$action='Updated');
		}

}


if ($db->Save('changeusers'))
{
   session_start();
      
      $p = md5($db->Input('user'));
       $updateTask = array('users_fname' => $db->Input('fname'),
                           'users_lname' => $db->Input('lname'),
                           'users_username' => $db->Input('user'),
		                    'users_password' =>$p,
                           'users_gender'=> $db->Input('gender'),
                           'users_email' => $db->Input('email'));
    
    
    $update=$db->updateData('users',$updateTask,$condition="id=".$_SESSION['Auth_id']);
		if($update==true){
         echo $db->messges($msg='success',$info='User info',$action='Updated');
		}else{
			echo $db->messges($msg='error',$info='User info',$action='Updated');
		}
    
}



if($db->Save('saveAbouts'))
{
    $table='abouts';
   $Task = array('abouts' => $db->Input('body'),'dates' => 'now()');
    
    
    $fetching=$db->query_display($table,$column_name='', $condition="");
    $rowcount=$db->num_rows($fetching);
    
 if($rowcount == 0){
     $add=$db->addData($table,$Task);
         if($add==true){
               echo $db->messges($msg='success',$info='New About us info',$action='saved');
            }else{
                echo $db->messges($msg='error',$info='New About us info',$action='saved');
            }
     
     }else{
            $row = $db->fetch_all_array($fetching);
             $id=$row['id'];
     
             $update=$db->updateData($table,$Task,$condition="id=".$id);
            if($update==true){
             echo $db->messges($msg='success',$info='About us info',$action='Updated');
            }else{
                echo $db->messges($msg='error',$info='About us info',$action='Updated');
            } 
     }
    
}


if($db->Save('updateService'))
{
    $table='service';
   $Task = array('service' => $db->Input('body'),'dates' => 'now()');
          $update=$db->updateData($table,$Task,$condition="id=".$db->Input('updateService'));
            if($update==true){
             echo $db->messges($msg='success',$info='Service us info',$action='Updated');
            }else{
                echo $db->messges($msg='error',$info='Service us info',$action='Updated');
            }
}

if($db->Save('editcat'))
{
   $table='categories';
   $Task = array('categories' => $db->Input('cat'));
    $update=$db->updateData($table,$Task,$condition="id=".$db->Input('catid'));
            if($update==true){
             echo $db->messges($msg='success',$info='Category info',$action='Updated');
            }else{
                echo $db->messges($msg='error',$info='Category info',$action='Updated');
            } 
}



if(isset($_FILES['ephotoname'])  || isset($_FILES['eaudioname']))
{
	$table='posts';
	$db->open_connection();
	$ds = DIRECTORY_SEPARATOR;
	  $dirPic=  '../../upload/img_posts/';
    $dirAudio= '../../upload/audio_posts/';
    $targetpicPath = $dirPic;
    $targetaudioPath = $dirAudio;
    $tempPFile = $_FILES['ephotoname']['tmp_name'];//temp name
    $PFilename = $_FILES['ephotoname']['name'];//file name
	$tempAFile = $_FILES['eaudioname']['tmp_name'];//temp name
    $AFilename = $_FILES['eaudioname']['name'];//file name//file name
	$ext = pathinfo($PFilename, PATHINFO_EXTENSION);
	$ext1 = pathinfo($AFilename, PATHINFO_EXTENSION);
	$phtofn   = 'ida-phto-'.time().rand(0,10).'.'.$ext;
	$audiofn  = 'ida-audio-'.time().rand(0,10).'.'.$ext1;
	$targetFilePic     =  $targetpicPath.$phtofn;
	$targetFileAudio   =  $targetaudioPath.$audiofn;
if (file_exists($targetpicPath.$db->Input('lastpic')))
        {
            if(!empty($_FILES['ephotoname'])){
           unlink($targetpicPath.$db->Input('lastpic'));
            }
        }
        if(file_exists($targetaudioPath.$db->Input('lastaudio')))
        {
            if(!empty($_FILES['eaudioname'])){
              unlink($targetaudioPath.$db->Input('lastaudio'));
            }
           
        }

        move_uploaded_file($tempPFile,$targetFilePic) ;
        move_uploaded_file($tempAFile,$targetFileAudio);

   $updateTask = array('photo' => empty($_FILES['ephotoname'])?$db->Input('lastpic'):$phtofn,'audio'=> empty($_FILES['eaudioname'])?$db->Input('lastaudio'):$audiofn);
   $update=$db->updateData($table,$updateTask,$condition="refers_id=".$db->Input('refers_id'));
	if($update==true){
			echo"Photo or audio saved and uploaded successfully!";
		}
		else{
		echo"Photo or audio not saved";
		}
    
	
	$db->close_connection();
	
}
   

if ($db->Save('makeReadble'))
{
     $html="";
    $condition="id=".$db->Input('id');
     $update=$db->updateData('contacts', array('checks' => '1'),$condition);
	//if($update==true){
    $runQuery=$db->query_display('contacts',$column_name = '',  $condition);
    $n=$db->num_rows($runQuery);
    if($n > 0){
    $row = $db->fetch_all_array($runQuery);
     
        $dates =date('F jS, y \A\t H:i:s A',strtotime($db->html_entity_decodes($row['dates'])));	                   //alert(_ajax);
        $html.='<div class="row"><div class="col-md-3 col-sm-3 col-xs-3"></div>';
        $html.='<div class="col-md-6 col-sm-6 col-xs-6" style="border:solid thin green"><p class="text-muted"><h3 style="color:#033ec1; font-size:18px">Read Contact Details <button class="btn btn-danger pull-right" onclick="window.location.reload()" >Close</button><hr  style="border:solid thin green"> </h3>';
        $html.='<h4>Names  : '.$db->html_entity_decodes($row['contacter_name']).'</h4>';
        $html.='<h4>Email  : '.$db->html_entity_decodes($row['contacter_email']).'</h4>';
        $html.='<h4>Details:'.$db->html_entity_decodes($row['contacts']).'</h4>';
        $html.='<h4 class="pull-right">Sent Date: '.$dates.'</h4>';
        $html.=' </p></div>';
        $html.='<div class="col-md-3 col-sm-3 col-xs-3"></div></div>';
         echo ($html);
        }

		// }else{
		// 	echo "<center>this contact can not readable!</center>";
		// }
}

if ($db->Save('EditPubAnounc'))
{
     $html="";
    $condition="notic_id=".$db->Input('id');
     //$update=$db->updateData('contacts', array('checks' => '1'),$condition);
  //if($update==true){
    $runQuery=$db->query_display('notifications',$column_name = '',  $condition);
    $n=$db->num_rows($runQuery);
    if($n > 0){
    $row = $db->fetch_all_array($runQuery);
    $id=$row['notic_id'];
      $logo=$db->html_entity_decodes($row['file']); $logo=($logo=="")?'':$logo;
        $dates =date('F jS, y \A\t H:i:s A',strtotime($db->html_entity_decodes($row['created_at'])));                     //alert(_ajax);
        $html.='<br /><div class="row"><div class="col-md-1 col-sm-1 col-xs-1"></div>';
        $html.='<div class="col-md-6 col-sm-6 col-xs-6" style="border:solid thin green"><p class="text-muted"><h3 style="color:#033ec1; font-size:18px">Read Announcement Details 
          <span class="pull-right"><button type="button" class="btn btn-info" onClick="editPubAnncs('.$id.')"> 
            <i class="fa fa-pencil"></i> Edit
          </button> <button class="btn btn-danger" onclick="window.location.reload()" >Close</button></span><hr  style="border:solid thin green"> </h3>';
        $html.='<div class="text-box" id="eeditStatuss"> </div><h4>Title  : <textarea class="form-control" id="etitle">'.$db->html_entity_decodes($row['title']).'</textarea></h4>';
        $html.='<h4>View Announcement  : <textarea class="form-control" style="height:120px" id="epubcAnnounce">'.$db->html_entity_decodes($row['notification']).'</textarea></h4>';
        // $html.='<h4>Details:'.$db->html_entity_decodes($row['contacts']).'</h4>';
        $html.='<h4 class="pull-right">Created Date: '.$dates.'</h4>';
        $html.=' </p></div>';
        $html.='<div class="col-md-5 col-sm-5 col-xs-5">

          <div  class=""> <label>Choose logo</label>            
                      <img src="../upload/annaunce/'.$logo.'" id=\'epreviewing\' alt=\'Add Photo  400x400\' style=\'
                    font-size: 30px;text-align: center;width: 60%;text-align: center;
                    line-height: 180px;left:5%;font-weight: bold;color: #C0C0C0;background-color: #FFFFFF;overflow: auto;border:solid;\'><br /><br />
                    <div class="alert alert-danger" id=\'epmessage\' style="display:none">
                     <strong>
                         <i class="fa fa-info"> alert Message :</i>
                    </strong>  
                    </div>
                        <dimension style="display:none">
                    <input type="number" value="500" id="ewidths"  />
                    <input type="number" value="400" id="eheights" />
                        </dimension>
                    </div>
                     <input type="text" hidden="hidden" value="'.$logo.'" id="logo">
                    <div class="">
                             
                       
                                <input type="file" onchange="echoosePhoto()"  id=\'ephotoname\' name=\'file\'  required="required"  class="form-control"/>
                           </div>
                            </div>
                            </div> 
                        </div>';
         echo ($html);
        }

    // }else{
    //  echo "<center>this contact can not readable!</center>";
    // }
}
