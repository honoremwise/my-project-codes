<?php 
include('../../Includes/Databases.php');

$db= new Databases();
if(isset($_GET['getArticle']))
{
 $db->open_connection();

$id=$db->maxrecords('posts');
$token=rand(10,90000).'.'.$id.'.'.rand(10,980000);
echo($token);

  $db->close_connection();
}


if($db->Save('getAllstudent')){
		   $db->open_connection();
		  $runQuery=$db->query_display('students',$column_name = '', $condition="");
		  $n=$db->num_rows($runQuery);
		  if($n > 0){
		   while ($numbers= $db->fetch_all_array($runQuery)) {
		  $ids=$numbers['st_code'];
		  $ids.=',';

		  echo $ids;
   }
}
}
?>

