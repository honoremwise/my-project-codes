<?php
include('../../Includes/Databases.php');
include('../../Includes/PHPMailer.php');
$db= new Databases();

if(isset($_POST['uploadPhoto']))
{
  $table='files';
  $db->open_connection();
    $ds = DIRECTORY_SEPARATOR;
    $dirPic=  '../../upload/img_posts/';
      $targetpicPath = $dirPic;
      $tempPFile = $_FILES['photo']['tmp_name'];//temp name
      $PFilename = $_FILES['photo']['name'];//file name
      $ext = pathinfo($PFilename, PATHINFO_EXTENSION);
      $phtofn   = 'ida-phto-'.time().rand(0,10).'.'.$ext;
     $targetFilePic     =  $targetpicPath.$phtofn;
       if( move_uploaded_file($tempPFile,$targetFilePic) ){
          
           $Task = array('file_name' => $phtofn,'file_format' =>'photo','refers_id' => $db->Input('refers_id'),'description' => $db->Input('desc') );
             $add=$db->addData($table,$Task);
             echo "Photo uploaded and saved!";

              /* watch the video for detailed instructions */
//$to = "+250781549903@vtext.com";
$mail = new PHPMailer();
 
// Set up SMTP
$mail->IsSMTP();                // Sets up a SMTP connection
$mail->SMTPDebug  = 2;          // This will print debugging info
$mail->SMTPAuth = true;         // Connection with the SMTP does require authorization
$mail->SMTPSecure = "tls";      // Connect using a TLS connection
$mail->Host = "smtp.gmail.com";
$mail->Port = 587;
$mail->Encoding = '7bit';       // SMS uses 7-bit encoding
 
// Authentication email.address
$mail->Username   = "respinho2014@gmail.com"; // Login
$mail->Password   = "bottom123456"; // Password
 
// Compose
$mail->Subject = "Testing";     // Subject (which isn't required)
$mail->Body = "Testing";        // Body of our message
 
// Send To
$mail->AddAddress( "+250781945189@vtext.com" ); // Where to send it
var_dump( $mail->send() );      // Send!
      }
    }

    if(isset($_POST['uploadAudio']))
{
  $table='files';
  $db->open_connection();
    $ds = DIRECTORY_SEPARATOR;
    $dirPic=  '../../upload/audio_posts/';
      $targetpicPath = $dirPic;
      $tempPFile = $_FILES['audio']['tmp_name'];//temp name
      $PFilename = $_FILES['audio']['name'];//file name
      $ext = pathinfo($PFilename, PATHINFO_EXTENSION);
      $phtofn   = 'ida-audio-'.time().rand(0,10).'.'.$ext;
     $targetFilePic     =  $targetpicPath.$phtofn;
       if( move_uploaded_file($tempPFile,$targetFilePic) ){
          
           $Task = array('file_name' => $phtofn,'file_format' =>'audio','refers_id' => $db->Input('refers_id'),'description' => $db->Input('adesc'),'files_owner' => $db->Input('artist') );
             $add=$db->addData($table,$Task);
             echo "Audio uploaded and saved!";     // Send!
      }
    }

    

  if(isset($_POST['edtuploadPhoto']))
{
  $table='files';
  $db->open_connection();
    $ds = DIRECTORY_SEPARATOR;
    $dirPic=  '../../upload/img_posts/';
      $targetpicPath = $dirPic;
      $tempPFile = $_FILES['photo']['tmp_name'];//temp name
      $PFilename = $_FILES['photo']['name'];//file name
      $ext = pathinfo($PFilename, PATHINFO_EXTENSION);
      $phtofn   = 'ida-phto-'.time().rand(0,10).'.'.$ext;
      $targetFilePic     =  $targetpicPath.$phtofn;

         $condition="files_id=".$db->Input('edtuploadPhoto');
          $fetching=$db->query_display($table,$column_name='', $condition);
           $rowcount=$db->num_rows($fetching);
           if($rowcount > 0){
           $row = $db->fetch_all_array($fetching);
   if(empty($_FILES['photo'])){
          $Task = array('file_name' => $row['file_name'],'file_format' =>'photo','refers_id' => $row['refers_id'],'description' => empty($_POST['desc'])?$row['description']:$_POST['desc'] );
           $update=$db->updateData($table,$Task,$condition);
             echo "Photo uploaded and saved!";
   }else{

        $imgs = $targetpicPath.$row['file_name'];
          $ts=0;
           if(!empty($row['file_name'])){
      while(file_exists($imgs)){
            unlink($imgs); 
        $ts++;
      }
    }
       if( move_uploaded_file($tempPFile,$targetFilePic) ){
         
           $Tasks = array('file_name' => $phtofn,'file_format' =>'photo','refers_id' => $row['refers_id'],'description' => empty($_POST['desc'])?$row['description']:$_POST['desc'] );
           $update=$db->updateData($table,$Tasks,$condition);
            echo "Photo uploaded and saved!";
          }
      }
    }
  }

if(isset($_POST['edtuploadAudio']))
{
  $table='files';
  $db->open_connection();
    $ds = DIRECTORY_SEPARATOR;
    $dirPic=  '../../upload/audio_posts/';
      $targetpicPath = $dirPic;
      $tempPFile = $_FILES['audio']['tmp_name'];//temp name
      $PFilename = $_FILES['audio']['name'];//file name
      $ext = pathinfo($PFilename, PATHINFO_EXTENSION);
      $phtofn   = 'ida-audio-'.time().rand(0,10).'.'.$ext;
      $targetFilePic     =  $targetpicPath.$phtofn;

         $condition="files_id=".$db->Input('edtuploadAudio');
          $fetching=$db->query_display($table,$column_name='', $condition);
           $rowcount=$db->num_rows($fetching);
           if($rowcount > 0){
           $row = $db->fetch_all_array($fetching);
   if(empty($_FILES['audio'])){
          $Task = array('file_name' => $row['file_name'],'file_format' =>'audio','refers_id' => $row['refers_id'],'description' => empty($_POST['adesc'])?$row['description']:$_POST['adesc'],'files_owner' => empty($_POST['eartist'])?$row['files_owner']:$_POST['eartist'] );
           $update=$db->updateData($table,$Task,$condition);
             echo "Audio uploaded and saved!";
   }else{

        $imgs = $targetpicPath.$row['file_name'];
          $ts=0;
           if(!empty($row['file_name'])){
      while(file_exists($imgs)){
            unlink($imgs); 
        $ts++;
      }
    }
       if( move_uploaded_file($tempPFile,$targetFilePic) ){
         
           $Tasks = array('file_name' => $phtofn,'file_format' =>'audio','refers_id' => $row['refers_id'],'description' => empty($_POST['adesc'])?$row['description']:$_POST['adesc'] );
           $update=$db->updateData($table,$Tasks,$condition);
            echo "Photo uploaded and saved!";
          }
      }
    }
  }
  
if(isset($_GET['loadphoto']))
{       $dirPic=  '../upload/img_posts/';
        $condition="refers_id=".$_GET['loadphoto']." AND file_format='photo'";
        $fetch_file=$db->query_display('files',$column_name='', $condition);
        $rowcount=$db->num_rows($fetch_file);
         if($rowcount > 0){
           echo"<span id='getoption'></span><br />";
              while($row = $db->fetch_all_array($fetch_file)){
                $id=$row['files_id'];
                $filename=$row['file_name'];
             
             echo "<div class='col-lg-4 col-md-4 col-sm-4' style='height:10%'>
                     <div class=\"panel panel-primary\">
                              
                                <div class=\"panel-body\">
                                 <img style='height:100px' class=\"img-responsive img-thumbnail\" src='".$dirPic.$filename."'>
                               </div>
                               <div class=\"panel-footer\">
                               <button class=\"btn btn-danger\" onclick=\"deletefile($id,'photo')\"><i class='fa fa-trash'></i></button>
                                <button class=\"btn btn-info\" onclick='setphotoeditor($id)'><i class='fa fa-pencil'></i></button>
                               </div>
                     </div>

             </div>";
            }
            echo"<div class='clearfix'></div><hr />";
            
     }
}

if(isset($_GET['loadaudio']))
{       $dirPic=  '../upload/audio_posts/';
        $condition="refers_id=".$_GET['loadaudio']." AND file_format='audio'";
        $fetch_file=$db->query_display('files',$column_name='', $condition);
        $rowcount=$db->num_rows($fetch_file);
         if($rowcount > 0){
           echo"<span id='getoptions'></span><br />";
              while($row = $db->fetch_all_array($fetch_file)){
                $id=$row['files_id'];
                $filename=$row['file_name'];
             
             echo "<div class='col-lg-4 col-md-4 col-sm-4' style='height:10%'>
                     <div class=\"panel panel-primary\">
                              
                                <div class=\"panel-body\">
                                 <video controls contextmenu='mp3 audio' poster=\"../img/audio.gif\" style='height:100px' class=\"img-responsive img-thumbnail\" src='".$dirPic.$filename."'>
                                 </video>
                               </div>
                               <div class=\"panel-footer\">
                               <button class=\"btn btn-danger\" onclick=\"deletefile($id,'audio')\"><i class='fa fa-trash'></i></button>
                                <button class=\"btn btn-info\" onclick='setaudioeditor($id)'><i class='fa fa-pencil'></i></button>
                               </div>
                     </div>

             </div>";
            }
            echo"<div class='clearfix'></div><hr />";
            
     }
}

