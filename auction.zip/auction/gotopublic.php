
<?php 

if(isset($_POST['set'])){
    $db= new Databases();
$start=$_POST['start'];
$end=$_POST['end'];

    if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$start) || preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$end) )
        {
        
    $addTask=array('item_id'=>$_GET['gotoPublic'], 'published_at'=>$start, '	item_deadlineTopublic'=>$end);
                $add=$db->addData('item_publisher', $addTask);
                if ($add == true) {
                    echo"<center><img src='img/progressring.gif'><h1>Process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./admin.php?publicproducts'; }, 1000);</script>";
        
                }
    }
}
?>
<div class="row">
    <h3 style="text-align: center;color:white">Add To Public</h3>
<div  class="form-module1">
                        <form action="#" class="form" id="productform" method="post">
                          <div class="clearfix"></div><p />
                            <div class="col-lg-1">
                            </div>
                            <div class="col-lg-3">
                            
                            <div  class="col-md-24">
                             <span style="color:white">Start from  :  :</span><input type="date" name='start'/>
                                
                        <div>
                              <div  class="col-md-24" >
                            <span style="color:white">Removed At  :</span><input type="date" name='end'/>
                           
                        <div>
                            <div  class="col-md-24">
                                <div class="clearfix"></div><hr />
                                  <input type="submit" name="set" value="Add">
                        <div>
                        
                         
                        </form>
</div>
                    </div>
