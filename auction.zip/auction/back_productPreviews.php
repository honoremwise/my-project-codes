 <?php
 
 $exp=explode("_",$_GET['productPreviews']);

//error_reporting(0);
$db= new Databases();

     $db->open_connection();
         $table='items';
         $item=$exp[1];
         $incr=+1;
        $db->updateData($table,array('vistors'=>$incr),$condition="item_id=".$item);
        $fetch=$db->query_display($table,$column_name="",'item_id='.$item);
        $rowcount=$db->num_rows($fetch);
         if($rowcount > 0){
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                 $item_id=$row['item_id'];
                                 $saler_id=$row['saler_id'];
                                 $item=$row['item'];
                                 $type=$row['type'];
                                 $size=$row['size'];
                                 $price=$row['post_price'];
                                 $category=$row['category'];
                                 $photo_view=$row['photo_view'];
                                 $description=$row['description'];
                                 $carry=$row['currency'];
                      
                                  $f=$db->query_display('deals',$column_name="price,MAX(price)as mxprice","item_id=".$item_id.' GROUP BY item_id');
                                 $r=$db->fetch_all_array($f);
                                  $post_price=$r['mxprice'];
                                   
                                    echo'<div class="col-md-9 top_brand_left">
                    <div class="hover14 column">
                    <h4 style="text-align:center">Product owner info 
                       <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block col-md-16">
                                        <div class="snipcart-thumb">';
                                         $fetch1=$db->query_display('salers',$column_name="",'saler_id='.$saler_id);
                                            $rowcount1=$db->num_rows($fetch);
                                            if($rowcount1 > 0){
                                                    while($row1=$db->fetch_all_array($fetch1)){
                                                        echo"Brand:".$row1['bussins_name'].",manager:".$row1['fname']." ".$row1['lname'].", phone:".$row1['phone'].", email:".$row1['email'].", country:".$row1['country'].", address:".$row1['address']." ";
                                                    }
                                            }
                                    

                                    echo "</div></div></figure></div></div></div></div><p />";

                                 echo'<hr /><div class="col-md-4 top_brand_left">
                    <div class="hover14 column">
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block col-md-16">
                                        <div class="snipcart-thumb" style="height:200px">
                                            <a href="./" >
                                            <img style="max-height:100%;min-height:100%;height:200px" class="img-rounded img-thumbnail" alt=" " src="activity/upload/lg_photo/'.$photo_view.'"></a>
                                            </div>
                                         <center><b>
                                        <p>Item:'. $item.'</p>
                                        <p>type:'. $type.'</p>
                                        <p>size:'. $size.'</p>
                                        <h4>price:'. $price.' ['. $carry.']'.'</h4>
                                         
                                        Description:
                                        '. $description.'
                                        </b></center>
                                       
                                    </div>


                                </figure>

                              
                            </div>
                        </div>
                    </div>
                </div>';
                echo"</div>";
                   }
         }else{
             echo"no product info were found!";
         }
    $item=$exp[1];
         $fetch=$db->query_display('items as i,deals as d,buyers as b',$column_name="d.created_at,d.message,d.buyer_id,b.fullname,b.lastname,b.phone,i.item_id,i.item,i.saler_id,i.post_price,i.post_price,i.category,i.photo_view,i.currency,d.deals_id,d.item_id,d.price",'i.item_id=d.item_id AND d.buyer_id=b.buyer_id AND i.item_id='.$item.' ORDER BY i.item_id DESC');
        $rowcount=$db->num_rows($fetch);
            if($rowcount > 0){
                                 $fs=$db->query_display('items as i,deals as d,buyers as b',$column_name="i.item_id,b.phone,b.fullname,b.lastname,d.price,d.currency,d.item_id,d.buyer_id,b.buyer_id,MAX(d.price)as mxprice",'d.item_id='.$item.' AND d.buyer_id=b.buyer_id GROUP BY d.item_id');
                                  $rs=$db->fetch_all_array($fs);
                                  $f=$db->query_display('items as i,deals as d,buyers as b',$column_name="i.item_id,b.phone,b.fullname,b.lastname,d.price,d.currency,d.item_id,d.buyer_id,b.buyer_id ",'d.price='.$rs['mxprice'].' AND d.buyer_id=b.buyer_id GROUP BY d.item_id');
                                
                                 $r=$db->fetch_all_array($f);
                                 $post_price=$rs['mxprice'];
                                  $currency=$rs['currency'];
                                   $custname=$r['fullname'];
                                   $contact=$r['phone'];

                                  echo'<div class="col-md-5 top_brand_left">
                    <div class="hover14 column">
                    <h4><hr />
                    <input type="submit" name="submit" id="viewpriceinfo" class="btn btn-info" value="Add your price" class="button" /></h4>
                   <form <div  class="form-module1"  style="display:none" id="priceform">
                    Your Full name:<input type="text" name="fullname" id="fname" placeholder=" full name">
                    Your Email:<input type="text" name="email" id="email" placeholder=" email">
                    Your Phone:<input type="text" name="phone" id="phone" placeholder=" phone">
                    Your Price:<input type="text" name="price" id="price">
                     <input type="hidden" value='.$item.' name="item_id" id="item_id" placeholder=" price">
                    <input type="hidden" value='.$price.' id="hprice" placeholder=" price">
                     <input type="hidden" name="saveprice" value="saveprice">
                    Your Currency: <select id="currency"  name="currency" placeholder="product currency">
                                    <option>currency</option> <option>USD</option> <option>FRW</option> <option>POUND</option> <option>EURO</option>
                                </select>
                    <br />
                    <center><input type="submit" name="saveprice" id="hidepriceinfo" style="display:none" class="btn btn-danger" value="Hide box" class="button" /> | 
                    <input type="submit" name="submit" id="addprice" class="btn btn-info" value="Save" class="button" /></center>
                    <hr />
                    </form>
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block col-md-16">
                                        <div class="snipcart-thumb"><h6>Best Dealer:'.$custname.',his/her contact:<b>:'.$contact.'</b>  his/her price :<span class="label label-warning">'.$post_price.' '.$currency.'</span></h6>';
                                    
       
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                 $item_id=$row['item_id'];
                                date_default_timezone_set('UTC');

                                 $carry=$row['currency'];
                                 $postprice=$row['price'];
                                 $postphone=$row['phone'];
                                 $postat=date("d-m-Y", strtotime($row['created_at']));
                                 $postname=$row['fullname'];
                                 $postcmt=empty($row['message'])?null:'<span class="label label-info">'.$row['message'].'</span>';
                                 echo'<ul class="list-group">
  <li class="list-group-item">|'.$postname.'|'.$postphone.'|'.$postat.'|    '.$postcmt.' <span class="badge">'.$postprice. ' '.$carry.'</span></li></ul>';
                   }
                   echo' </div></div></figure></div>
                        </div>
                    </div>
                </div>';

         }else{
             echo' <div class="col-md-5 top_brand_left">
                    <div class="hover14 column">
                    <h4><hr />
                    <input type="submit" name="submit" id="viewpriceinfo" class="btn btn-info" value="Add your price" class="button" /></h4>
                   <form <div  class="form-module1"  style="display:none" id="priceform">
                    Your Full name:<input type="text" name="fullname" id="fname" placeholder=" full name">
                    Your Email:<input type="text" name="email" id="email" placeholder=" email">
                    Your Phone:<input type="text" name="phone" id="phone" placeholder=" phone">
                    Your Price:<input type="text" name="price" id="price">
                     <input type="hidden" value='.$item.' name="item_id" id="item_id" placeholder=" price">
                    <input type="hidden" value='.$price.' id="hprice" placeholder=" price">
                     <input type="hidden" name="saveprice" value="saveprice">
                    Your Currency: <select id="currency"  name="currency" placeholder="product currency">
                                    <option>currency</option> <option>USD</option> <option>FRW</option> <option>POUND</option> <option>EURO</option>
                                </select>
                    <br />
                    <center><input type="submit" name="saveprice" id="hidepriceinfo" style="display:none" class="btn btn-danger" value="Hide box" class="button" /> | 
                    <input type="submit" name="submit" id="addprice" class="btn btn-info" value="Save" class="button" /></center>
                    <hr />
                    </form>
                            <div class="agile_top_brand_left_grid1">

                                <figure>
                                    <div class="snipcart-item block col-md-16"> <ul class="list-group">
  <li class="list-group-item">There are no deals made on this products</li>
</ul></div></div></figure></div>
                        </div>
                    </div>
                </div>';
         }
         echo"</div>";
         ?>