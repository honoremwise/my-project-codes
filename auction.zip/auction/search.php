<?php
//error_reporting(0);
$db= new Databases();
$item=$_GET['search'];
     $db->open_connection();
         $table='items';
      $fetch=$db->query_display($table,$column_name="",'item="'.$item.'" OR category="'.$item.'"');
      $rowcount=$db->num_rows($fetch);
          echo'<div class="top-brands">
    <div class="container">';
         if($rowcount > 0){
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                $item_id=$row['item_id'];
                                 $saler_id=$row['saler_id'];
                                 $item=$row['item'];
                                 $category=$row['category'];
                                 $photo_view=$row['photo_view'];
                               
                                 $carry=$row['currency'];
                                  $f=$db->query_display('deals',$column_name="price,MAX(price)as mxprice","item_id=".$item_id.' GROUP BY item_id');
                                 $r=$db->fetch_all_array($f);
                                  $post_price=$r['mxprice'];
                                 echo'<div class="col-md-3 pull-right"style="border:dotted red">
                    <div class="hover14 column">
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block">
                                        <div class="snipcart-thumb" style="height:160px">
                                            <a href="./" >
                                            <img style="max-height:100%;min-height:100%;height:160px" class="img-rounded img-thumbnail" alt=" " src="activity/upload/lg_photo/'.$photo_view.'"></a>

                                            
                                        </div>
                                        <p>Item:'. $item.'</p>
                                            <h4>Highest Price '.$post_price .'  ['. $carry.']<span></span></h4>
                                        <div class="snipcart-details top_brand_home_details">
                                            <form action="./?productPreviews='.md5('helllo auction').md5('am fine  dear').md5('helllo auction').md5('am fine  dear').'_'.$item_id.'" method="post">
                                                <input type="submit" class="button" value="select">  
                                            </form>
                                        </div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>';
                   }
         }else{
             echo"no product were found!";
         }
         echo"</div>
</div>";

   

    ?>

