<!-- top-brands -->
<?php   if ((isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){ ?>

<?php }else{
   require"back_allproduct.php";
  require'products_indeals.php';


 ?>


<?php } ?>
<!-- //top-brands -->