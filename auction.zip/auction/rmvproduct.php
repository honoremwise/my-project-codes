<?php

//error_reporting(0);
$db= new Databases();

     $db->open_connection();
         $table='items';
      $today= date('Y-m-d');
      $fetch=$db->query_display('items as i,item_publisher as p, salers as s',$column_name="i.item_id,i.item ,i.saler_id,i.category,i.photo_view,i.currency,i.post_price,p.pub_id,p.item_id,p.published_at,p.item_deadlineTopublic,s.saler_id,s.bussins_name,s.phone",
      "i.item_id=p.item_id AND s.saler_id=i.saler_id AND p.item_deadlineTopublic <='$today'");
      $rowcount=$db->num_rows($fetch);
          echo'<div class="top-brands">
    <div class="container">
       <h3>Products are not on Public</h3><hr />'; 
         if($rowcount > 0){
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                $item_id=$row['item_id'];
                                 $saler_id=$row['saler_id'];
                                 $item=$row['item'];
                                 $category=$row['category'];
                                 $photo_view=$row['photo_view'];
                                   $addat=$row['published_at'];
                                   $rmvat=$row['item_deadlineTopublic'];
                                 $carry=$row['currency'];
                                 $post_price=$row['post_price'];
                                 $bussins_name=$row['bussins_name'];
                                 echo'<div class="col-md-3 top_brand_left">
                    <div class="hover14 column">
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block">
                                        <div class="snipcart-thumb" style="height:160px">
                                            <a href="./" >
                                            <img style="max-height:100%;min-height:100%;height:160px" class="img-rounded img-thumbnail" alt=" " src="activity/upload/lg_photo/'.$photo_view.'"></a>

                                            
                                        </div>
                                            <p>Item:'. $item.'</p>
                                            <p>Add At:'.$addat.'</p>
                                            <p>Remove At:'.$rmvat.'</p>
                                            <p>Business Name:'. $bussins_name.'</p>
                                            <h4>'.$post_price .'  ['. $carry.']<span></span></h4>
                                        <div class="snipcart-details top_brand_home_details">
                                           
                                              <form action="./admin.php?gotoPublic='.$item_id.'" method="post">
                                                <input type="submit" class="button" value="Add to Public">  
                                            </form>
                                        </div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>';
                   }
         }else{
             echo"no product were found!";
         }
         echo"</div>
</div>";

   

    ?>


