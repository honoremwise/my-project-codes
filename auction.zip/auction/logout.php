<?php
 if(isset($_COOKIE["auth_id"])) {
            setcookie("auth_id", $_COOKIE["auth_id"], strtotime( '-5 days' ), '/');
        }else if(isset($_COOKIE["auth_id1"])) {
                        setcookie("auth_id1", $_COOKIE["auth_id1"], strtotime( '-5 days' ), '/');
                    }
        // Destroy the session variables
        
        // Double check to see if their sessions exists
                    if(isset($_SESSION['auth_id'])){
                    echo"<center><img src='img/progressring.gif'><h1>logout In process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./'; }, 3000);</script>";
                   exit();
                    } else{
                     echo"<center><img src='img/progressring.gif'><h1>logout In process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./'; }, 3000);</script>";
                 exit();
                    } 

                   

                     if(isset($_SESSION['auth_id1'])){
                    echo"<center><img src='img/progressring.gif'><h1>logout In process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./'; }, 3000);</script>";
                 exit();
                    } else{
                     echo"<center><img src='img/progressring.gif'><h1>logout In process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./'; }, 3000);</script>";
              exit();
                    } 