
<div class="row">
    <h3 style="text-align: center">Add product</h3>
<div  class="form-module1">
                        <form action="#" class="form" id="productform" method="post">
                            <div class="clearfix"></div><p />
                            <div class="col-lg-1">
                            </div>
                            <div class="col-lg-3">
                            <input type="text" id="item" name="item" placeholder="product name">
                            <input type="text" id="type" name="type" placeholder="product type">
                            <input type="text" id="size" name="size" placeholder="product size">
                                <span  id="counting"></span>
                            </div>
                            <div class="col-lg-3">
                            <input type="text" id="post_price" size="6" name="post_price" placeholder="product price">

                                <select id="currency"  name="currency" placeholder="product currency">
                                    <option>currency</option> <option>USD</option> <option>FRW</option> <option>POUND</option> <option>EURO</option>
                                </select>
                                <select id="categories" name="categories" placeholder="product categories">
                                    <option>select category</option> <option>auto</option>  <option>properties</option>
                                </select>

                            <textarea class="" id="desc" name="desc"  onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Description...';}">Description...</textarea>
                            <br />
                            </div>
                            <div class="col-lg-4">
                                <img src="img/15.png" id="pro_previewing">
                                <input type="file" id="choose_item_photo" name="choose_item_photo">
                                <span id="message"></span>
                            </div>
                            <div class="col-lg-1">
                            </div>
                            <div class="col-lg-3" style="text-align: center"> </div>
                            <div class="col-lg-12">
                                <input type="hidden" name="salers_id" id="salers_id" value="<?php print $_COOKIE["auth_id"];?>">
                                <input type="submit" name="addproduct" id="addproduct" value="Save product">
                            </div>
                            <div class="col-lg-3"></div>
                        </form>
</div>
                    </div>


