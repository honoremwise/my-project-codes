<?php
$db= new Databases();
$db->open_connection();
         $table='items';
         $get=isset($_COOKIE["auth_id"])?$_COOKIE["auth_id"]:0;
        $fetch=$db->query_display($table,$column_name="",'saler_id='.$get);
        $rowcount=$db->num_rows($fetch);
         if($rowcount > 0){
         $row=$db->fetch_all_array($fetch);
         ?>

<div class="row">
    <h3 style="text-align: center">Edit product</h3>
<div  class="form-module1">
                        <form action="#" class="form" id="productform" method="post">
                            <div class="clearfix"></div><p />
                            <div class="col-lg-1">
                            </div>
                            <div class="col-lg-3">
                            <input type="text" id="item" name="item" value=<?php echo empty($row['item'])?'':$row['item']; ?> placeholder="product name">
                            <input type="text" id="type" name="type" value=<?php echo empty($row['type'])?'':$row['type']; ?> placeholder="product type">
                            <input type="text" id="size" name="size" value=<?php echo empty($row['size'])?'':$row['size']; ?> placeholder="product size">
                                <span  id="counting"></span>
                            </div>
                            <div class="col-lg-3">
                            <input type="text" id="post_price" size="6" name="post_price" value=<?php echo empty($row['post_price'])?'':$row['post_price']; ?> placeholder="product price">

                                <select id="currency"  name="currency"  placeholder="product currency">
                                    <option><?php echo empty($row['currency'])?'':$row['currency']; ?></option> <option>frw</option>  <option>$</option>
                                </select>
                                <select id="categories"  name="categories" placeholder="product categories">
                                    <option><?php echo empty($row['category'])?'':$row['category']; ?></option> <option>auto</option>  <option>properties</option>
                                </select>

                            <textarea class="" id="desc" name="desc"  onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Description...';}"><?php echo empty($row['description'])?'Description....':$row['description']; ?> </textarea>
                            <br />
                            </div>
                            <div class="col-lg-4">
                                <img  src="activity/upload/lg_photo/<?php echo empty($row['photo_view'])?'':$row['photo_view']; ?>" id="pro_previewing">
                                <input type="file" id="choose_item_photo" name="choose_item_photo">
                                <span id="message"></span>
                            </div>
                            <div class="col-lg-1">
                            </div>
                            <div class="col-lg-3" style="text-align: center"> </div>
                            <div class="col-lg-12">
                            <input type="hidden" name="latestphoto" id="latestphoto" value=<?php print$row['photo_view'];?> >
                              <input type="hidden" name="item_id" id="item_id" value="<?php print$row['item_id'];?>">
                                <input type="hidden" name="salers_id" id="salers_id" value="<?php print $_COOKIE["auth_id"];?>">
                                <input type="submit" name="editproduct" id="editproduct" value="Edit product">
                            </div>
                            <div class="col-lg-3"></div>
                        </form>
</div>
                    </div>
                    <?php }else{
                        echo"please not edit made, try again . Go bak";
                    } ?>


