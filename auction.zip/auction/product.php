<?php
//error_reporting(0);
$db= new Databases();
if(isset($_GET['proedit'])){
require'editproduct.php';
}else if(isset($_GET['prodelete'])){
    
    $exp=explode("_",$_GET['prodelete']);
      echo'<div class="col-md-3 top_brand_left"></div><div class="col-md-6 top_brand_left">
                    <div class="hover14 column">
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block">
                                        <div class="snipcart-thumb">
                                            
                                        </div>
                                        <div class="snipcart-details top_brand_home_details">
                                            <form action="#" method="post">
                                            do realy want to delete this product '.$_GET['prodelete'].'<br />,click OK.
                                                 <br /><a href="./?products&prodoit='.$_GET['prodelete'].'" class="btn btn-info">Ok</a>
                                                   <a href="./?products" class="btn btn-danger">CLose</a>
                                                   
                                            </form>
                                        </div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>';
    }else if(isset($_GET['prodoit'])){
 $exp=explode("_",$_GET['prodoit']);

	$db->open_connection();
	$id=$exp[1];
	$delete=$db->deleteData('item_publisher',"item_id=".$id);
    $delete.=$db->deleteData('deals',"item_id=".$id);
	$delete.=$db->deleteData('items',"item_id=".$id);
	
	if($delete==true){
        echo"<center><img src='img/progressring.gif'><h1>Deletion In process ,wait......</h1></center><script>setInterval(function(){ return window.location.href='./?products'; }, 3000);</script>";
       
    }
        }else{
     $db->open_connection();
         $table='items';
         $get=isset($_COOKIE["auth_id"])?$_COOKIE["auth_id"]:0;
        $fetch=$db->query_display($table,$column_name="",'saler_id='.$get);
        $rowcount=$db->num_rows($fetch);
        echo"<h3 style=\"text-align: center\">All product</h3>
<div  class=\"form-module1\">";
         if($rowcount > 0){
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                $item_id=$row['item_id'];
                                 $saler_id=$row['saler_id'];
                                 $item=$row['item'];
                                 $type=$row['type'];
                                 $size=$row['size'];
                                 $post_price=$row['post_price'];
                                 $category=$row['category'];
                                 $photo_view=$row['photo_view'];
                                 $description=$row['description'];
                                 $carry=$row['currency'];

                                 echo'<div class="col-md-3 top_brand_left">
                    <div class="hover14 column">
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block">
                                        <div class="snipcart-thumb" style="height:160px">
                                            <a href="./" >
                                            <img style="max-height:100%;min-height:100%;height:160px" class="img-rounded img-thumbnail" alt=" " src="activity/upload/lg_photo/'.$photo_view.'"></a>

                                            
                                        </div>
                                        <p>Item:'. $item.'</p>
                                            <p>Size:'. $size.'</p>
                                            <h4>Fixed Price '.$post_price .'  ['. $carry.']<span></span></h4>
                                        <div class="snipcart-details top_brand_home_details">
                                            <form action="#" method="post">
                                                 <a href="./?products&proedit='.md5('helllo auction').md5('am fine  dear').md5('helllo auction').md5('am fine  dear').'_'.$item_id.'" class="btn btn-info">Edit</a>
                                                   <a href="./?products&prodelete='.md5('helllo auction').md5('am fine  dear').md5('helllo auction').md5('am fine  dear').'_'.$item_id.'" class="btn btn-danger">Delete</a>
                                                    <a href="./?productPreview='.md5('helllo auction').md5('am fine  dear').md5('helllo auction').md5('am fine  dear').'_'.$item_id.'" class="btn btn-default">Preview</a>
                                                   
                                            </form>
                                        </div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>';
                   }
         }else{
             echo"no product were found!";
         }
         echo"</div>";

}    

    ?>