<?php include "Includes/DbConfig.php";
include('Includes/Databases.php'); ?>


<?php include "head.php" ?>


<div class="agileits_header">
    <div class="w3l_offers">
        <a href="./">Auction | Admin Panel</a>
    </div>
   
    <!--<div class="w3l_search">
        <form action="./" method="GET">
            <input type="text" name="search" id="search" value="Search a product..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search a product...';}" required="">
            <input type="submit" value=" " name="searchbtns">
        </form>
    </div>-->
    
    <?php   if ( (isset($_SESSION['auth_id1']) || isset($_COOKIE["auth_id1"])) && (isset($_SESSION['admin']) || isset($_COOKIE["admin"])) ){?>
      <div class="product_list_header">

          <ul>
              <li class="dropdown profile_details_drop">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Welcome, Admin<span class="caret"></span></a>
                  <div class="mega-dropdown-menu">
                      <div class="w3ls_vegetables">
                          <ul class="dropdown-menu drp-mnu">
                              <li><a href="logout.php">Logout </a></li>
                              <!--<li><a href="login.html">My Profile</a></li>-->
                          </ul>
                      </div>
                  </div>
              </li>
          </ul>

        </div>

<script>
    $(document).ready(function() {
        var navoffeset=$(".agileits_header").offset().top;
        $(window).scroll(function(){
            var scrollpos=$(window).scrollTop();
            if(scrollpos >=navoffeset){
                $(".agileits_header").addClass("fixed");
            }else{
                $(".agileits_header").removeClass("fixed");
            }
        });

    });
</script>

<?php }  if ((isset($_SESSION['auth_id1']) || isset($_COOKIE["auth_id1"])) && (isset($_SESSION['admin']) || isset($_COOKIE["admin"])) ){ ?>

<div class="logo_products">
<div class="container">
<div class="w3ls_logo_products_left1">
<ul class="special_items" style="color:white">
<li><a href="./admin.php" style="color:white">Products </a><i>/</i></li>
<li><a href="admin.php?publicproducts" style="color:white">Public Products</a><i>/</i></li>
<li><a href="./admin.php?rmvproduct" style="color:white">Products removed on public</a><i>/</i></li>

<!--<li><a href="./proexpired">Product blocked </a></li>-->
<li> &nbsp;&nbsp;</li>
</ul>
</div>
</div>

</div>
 <?php } if (!(isset($_SESSION['auth_id1']) || isset($_COOKIE["auth_id1"])) && (isset($_SESSION['admin']) || isset($_COOKIE["admin"])) ){ ?>
<!-- login -->
<div class="w3_login">
    <h3 style="color:white">Sign In </h3>
    <div class="w3_login_module">
        <div class="module form-module">
            <div class="toggle"><i class="fa fa-times fa-pencil"></i>
                <div class="tooltip"></div>
            </div>
            <div class="form">
                <h2>Login to your account</h2>
                <form action="#" method="post" id="adminform">
                    <input type="text" name="username" id="username" placeholder="Username or business name" required=" ">
                    <input type="password" name="password" id="password" placeholder="Password" required=" ">
                    <input type="hidden" name="btnsigninadmin" id="btnsigninadmin" value="btnsigninadmin">
                    <input type="submit" value="Login" id="adminlogin">
                </form>

            </div>
           
        </div>
    </div>
    <script>
        $('.toggle').click(function(){
            // Switches the Icon
            $(this).children('i').toggleClass('fa-pencil');
            // Switches the forms
            $('.form').animate({
                height: "toggle",
                'padding-top': 'toggle',
                'padding-bottom': 'toggle',
                opacity: "toggle"
            }, "slow");
        });
    </script>
    <?php }else{
    

    if(isset($_GET['products'])){

    }else if(isset($_GET['publicproducts'])){
      require'publicproduct.php';
    }else if(isset($_GET['gotoPublic'])){
           require'gotopublic.php';
    }else if(isset($_GET['rmvPublic'])){
           require'rmvPublic.php';
    }else if(isset($_GET['rmvproduct'])){
     include'rmvproduct.php';
    }else{
       require'allproducts.php';
    }


    
    } ?>
</div>
<!-- //login -->
<?php include "footer.php" ?>