<!-- login -->
<div class="w3_login">
    <h3>Sign In or Sign Up</h3>
    <div class="w3_login_module">
        <div class="module form-module">
            <div class="toggle"><i class="fa fa-times fa-pencil"></i>
                <div class="tooltip">Sign Up</div>
            </div>
            <div class="form">
                <h2>Login to your account</h2>
                <form action="#" method="post" id="salrsloginform">
                    <input type="text" name="username" id="username" placeholder="Username or business name" required=" ">
                    <input type="password" name="password" id="password" placeholder="Password" required=" ">
                    <input type="hidden" name="btnsignin" id="btnsignin" value="btnsignin">
                    <input type="submit" value="Login" id="salrslogin">
                </form>

            </div>
            <div class="form">
                <h2>Create an account</h2>
                <form action="#" id="salrssignup" method="post">
                    <input type="text" id="firstname" name="firstname" placeholder="First name">
                    <input type="text" id="lastname" name="lastname" placeholder="Last name">
                    <input type="text" id="businessname"  name="businessname" placeholder="Business name">
                    <span id="verifybusinss"> </span>
                    <input type="password" id="password" name="password" placeholder="Password">
                    <input type="password" id="confpassword" name="confpassword" placeholder="Confirm Password">
                    <input type="email" id="email" name="email" placeholder="Email Address">
                    <input type="text" id="phone" name="phone" placeholder="Phone Number">
                    <input type="text" id="address" name="address" placeholder="Address ..">
                    <input type="text" id="country" name="country" placeholder="country">
                    <textarea class="form-control" id="about" name="about"  onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'About my Business...';}">About my Business...</textarea>
                    <br />
                    <input type="hidden" name="btnssignup" id="btnssignup" value="btnssignup">
                    <input type="submit" name="btnsignup" id="btnsignup" value="Register">
                </form>
            </div>
        </div>
    </div>
    <script>
        $('.toggle').click(function(){
            // Switches the Icon
            $(this).children('i').toggleClass('fa-pencil');
            // Switches the forms
            $('.form').animate({
                height: "toggle",
                'padding-top': 'toggle',
                'padding-bottom': 'toggle',
                opacity: "toggle"
            }, "slow");
        });
    </script>
</div>
<!-- //login -->