<?php

 $exp=explode("_",$_GET['productPreview']);

//error_reporting(0);
$db= new Databases();

     $db->open_connection();
         $table='items';
         $item=$exp[1];
         $get=isset($_COOKIE["auth_id"])?$_COOKIE["auth_id"]:0;
        $fetch=$db->query_display($table,$column_name="",'item_id='.$item.' AND saler_id='.$get);
        $rowcount=$db->num_rows($fetch);
         if($rowcount > 0){
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                 $item_id=$row['item_id'];
                                 $saler_id=$row['saler_id'];
                                 $item=$row['item'];
                                 $type=$row['type'];
                                 $size=$row['size'];
                                 $price=$row['post_price'];
                                 $category=$row['category'];
                                 $photo_view=$row['photo_view'];
                                 $description=$row['description'];
                                 $carry=$row['currency'];
                      
                                  $f=$db->query_display('deals',$column_name="price,MAX(price)as mxprice","item_id=".$item_id.' GROUP BY item_id');
                                 $r=$db->fetch_all_array($f);
                                  $post_price=$r['mxprice'];
                                   echo"<h3 style=\"text-align: center\">Preview product :".$item."</h3>
<div  class=\"form-module1\">";
                                 echo'<div class="col-md-6 top_brand_left">
                    <div class="hover14 column">
                    <h4 style="text-align:center">Product Info</h4>
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block col-md-16">
                                        <div class="snipcart-thumb" style="height:200px">
                                            <a href="./" >
                                            <img style="max-height:100%;min-height:100%;height:200px" class="img-rounded img-thumbnail" alt=" " src="activity/upload/lg_photo/'.$photo_view.'"></a>
                                            </div>
                                         <center><b>
                                        <p>Item:'. $item.'</p>
                                        <p>type:'. $type.'</p>
                                        <p>size:'. $size.'</p>
                                        <h4>price:'. $price.' ['. $carry.']'.'</h4>
                                         
                                        Description:
                                        '. $description.'
                                        </b></center>
                                       
                                    </div>


                                </figure>

                              
                            </div>
                        </div>
                    </div>
                </div>';
                echo"</div>";
                   }
         }else{
             echo"no product info were found!";
         }
    $item=$exp[1];
         $get=isset($_COOKIE["auth_id"])?$_COOKIE["auth_id"]:0;
         $fetch=$db->query_display('items as i,deals as d,buyers as b',$column_name="d.created_at,d.message,d.buyer_id,b.fullname,b.lastname,b.phone,i.item_id,i.item,i.saler_id,i.post_price,i.post_price,i.category,i.photo_view,i.currency,d.deals_id,d.item_id,d.price",'i.item_id=d.item_id AND d.buyer_id=b.buyer_id AND i.item_id='.$item.' AND i.saler_id='.$get.' ORDER BY i.item_id DESC');
        $rowcount=$db->num_rows($fetch);
  if($rowcount > 0){
                                 $f=$db->query_display('deals as d,buyers as b',$column_name="b.phone,b.fullname,b.lastname,d.price,d.currency,d.item_id,d.buyer_id,b.buyer_id,MAX(d.price)as mxprice","d.item_id=".$item.' AND d.buyer_id=b.buyer_id GROUP BY d.item_id');
                                 $r=$db->fetch_all_array($f);
                                 
                                  
                                  $post_price=$r['mxprice'];
                                  $currency=$r['currency'];
                                   $custname=$r['fullname'];
                                   $contact=$r['phone'];
                                  echo'<div class="col-md-6 top_brand_left">
                    <div class="hover14 column">
                    <h4 style="text-align:center">Product Deals</h4>
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block col-md-16">
                                        <div class="snipcart-thumb"><b>Best Dealer:'.$custname.'</b>,his/her contact:<b>:'.$contact.'</b>  his/her price :<span class="label label-warning">'.$post_price.' '.$currency.'</span>';
                                    
       
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                 $item_id=$row['item_id'];
                                date_default_timezone_set('UTC');

                                 $carry=$row['currency'];
                                 $postprice=$row['price'];
                                 $postphone=$row['phone'];
                                 $postat=date("d-m-Y", strtotime($row['created_at']));
                                 $postname=$row['firstname'].' '.$row['lastname'];
                                 $postcmt=empty($row['message'])?null:'<span class="label label-info">'.$row['message'].'</span>';
                                 echo'<ul class="list-group">
  <li class="list-group-item">|'.$postname.'|'.$postphone.'|'.$postat.'|    '.$postcmt.' <span class="badge">'.$postprice. ' '.$carry.'</span></li></ul>';
                   }
                   echo' </div></div></figure></div>
                        </div>
                    </div>
                </div>';

         }else{
             echo' <div class="col-md-6 top_brand_left">
                    <div class="hover14 column">
                    <h4 style="text-align:center">Product Deals</h4>
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block col-md-16"> <ul class="list-group">
  <li class="list-group-item">There are no deals made on this products</li>
</ul></div></div></figure></div>
                        </div>
                    </div>
                </div>';
         }


?>