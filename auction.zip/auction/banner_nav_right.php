<?php   if ( !(isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){
       require"onslidershow.php";
 }else{

    if(isset($_GET['addproduct'])) {
           echo'<span id="searchout"></span>';
    include 'addproduct.php';
    }else if(isset($_GET['products'])) {
    include 'product.php';
    }else if(isset($_GET['proDeals'])){
           echo'<span id="searchout"></span>';
        require"proDeals.php";
    }else if(isset($_GET['productPreview'])){
        echo'<span id="searchout"></span>';
        require'productPreview.php';
    }else{?>

<span id="searchout"></span>

<?php include 'product.php'; ?>

<?php } } ?>