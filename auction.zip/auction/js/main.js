var _URL = window.URL || window.webkitURL;
function _(x) {
    return document.getElementById(x);
}
function ajaxReturn(x){
    try{
        if(x.readyState == 4 && x.status == 200){
            return true;
        }
    }catch ( e ){
        // IE8,9 Will throw exceptions on certain host objects #9897
        return false;
    }
}
$(document).ready(function() {
    function errorHandler() {

    }
        function abortHandler() {

        }

        function progressHandler(event){
            // $("#euploadPhoto").hide();
            // $("#eprogress-barimg").show();
            var percent = (event.loaded / event.total) * 100;
           $('#counting').css('width', Math.round(percent) + '%');
            document.getElementById("counting").innerHTML = Math.round(percent) + "% complete ....";
            $('#counting').fadeOut(1000, function (){
                $('#counting').html('');
            });
            ///setTimeout($("#counting").html(''), 4000);
        }


        function completeHandler(event){
            alert('File Uploaded successfully');
            // //document.getElementById("message").innerHTML = 'File Uploaded successfully';
            // $("#progress-baraudio").hide();
            // $("#uploadAudio").hide();
            // $("#progress-baraudio").hide();
            // $("#aperctage").hide();
            // $("#adesc").val('');
            // $("#adesc").hide();
            // $("#artist").val('');
            // $("#artist").hide();
            // return loadaudio();

        }

        function fileIsLoaded(e) {
            e.preventDefault();
            $('#pro_previewing').show();
            $("#pro_previewing").css("color", "green");
            //$('#image_preview').css("display", "block");
            $('#pro_previewing').attr('src', e.target.result);
            $('#pro_previewing').attr('width', '100%');
            $('#pro_previewing').attr('max-width', '300px');

        };

        productPhoto=function() {

            try{
                var img = new Image();
                var file = _('choose_item_photo').files[0];
                var imgwidth = 0;
                var imgheight = 0;

                var imagefile = file.type;

                var match = ["image/jpeg", "image/png", "image/jpg", "image/ico"];

                if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]) || (imagefile == match[3]))) {
                    $('#pro_previewing').show();
                    $("#message").show(); //show submit button
                    $('#pro_previewing').attr('src', 'img/15.png');
                    $('#pro_previewing').attr('width', '100%');
                    $('#pro_previewing').attr('max-width', '300px');
                    $('#pro_previewing').attr('line-height', '16');
                    $("#message").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg ,ico and png Images type allowed</span>");
                    return false;
                } else {
                    img.src = _URL.createObjectURL(file);
                    img.onload = function() {
                        imgwidth = this.width;
                        imgheight = this.height;

                            $("#message").hide(); //show submit button
                            var reader = new FileReader();
                            reader.onload = fileIsLoaded;
                            reader.readAsDataURL(_('choose_item_photo').files[0]);

                    }
                }
            }catch ( e ) {
                // IE8,9 Will throw exceptions on certain host objects #9897
                return false;
            }
        }
 function businessname(){
      
                var box = $("#verifybusinss");
                var input = $("#businessname").val();
                $.ajax({
                    type: 'POST',
                    url: "activity/Adddata.php",
                    data: 'verify_business='+input+'&find=find',
                    dataType: 'json',
                    processData: true,
                    async: true,
                    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                    beforeSend: function (){
                        box.css('border','solid'); 
                        box.css('border-color','red');
                          box.css('border-width','thin');
                        box.html('verify in proccess.....');
                        box.css('font-weight', 'bold');
                        box.css('font-size', '1em');
                    },
                    success: function (response){
                        if (response.status == 'find'){
                            box.html('Please, this business name has been taken! enter untaken.');
                        } else {
                            box.html('');
                        }
                    },
                    error: function (xhr, ajaxOptions, thrownError){
                        if (thrownError) {
                            return false;
                        }
                    }
                });
        }

  $("#businessname").keyup(function (e){
        e.preventDefault();
        return businessname();

});

    $("#choose_item_photo").change(function (e){
        e.preventDefault();
        return productPhoto();

});
    // $("#businessname").keyup(function (e){
    //     e.preventDefault();
    //     var box = $("#verifybusinss");
    //     var input = $("#businessname");
    //     var vrfy = verify_business(input.val(),box);

    //     if(vrfy===true){
    //         box.css('font-weight', 'bold');
    //         box.css('font-size', '1em');

    //         input.css('border','solid'); input.css('border-color','red');  input.css('border-width','thin');
    //         box.html('Please, this business name has been taken! enter untaken.');
    //         alert('ok');
    //     }else if(vrfy===false){
    //         box.val('');
    //         input.css('border','solid'); input.css('border-color','#d9d9d9');  input.css('border-width','thin');
    //     }
    // });

    $("#username").keyup(function (e){
            e.preventDefault();
            $("#username").css('border','solid'); $("#username").css('border-color','#d9d9d9'); $("#username").css('border-width','thin');
            //return false;
});

        $("#password").keyup(function (e){
            e.preventDefault();
            $("#password").css('border','solid'); $("#password").css('border-color','#d9d9d9'); $("#password").css('border-width','thin');
            //return false;
        });

        $("#salrslogin").click(function (e){
            e.preventDefault();
            var btn = $("#salrslogin");
            var myDatas = $("#salrsloginform").serialize();

            if($("#password").val()==="") {
                $("#password").css('border','solid'); $("#password").css('border-color','red'); $("#password").css('border-width','thin');
                //return false;
            }else {
                $("#password").css('border','solid'); $("#password").css('border-color','#d9d9d9;');  $("#password").css('border-width','thin');
            }


            if($("#username").val()==="") {
                $("#username").css('border','solid'); $("#username").css('border-color','red'); $("#username").css('border-width','thin');
                //return false;
            }else {
                $("#username").css('border','solid'); $("#username").css('border-color','#d9d9d9;');  $("#username").css('border-width','thin');
            }
            if($("#username").val()==="" || $("#password").val()==="") {

                alert('Fill submission fields');
                btn.css('background', 'red');
            } else {
                $.ajax({
                    type: 'POST',
                    url: "activity/Adddata.php",
                    data: myDatas,
                    dataType: 'json',
                    processData: true,
                    async: true,
                    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                    beforeSend: function () {
                        btn.css('background', '#343434');
                        btn.val('Logged in proccess.....');
                    },
                    success: function (response) {
                        if (response.status == 'salers_success'){
                           // alert(response.status);
                            btn.css('background', '#0c7aa8');
                            btn.val('Logged In ......');
                            setTimeout(' window.location.href = "./?home"; ', 4000);
                            $("#username").val('');
                            $("#password").val('');
                        } else {
                              alert('incorect username and password');
                            btn.val('Login');
                        }
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        if (thrownError) {
                            btn.css('background', 'red');
                            btn.val('Logged in fail');
                        }
                    }
                });
                return false;
            }

        });



          $("#adminlogin").click(function (e){
            e.preventDefault();
            var btn = $("#adminlogin");
            var myDatas = $("#adminform").serialize();

            if($("#password").val()==="") {
                $("#password").css('border','solid'); $("#password").css('border-color','red'); $("#password").css('border-width','thin');
                //return false;
            }else {
                $("#password").css('border','solid'); $("#password").css('border-color','#d9d9d9;');  $("#password").css('border-width','thin');
            }


            if($("#username").val()==="") {
                $("#username").css('border','solid'); $("#username").css('border-color','red'); $("#username").css('border-width','thin');
                //return false;
            }else {
                $("#username").css('border','solid'); $("#username").css('border-color','#d9d9d9;');  $("#username").css('border-width','thin');
            }
            if($("#username").val()==="" || $("#password").val()==="") {

                alert('Fill submission fields');
                btn.css('background', 'red');
            } else {
                $.ajax({
                    type: 'POST',
                    url: "activity/Adddata.php",
                    data: myDatas,
                    dataType: 'json',
                    processData: true,
                    async: true,
                    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                    beforeSend: function () {
                        btn.css('background', '#343434');
                        btn.val('Logged in proccess.....');
                    },
                    success: function (response) {
                        if (response.status == 'salers_success'){
                           // alert(response.status);
                            btn.css('background', '#0c7aa8');
                            btn.val('Logged In ......');
                            setTimeout(' window.location.href = "./admin.php?home"; ', 4000);
                            $("#username").val('');
                            $("#password").val('');
                        } else {
                            alert('incorect username and password');
                            btn.val('Login');
                        }
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        if (thrownError) {
                            btn.css('background', 'red');
                            btn.val('Logged in fail');
                        }
                    }
                });
                return false;
            }

        });



    $("#btnsignup").click(function (e){
        e.preventDefault();
        var btn = $("#btnsignup");
        var myDatas = $("#salrssignup").serialize();

        if($("#firstname").val()==="") {
            $("#firstname").css('border','solid'); $("#firstname").css('border-color','red');  $("#firstname").css('border-width','thin');
           // return false;
        }else {
          $("#firstname").css('border','solid'); $("#firstname").css('border-color','#d9d9d9;');  $("#firstname").css('border-width','thin');
        }
        if($("#lastname").val()==="") {
            $("#lastname").css('border','solid'); $("#lastname").css('border-color','red'); $("#lastname").css('border-width','thin');
            //return false;
        }else {
            $("#lastname").css('border','solid'); $("#lastname").css('border-color','#d9d9d9;');  $("#lastname").css('border-width','thin');
        }
        if($("#email").val()==="") {
            $("#email").css('border','solid'); $("#email").css('border-color','red'); $("#email").css('border-width','thin');
            //return false;
        }else {
            $("#email").css('border','solid'); $("#email").css('border-color','#d9d9d9;');  $("#email").css('border-width','thin');
        }
        if($("#phone").val()==="") {
            $("#phone").css('border','solid'); $("#phone").css('border-color','red'); $("#phone").css('border-width','thin');
            //return false;
        }else {
            $("#phone").css('border','solid'); $("#phone").css('border-color','#d9d9d9;');  $("#phone").css('border-width','thin');
        }
        if($("#address").val()==="") {
            $("#address").css('border','solid'); $("#address").css('border-color','red'); $("#address").css('border-width','thin');
            //return false;
        }else {
            $("#address").css('border','solid'); $("#address").css('border-color','#d9d9d9;');  $("#address").css('border-width','thin');
        }
        if($("#businessname").val()==="") {
            $("#businessname").css('border','solid'); $("#businessname").css('border-color','red'); $("#businessname").css('border-width','thin');
            //return false;
        }else {
            $("#businessname").css('border','solid'); $("#businessname").css('border-color','#d9d9d9;');  $("#businessname").css('border-width','thin');
        }
        if($("#country").val()==="") {
            $("#country").css('border','solid'); $("#country").css('border-color','red'); $("#country").css('border-width','thin');
            //return false;
        }else {
            $("#country").css('border','solid'); $("#country").css('border-color','#d9d9d9;');  $("#country").css('border-width','thin');
        }
        if($("#about").val()==="About my Business..." || $("#about").val()==="") {
            $("#about").css('border','solid'); $("#about").css('border-color','red'); $("#about").css('border-width','thin');
            //return false;
        }else {
            $("#about").css('border','solid'); $("#about").css('border-color','#d9d9d9;');  $("#about").css('border-width','thin');
        }
        if($("#password").val()==="") {
            $("#password").css('border','solid'); $("#password").css('border-color','red'); $("#password").css('border-width','thin');
            //return false;
        }else {
            $("#password").css('border','solid'); $("#password").css('border-color','#d9d9d9;');  $("#password").css('border-width','thin');
        }
        if($("#confpassword").val()==="") {
            $("#confpassword").css('border','solid'); $("#confpassword").css('border-color','red'); $("#confpassword").css('border-width','thin');
            //return false;
        }else {
            $("#confpassword").css('border','solid'); $("#confpassword").css('border-color','#d9d9d9;');  $("#confpassword").css('border-width','thin');
        }
       var pas=$("#confpassword").val();
       var pass=$("#password").val();
    //    if(!pas==pass){
    //         alert('confirmation Password is not match with realy password.');
    //     } else {

            $.ajax({
                type: 'POST',
                url: "activity/Adddata.php",
                data: myDatas,
                dataType: 'json',
                processData: true,
                async: true,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                beforeSend: function () {
                    btn.css('background', '#343434');
                    btn.val('Creating  Account in proccess.....');
                },
                success: function (response) {
                    if (response.status == 'success') {
                        alert(response.status);
                        btn.css('background', '#0c7aa8');
                        btn.val('Registed');
                        $("#firstname").val('');
                        $("#address").val('');
                        $("#businessname").val('');
                        $("#password").val('');
                        $("#country").val('');
                        $("#about").val('');
                        $("#lastname").val('');
                        $("#email").val('');
                        $("#phone").val('');
                        $("#confpassword").val('');
                        $("#address").val('');
                    } else {
                        btn.val('Register');
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (thrownError) {
                        btn.css('background', 'red');
                        btn.val('Registed fail');
                    }
                }
            });
            return false;
      //  }

    });

 $("#viewpriceinfo").click(function (e){
            e.preventDefault();
            $("#priceform").show();
            $("#hidepriceinfo").show();
            $("#viewpriceinfo").hide();
        
 });
 
 $("#hidepriceinfo").click(function (e){
            e.preventDefault();
            $("#priceform").hide();
            $("#hidepriceinfo").hide();
            $("#viewpriceinfo").show();
        
 });
  $("#addprice").click(function (e){
            e.preventDefault();
           
 if( $("#price").val() =="" || $("#fname").val() =="" || $("#phone").val() =="" || $("#email").val() =="" ){
                    alert('Please, Fill the rquired field');
                    return false;
            }
 var btn = $("#addprice");
            //  if( $("#price").val() > $("#hprice").val()){
            //         alert('only price higher than '+$("#hprice").val());
            //         return false;
            // }else{
                var myDatas = $("#priceform").serialize();
                //alert(myDatas);
            $.ajax({
                type: 'POST',
                url: "activity/Adddata.php",
                data: myDatas,
                dataType: 'json',
                processData: true,
                async: true,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                beforeSend: function () {
                    btn.css('background', '#343434');
                    btn.val('Saving .....');
                },
                success: function (response) {
                    if (response.status == '_success') {
                        //alert(response.status);
                        btn.css('background', '#0c7aa8');
                      
                        $("#price").val('');
                        $("#fname").val('');
                        $("#phone").val('');
                        $("#email").val('');
                       btn.val('Saved');
                    } else {
                        btn.val('Save failed');
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (thrownError) {
                        btn.css('background', 'red');
                        console.log(thrownError);
                    }
                }
            });
          //  }
           // return false;
            // $("#priceform").hide();
            // $("#hidepriceinfo").hide();
            // $("#viewpriceinfo").show();
        
 });
 

 $("#editproduct").click(function (e){
            e.preventDefault();
           
           var formData  = document.getElementById('choose_item_photo').files[0];
            var btn = $("#editproduct");

            var formData  = new FormData();
                var url = "activity/Adddata.php";
                var metthod = 'POST';
                formData.append("photo", document.getElementById('choose_item_photo').files[0]);
                
                 formData.append("item_id", $('#item_id').val());
                formData.append("item", $('#item').val());
                formData.append("type", $('#type').val());
                formData.append("size", $('#size').val());
                formData.append("post_price", $('#post_price').val() );
                formData.append("categories", $('#categories').val() );
                formData.append("desc", $('#desc').val());
                formData.append("latestphoto", $('#latestphoto').val());
                formData.append("currency", $('#currency').val());
                formData.append("salers_id", $('#salers_id').val());
                formData.append("editproduct", 'editproduct');
                var aj = new XMLHttpRequest();
                aj.upload.addEventListener("progress", progressHandler, false);
                aj.addEventListener("load", completeHandler, false);
                aj.addEventListener("error", errorHandler, false);
                aj.addEventListener("abort", abortHandler, false);
                aj.open(metthod, url);
                console.log(formData);
                aj.onreadystatechange = function (){
                    if (ajaxReturn(aj) == true){
                    if(aj.responseText=='editproduct_fail'){
                        alert('editproduct_fail');
                        btn.css('background', 'red');
                    }else if(aj.responseText=='upload_fail'){
                        alert('upload_fail');
                        btn.css('background', 'red');
                    }else{
                        alert(aj.responseText);
                        btn.css('background', 'red');
                        // $('#item').val('');
                        // $('#type').val('');
                        // $('#size').val('');
                        // $('#post_price').val('');
                        // $('#categories').val('select category');
                        // $('#currency').val('currency');
                        // $('#desc').val('Description...');
                        // $('#pro_previewing').attr('src', '');
                        // $('#pro_previewing').attr('width', '100%');
                        // $('#pro_previewing').attr('max-width', '300px');
                        // $('#pro_previewing').attr('line-height', '16');
                    }
                    }else{
                        return false;
                    }
                };

                aj.send(formData);
                return false;
 });

        $("#addproduct").click(function (e){
            e.preventDefault();
           // var formData  = document.getElementById('choose_item_photo').files[0];
            var btn = $("#savproduct");
           // var myDatas = $("#productform").serialize()+formData;

            if($("#item").val()==="") {
                $("#item").css('border','solid'); $("#item").css('border-color','red');  $("#item").css('border-width','thin');
                // return false;
            }else {
                $("#item").css('border','solid'); $("#item").css('border-color','#d9d9d9;');  $("#item").css('border-width','thin');
            }
            if($("#type").val()==="") {
                $("#type").css('border','solid'); $("#type").css('border-color','red'); $("#type").css('border-width','thin');
                //return false;
            }else {
                $("#type").css('border','solid'); $("#type").css('border-color','#d9d9d9;');  $("#type").css('border-width','thin');
            }
            if($("#size").val()==="") {
                $("#size").css('border','solid'); $("#size").css('border-color','red'); $("#size").css('border-width','thin');
                //return false;
            }else {
                $("#size").css('border','solid'); $("#size").css('border-color','#d9d9d9;');  $("#size").css('border-width','thin');
            }
            if($("#post_price").val()==="") {
                $("#post_price").css('border','solid'); $("#post_price").css('border-color','red'); $("#post_price").css('border-width','thin');
                //return false;
            }else {
                $("#post_price").css('border','solid'); $("#post_price").css('border-color','#d9d9d9;');  $("#post_price").css('border-width','thin');
            }
            if($("#categories").val()==="select category") {
                $("#categories").css('border','solid'); $("#categories").css('border-color','red'); $("#categories").css('border-width','thin');
                //return false;
            }else {
                $("#categories").css('border','solid'); $("#categories").css('border-color','#d9d9d9;');  $("#categories").css('border-width','thin');
            }

            if($("#desc").val()==="Description...") {
                $("#desc").css('border','solid'); $("#desc").css('border-color','red'); $("#desc").css('border-width','thin');
                //return false;
            }else {
                $("#desc").css('border','solid'); $("#desc").css('border-color','#d9d9d9;');  $("#desc").css('border-width','thin');
            }

            if($("#currency").val()==="currency") {
                $("#currency").css('border','solid'); $("#currency").css('border-color','red'); $("#currency").css('border-width','thin');
                //return false;
            }else {
                $("#currency").css('border','solid'); $("#currency").css('border-color','#d9d9d9;');  $("#currency").css('border-width','thin');
            }

            if($("#choose_item_photo").val()==="") {
                $("#choose_item_photo").css('border','solid'); $("#choose_item_photo").css('border-color','red'); $("#choose_item_photo").css('border-width','thin');
                //return false;
            }else {
                $("#choose_item_photo").css('border','solid'); $("#choose_item_photo").css('border-color','#d9d9d9;');  $("#choose_item_photo").css('border-width','thin');
            }

            if($("#currency").val()==="currency" || $("#categories").val()==="select category" || $("#choose_item_photo").val()==="" || $("#item").val()==="" || $("#size").val()==="" || $("#type").val()==="" || $("#post_price").val()==="" || $("#desc").val()==="Description...") {

                alert('Fill submission fields or choose photo');
                btn.css('background', 'red');
            } else{

                var formData  = new FormData();
                var url = "activity/Adddata.php";
                var metthod = 'POST';
                formData.append("photo", document.getElementById('choose_item_photo').files[0]);
                formData.append("item", $('#item').val());
                formData.append("type", $('#type').val());
                formData.append("size", $('#size').val());
                formData.append("post_price", $('#post_price').val() );
                formData.append("categories", $('#categories').val() );
                formData.append("desc", $('#desc').val());
                formData.append("currency", $('#currency').val());
                formData.append("salers_id", $('#salers_id').val());
                formData.append("addproduct", 'addproduct');
                var aj = new XMLHttpRequest();
                aj.upload.addEventListener("progress", progressHandler, false);
                aj.addEventListener("load", completeHandler, false);
                aj.addEventListener("error", errorHandler, false);
                aj.addEventListener("abort", abortHandler, false);
                aj.open(metthod, url);
                console.log(formData);
                aj.onreadystatechange = function (){
                    if (ajaxReturn(aj) == true){
                    if(aj.responseText=='addproduct_fail'){
                        alert('addproduct_fail');
                        btn.css('background', 'red');
                    }else if(aj.responseText=='upload_fail'){
                        alert('upload_fail');
                        btn.css('background', 'red');
                    }else{
                        alert(aj.responseText);
                        btn.css('background', 'red');
                        $('#item').val('');
                        $('#type').val('');
                        $('#size').val('');
                        $('#post_price').val('');
                        $('#categories').val('select category');
                        $('#currency').val('currency');
                        $('#desc').val('Description...');
                        $('#pro_previewing').attr('src', '');
                        $('#pro_previewing').attr('width', '100%');
                        $('#pro_previewing').attr('max-width', '300px');
                        $('#pro_previewing').attr('line-height', '16');
                    }
                    }else{
                        return false;
                    }
                };

                aj.send(formData);
                return false;
            }

        });


}
);

