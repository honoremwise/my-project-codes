<?php   if (!(isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){ ?>

<div class="w3l_banner_nav_left">
    <nav class="navbar nav_bottom">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header nav_2">
            <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
            <ul class="nav navbar-nav nav_1">
            <?php
//error_reporting(0);
$db= new Databases();

     $db->open_connection();
         $table='items';
         $get=isset($_COOKIE["auth_id"])?$_COOKIE["auth_id"]:0;
        $fetch=$db->query_display('items as i,deals as d',$column_name="i.item_id,i.item,i.saler_id,i.post_price,i.post_price,i.category,i.photo_view,i.currency,d.deals_id,d.item_id,d.price",'i.item_id=d.item_id  GROUP BY i.item_id LIMIT 0,1');
        $rowcount=$db->num_rows($fetch);
    
         if($rowcount > 0){
                   while($row=$db->fetch_all_array($fetch)){
                      // var_dump($row);
                                $item_id=$row['item_id'];
                                 $saler_id=$row['saler_id'];
                                 $item=$row['item'];
                                 $category=$row['category'];
                                 $photo_view=$row['photo_view'];
                               
                                 $carry=$row['currency'];
                                  $f=$db->query_display('deals',$column_name="price,MAX(price)as mxprice","item_id=".$item_id.' GROUP BY item_id');
                                 $r=$db->fetch_all_array($f);
                                  $post_price=$r['mxprice'];
                                 echo'<div class="top_brand_left">
                    <div class="hover14 column">
                  Best Deals <br /> 
                        <div class="agile_top_brand_left_grid">
                      
                            <div class="agile_top_brand_left_grid1">
                                <figure>
                                    <div class="snipcart-item block">
                                        <div class="snipcart-thumb" style="height:160px">
                                            <a href="./" >
                                            <img style="max-height:100%;min-height:100%;height:160px" class="img-rounded img-thumbnail" alt=" " src="activity/upload/lg_photo/'.$photo_view.'"></a>

                                            
                                        </div>
                                        <p>Item:'. $item.'</p>
                                            <h4>Highest Price '.$post_price .'  ['. $carry.']<span></span></h4>
                                        <div class="snipcart-details top_brand_home_details">
                                            <form action="./?productPreviews='.md5('helllo auction').md5('am fine  dear').md5('helllo auction').md5('am fine  dear').'_'.$item_id.'" method="post">
                                                <input type="submit" class="button" value="more details">  
                                            </form>
                                        </div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>';
                   }
         }else{
             echo"no product were found!";
         }
       

   

    ?>


            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</div>
<?php } ?>