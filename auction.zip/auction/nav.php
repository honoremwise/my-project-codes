
<div class="agileits_header">
    <div class="w3l_offers">
        <a href="./">Auction | <?php if (isset($_COOKIE["auth_id"])) { $info=array();
                $info=salersinfo($_COOKIE['auth_id']) ; print ucfirst($info['bussins_name']); }else{ print 'Daily Offers';}  ?></a>
    </div>
     <?php   if ( !(isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){?>
    <div class="w3l_search">
        <form action="./" method="GET">
            <input type="text" name="search" id="search" value="Search a product..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search a product...';}" required="">
            <input type="submit" value=" " name="searchbtns">
        </form>
    </div>
    <?php } ?>
    <?php   if ( (isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){?>
      <div class="product_list_header">

          <ul>
              <li class="dropdown profile_details_drop">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Welcome, <?php print ucfirst($info['fname']); ?><span class="caret"></span></a>
                  <div class="mega-dropdown-menu">
                      <div class="w3ls_vegetables">
                          <ul class="dropdown-menu drp-mnu">
                              <li><a href="logout.php">Logout </a></li>
                              <!--<li><a href="login.html">My Profile</a></li>-->
                          </ul>
                      </div>
                  </div>
              </li>
          </ul>

        </div>

    <?php }else{ ?>

        <div class="product_list_header">

            <fieldset>
                <input type="hidden" name="cmd" value="_cart" />
                <input type="hidden" name="display" value="1" />
                <a href="./?salerLogin"> <input type="submit" name="submit"  value=" Salers Login " class="button" /></a>
            </fieldset>

        </div>

 

    <?php }  if ( !(isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){ ?>

        <div class="w3l_header_right1">
            <h3><a href="./?about"><i class="fa fa-user"></i> About Us</a></h3>
        </div>
        <div class="w3l_header_right1">
            <h3><a href="./?contact"><i class="fa fa-phone"></i> Contact Us</a></h3>
        </div>

    <?php } ?>
    <div class="clearfix"> </div>
</div>

<!-- script-for sticky-nav -->
<script>
    $(document).ready(function() {
        var navoffeset=$(".agileits_header").offset().top;
        $(window).scroll(function(){
            var scrollpos=$(window).scrollTop();
            if(scrollpos >=navoffeset){
                $(".agileits_header").addClass("fixed");
            }else{
                $(".agileits_header").removeClass("fixed");
            }
        });

    });
</script>

<?php   if ((isset($_SESSION['auth_id']) || isset($_COOKIE["auth_id"])) && (isset($_SESSION['salers']) || isset($_COOKIE["salers"])) ){ ?>

<div class="logo_products">
<div class="container">
<div class="w3ls_logo_products_left1">
<ul class="special_items">
    <li><a href="./">DashBoard</a><i>/</i></li>
<li><a href="./?products">all Products</a><i>/</i></li>
<li><a href="./?proDeals">Product in Deals </a><i>/</i></li>
<!--<li><a href="./proexpired">Product blocked </a></li>-->
<li> &nbsp;&nbsp;</li>
</ul>
</div>
<div class="clearfix"> </div><br />
  <div class="pull-right">
        <a href="./?addproduct" class="btn btn-info"> <i class="fa fa-plus"></i> Add new product</a></div>
</div>
</div>
<?php }else{  ?>
<div class="logo_products"> <div class="clearfix"> </div> </div>
<?php } ?>
