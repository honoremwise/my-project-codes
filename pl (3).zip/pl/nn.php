 <?php 
require('dbcon/dbcon.php');
session_start();
    $message="";
    $username="";
    $password="";
if(isset($_POST['lgn']))
{
$username = stripslashes($_REQUEST['email']);
       // escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	//Checking is user existing in the database or not
    if($username!="" && $password!="")
    {
$branchquery = "SELECT * FROM `branch_workers` WHERE username='$username'
and worker_password='$password'";
$branch_result = mysqli_query($con,$branchquery) or die(mysqli_error());
	$branchrecs = mysqli_num_rows($branch_result);
       
// to trying to login as  user from different tble but stack
$query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysqli_error());
	$rows = mysqli_num_rows($result);
        
        if($rows==1)
        {
	    $_SESSION['username'] = $username;
            // Redirect user to users folder home.php
            if($_SESSION['username']!='admin')
            {
            header("Location: users/?");   
            }
            else
            {
	     header("Location: admin/?"); 
            }
         }
         if($branchrecs==1)
        {
             $_SESSION['username'] = $username;
            if($_SESSION['username']=='admin')
            {
            header("Location: pharmacy/branch_admin.php");   
            }
            else 
            {
	     header("Location: pharmacy/branch.php"); 
            }
          } 
else{
	$message="incorrect creditentials";
	}
    }}
    else if ($username=="" && $password==""){
        $message="please fill your authentications first";
    }
    ?>
<form method="post" action="#">
				  <div>
<span>Email Address<label>*</label></span>
<input type="text" name="email"> 
				  </div>
				  <div>
					<span>Password<label>*</label></span>
<input type="password" name="password"> 
				  </div>
				  <a class="forgot" href="#">Forgot Your Password?</a>
				  <input type="submit" value="Login" name="lgn">
			    </form>
   