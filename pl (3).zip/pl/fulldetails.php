<!DOCTYPE html>
<html>
<head>
<title>PHARMACY LOCATOR</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<!--<meta http-equiv="refresh" content="500">    -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--google map api    -->
<!--still not find it    <script src="js/jquery.js"></script>-->
   <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBdAXGeAzLivzpjW24uOjwXEM3GWgQ5BMk&callback=initMap"
  type="text/javascript"></script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script src="js/simpleCart.min.js"> </script>	
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
 
	<style>
        #map{
            min-height: 285px;
	width: 100%;
	border: none;
            margin-top: 10px;
        }
    </style>
</head>
<body onload="getLocation()">
    <?php require('dbcon/dbcon.php');
    $length="";
     if(isset($_GET['fullinfos']))
              {
          $reference=$_GET['fullinfos'];
         //echo $reference;
     $select="SELECT * FROM pharmacies,pharmacy_branches WHERE pharmacy_branches.pharmacyid = pharmacies.pharmacy_id AND pharmacy_branches.branchid = '$reference'";
        $sql=mysqli_query($con,$select);
        while($rec=mysqli_fetch_array($sql))
        {
            $branchid=$rec['branchid'];
            $pharmacyid=$rec['pharmacyid'];
            $tel_contact_no=$rec['tel_contact_no'];
            $latitudefromtb=$rec['latitude'];
            $longitudefromtb=$rec['longitude'];
            $branch_site_image=$rec['branch_site_image'];
            $service_start_time=$rec['service_start_time'];
            $service_end_time=$rec['service_end_time'];
            $working_day_info=$rec['working_day_info'];
            $pharmacy_name=$rec['pharmacy_name'];
            $pharmacy_logo=$rec['pharmacy_logo'];
            $pharmacy_link=$rec['pharmacy_link'];
            $email=$rec['pharmacy_email'];
            $province=$rec['province'];
            $branch_district=$rec['branch_district'];
        echo"   <input type='hidden' id=\"lat\" value='$latitudefromtb'>
        <input type='hidden' id=\"long\" value='$longitudefromtb'>";
        }
function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  $theta = $lon1 - $lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);
  if ($unit == "K") {
    return ($miles * 1.609344);
  } else if ($unit == "N") {
      return ($miles * 0.8684);
    }
      else if ($unit == "M") {
      return ($miles * 1609.34);
    } else {
        return $miles;
      }
}
 
     }
   if(isset($_POST['getdistance']))
   {
$latlong=$_POST['latlong'];
 $lt=""; $lg=""; 
error_reporting(0); 
$latlong=explode(',',$_POST['latlong']);
$lt=$latlong[0]; $lg=$latlong[1]; 
       $length = distance($lt,$lg,$latitudefromtb,$longitudefromtb, "M");
       
   }
    
    ?>
    
    <!-- header-section-starts -->
	<div class="header">
		<div class="menu-bar">
			<div class="container">
				<div class="login-section">
					<ul>
						<li><a class="active" href="index.php">Home</a>  </li>|
                        <li><a href="register.php">Register</a> </li> |
                        <li><a href="login.php">Login</a>  </li> |
						
						<li><a href="#">Help</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="banner wow fadeInUp" id="Home">
		    <div class="container">
				<div class="banner-info">
					<div class="banner-info-head text-center wow fadeInLeft" data-wow-delay="0.5s">
						<h1><i class="fa fa-paper-plane-o fa-1x"></i>&nbsp;&nbsp;Welcome To Pharmacy Locator</h1>
						<div class="line">
							
						</div>
					</div>
					<div class="form-list wow fadeInRight">
                        <center>
<!--                            searching field-->
						 <form action="#" method="post">
	          <input type="search" placeholder="check for drug available in this pharmacy" class="text" style="width:50%;"/>
	            <button type="submit" name="searchdrug" class="btn btn-default btn-lg"><i class="fa fa-search" style="font-size:100%;color:red;"></i></button>&nbsp;&nbsp;
<!--                            searching field end..-->
                 </form>


        
                       </center>
						</div>					
				</div>
			</div>
		</div>
	</div>
	<div class="contact_top">
<div class="container">
    <?php echo "<center><h4><b>Welcome to {$pharmacy_name} PHAMACY PAGE</b></h4></center>";?>
     
    <div class="col-md-4 top-restaurents">
	<center><h4><b>Images For Descriptions</b></h4></center>
       <br>
					<div class="top-restaurent-grids">
						<div class="top-restaurent-logos">
		
<?php 
 $im="SELECT * FROM pharmacies,pharmacy_branches WHERE pharmacy_branches.pharmacyid = pharmacies.pharmacy_id AND pharmacy_branches.branchid = '$reference' ";
$imsql=mysqli_query($con,$im);
        while($imrec=mysqli_fetch_array($imsql))
        {
         $branch_site_image=$imrec['branch_site_image'];
        $rightclosestplace=$imrec['rightclosestplace'];
        $leftclosestplace=$imrec['leftclosestplace'];
        $closest_common_known_place=$imrec['closest_common_known_place'];   
          echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>PHARMACY IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$branch_site_image' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>A REFERENCE IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$closest_common_known_place' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>RIGHT SIDE REFERENCE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$rightclosestplace' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>LEFT SIDE REFERENCE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$leftclosestplace' class='img-responsive' alt='' style='width:170px;height:110;'/></div>";  
        }                            
                            
                            
                            ?>
							<div class="clearfix"></div>
                            <br>
						</div>
					</div>
				</div>
    <div class="col-md-2 top-restaurents">
	<br><br>
       <p class='fa fa-tasks'><b><u> SERVICE SCHEDULE</u></b></p>
         <?php echo"                          
<p class='fa fa-clock-o'>{$service_start_time} AM  To &nbsp;{$service_end_time} PM, </p><br>
<p class='fa fa-calendar'>&nbsp;{$working_day_info}</p>
<br>
<p class='fa fa-mobile'>&nbsp;{$tel_contact_no}</p>
<br>
<p class='fa fa-envelope'>&nbsp;{$email}</p>
<br>
<p class='fa fa-globe'>&nbsp;<a href='{$pharmacy_link}'>{$pharmacy_link}</a></p><p class='fa fa-location-arrow'>".strtoupper($province)." Province,</p><p>".strtoupper($branch_district).".District</a></p>

<p>".$length."gfgfgf"."in meters</a></p>";
        
        
        
					?>
        
<!--
        <input type="text" name="latlong" id="demo" value="">                             
<input type="submit" name="checklglat" value="view distance" class="wow swing animated btn btn-default btn-lg" data-wow-delay= "0.4s">
-->
				</div>
     <div class="col-md-6 company-right wow fadeInLeft" data-wow-delay="0.4s">
 <p class='fa fa-marker'><b></b></p><div class="contact-map" id="map">
 		       </div>
      
         <div class="clearfix"></div>
    </div>
        </div>									
						 
<!--  getting coordinates-->
<!--
    <script>
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.value = position.coords.latitude + 
    "," + position.coords.longitude;
}
</script>
-->
<!--    end-->
	<div class="special-offers-section">
			<div class="container">
				<div class="special-offers-section-head text-center dotted-line">
					<h4>Health Insurrances </h4>
				</div>
				<div class="special-offers-section-grids">
				 <div class="m_3"><span class="middle-dotted-line"> </span> </div>
				   <div class="container">
					  <ul id="flexiselDemo3">
                          <?php
   $sld="SELECT * FROM `insurrence_companies`";
  $inqueryd=mysql_query($sld);
   $insucounterd=mysql_num_rows($inqueryd);
  if($insucounterd > 0)
  {
  echo"<li>
							<div class='offer'>
								<div class='offer-image'>	
									<img src='images/p1.jpg' class='img-responsive' alt=''/>
								</div>
								<div class='offer-text'>
									<h4>BRITAM</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<span></span>
								</div>
								<div class='clearfix'></div>
							</div>
						</li>";}
                          ?>
                          
                          
						
<!--
                          <li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p1.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>MIS UR</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								<div class="clearfix"></div>
							</div>
-->
<!--
						</li><li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p1.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>SAHAM Insurrance</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								<div class="clearfix"></div>
							</div>
						</li>
-->
<!--
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>MMI</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								<div class="clearfix"></div>
							</div>
						</li>
-->
<!--
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p3.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>RSSB</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
						</li>
-->
<!--
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>UAP Insurrance</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
					    </li>
-->
<!--                          <li>-->
<!--
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>MIS UR</h4>
									<p>La Rwandaise d'Assurance Maladie </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
-->
<!--					    </li>-->
<!--
                          <li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>RADIANT</h4>
									<p>A PROMISE IS PROMISE </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
					    </li>
-->
<!--
                          <li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>UAP</h4>
									<p>Better,simple,Life</p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
					    </li>
-->
					 </ul>
                       
    <script>
    x = navigator.geolocation;
    x.getCurrentPosition(success, failure);
        function success(position){
            //fetch coordinates
//         var mylat= position.coords.latitude;
//        var mylong= position.coords.longitude;
           var lat= $('#lat').val();
            var long= $('#long').val();
           
          //Google-API-ready latitude and longitude string 
         var coords =new google.maps.LatLng(lat, long);
//              // setting up the google map
            var mapOptions = {
                zoom:16,
                center: coords,
                mapTypeId: google.maps.MapTypeId.ROADMAP
                            }
//            // creating the map
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        var marker =new google.maps.Marker({map:map,position:coords});
        }
        function failure(){
           $('#lat').html("<p> It didn't work,co-ordinates not available!<p>"); 
        }
    </script>                      
                       
                       
				 <script type="text/javascript">
					$(window).load(function() {
						
						$("#flexiselDemo3").flexisel({
							visibleItems: 3,
							animationSpeed: 1000,
							autoPlay: false,
							autoPlaySpeed: 3000,    		
							pauseOnHover: true,
							enableResponsiveBreakpoints: true,
							responsiveBreakpoints: { 
								portrait: { 
									changePoint:480,
									visibleItems: 1
								}, 
								landscape: { 
									changePoint:640,
									visibleItems: 2
								},
								tablet: { 
									changePoint:768,
									visibleItems: 3
								}
							}
						});
						
					});
				    </script>
				    <script type="text/javascript" src="js/jquery.flexisel.js"></script>
				</div>
			</div>
		</div>
		</div>	
		<?php include_once('footer.html')?>

</body>
</html>