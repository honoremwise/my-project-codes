-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 10, 2017 at 02:46 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pharmaciesdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch_bills`
--

CREATE TABLE IF NOT EXISTS `branch_bills` (
  `branch_bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_worker_id` int(11) NOT NULL,
  `buyer_tel_no` varchar(250) NOT NULL,
  `healthinsurrance` varchar(250) NOT NULL,
  `healthinsurranceid` varchar(250) NOT NULL,
  `buyer` varchar(250) NOT NULL,
  `bill_value` varchar(250) NOT NULL DEFAULT 'qued',
  PRIMARY KEY (`branch_bill_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `branch_bills`
--

INSERT INTO `branch_bills` (`branch_bill_id`, `branch_worker_id`, `buyer_tel_no`, `healthinsurrance`, `healthinsurranceid`, `buyer`, `bill_value`) VALUES
(1, 0, '07894561230', 'RSSB', '147895656', 'honore', 'valid'),
(2, 1, '741852963', 'mutuele', '7894561', 'ganza', 'valid'),
(3, 1, '01784596', 'RSSB', 'ididiidid', 'honore', 'qued');

-- --------------------------------------------------------

--
-- Table structure for table `branch_drug_store`
--

CREATE TABLE IF NOT EXISTS `branch_drug_store` (
  `recording_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_id` varchar(250) NOT NULL,
  `drug_quantity` int(11) NOT NULL,
  `arrival_date` date NOT NULL,
  `pharmacy_id` varchar(250) NOT NULL,
  PRIMARY KEY (`recording_transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `branch_sales`
--

CREATE TABLE IF NOT EXISTS `branch_sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_bill_id` varchar(250) NOT NULL,
  `drug_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `branch_workers`
--

CREATE TABLE IF NOT EXISTS `branch_workers` (
  `worker_id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_first_name` varchar(250) NOT NULL,
  `worker_last_name` varchar(250) NOT NULL,
  `worker_id_no` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `worker_password` varchar(250) NOT NULL,
  `workers_email` varchar(250) NOT NULL,
  `worker_tel` varchar(250) NOT NULL,
  `data_of_employement` date NOT NULL,
  `access_status` varchar(250) NOT NULL DEFAULT 'granted',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`worker_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `branch_workers`
--

INSERT INTO `branch_workers` (`worker_id`, `worker_first_name`, `worker_last_name`, `worker_id_no`, `username`, `worker_password`, `workers_email`, `worker_tel`, `data_of_employement`, `access_status`, `branch_id`) VALUES
(1, 'ganza', 'respice', 2147483647, 'gaga', 'gaga', 'ga@gmail.com', '07894512', '0000-00-00', 'granted', 1),
(2, 'f', 'f', 0, 'admin', 'f', 'f@ga', '3', '0000-00-00', 'granted', 1),
(3, 'kababago', 'jean', 2147483647, 'lolo', 'hahaha', 'h@gmail.com', '078945612', '0000-00-00', 'granted', 0),
(4, 'honore', 'mwiseneza', 2147483647, 'sando', 'sando', 'uwasandrine@gmail.com', '07894561230', '0000-00-00', 'granted', 0);

-- --------------------------------------------------------

--
-- Table structure for table `drug_assignments`
--

CREATE TABLE IF NOT EXISTS `drug_assignments` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `pharmacy_id` varchar(250) NOT NULL,
  `pharmacy_branch_id` varchar(250) NOT NULL,
  `drug_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `assignments_date` date NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `insurrence_companies`
--

CREATE TABLE IF NOT EXISTS `insurrence_companies` (
  `insurrence_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(250) NOT NULL,
  `company_logo` varchar(1000) NOT NULL,
  `companydescirption` varchar(250) NOT NULL,
  `registration_date` date NOT NULL,
  `visibilitystatus` varchar(250) NOT NULL DEFAULT 'valid',
  `companyemail` varchar(250) NOT NULL,
  PRIMARY KEY (`insurrence_id`),
  UNIQUE KEY `company_name` (`company_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `insurrence_companies`
--

INSERT INTO `insurrence_companies` (`insurrence_id`, `company_name`, `company_logo`, `companydescirption`, `registration_date`, `visibilitystatus`, `companyemail`) VALUES
(14, 'vvv', '3717923.png', 'dd@f', '2017-07-06', 'valid', 'tttt@f'),
(15, 'hhh', 'RADIANT.jpg', 'jhjj', '2017-07-06', 'invalid', 'f@gnm');

-- --------------------------------------------------------

--
-- Table structure for table `insurrence_companies_pharmacies`
--

CREATE TABLE IF NOT EXISTS `insurrence_companies_pharmacies` (
  `insurrence_company_id` int(250) NOT NULL,
  `pharmacy_id` int(11) NOT NULL,
  `date_recorded` date NOT NULL,
  PRIMARY KEY (`insurrence_company_id`,`pharmacy_id`),
  KEY `pharmacy_id` (`pharmacy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurrence_companies_pharmacies`
--

INSERT INTO `insurrence_companies_pharmacies` (`insurrence_company_id`, `pharmacy_id`, `date_recorded`) VALUES
(14, 2, '2017-06-07'),
(15, 2, '2017-06-07');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacies`
--

CREATE TABLE IF NOT EXISTS `pharmacies` (
  `pharmacy_id` int(250) NOT NULL AUTO_INCREMENT,
  `pharmacy_name` varchar(250) NOT NULL,
  `pharmacy_logo` varchar(1000) NOT NULL,
  `pharmacy_link` varchar(250) NOT NULL,
  `pharmacy_email` varchar(250) NOT NULL,
  `pharmacy_service_tel` varchar(250) NOT NULL,
  `pharmacy_authorization_identication` varchar(250) NOT NULL,
  `pharmacy_owner_id` int(11) NOT NULL,
  `reg_date` datetime NOT NULL,
  `access_status` varchar(250) NOT NULL DEFAULT 'granted',
  `advertstatus` varchar(250) NOT NULL DEFAULT 'valid',
  PRIMARY KEY (`pharmacy_id`),
  UNIQUE KEY `pharmacy_owner` (`pharmacy_owner_id`),
  UNIQUE KEY `pharmacy_name` (`pharmacy_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pharmacies`
--

INSERT INTO `pharmacies` (`pharmacy_id`, `pharmacy_name`, `pharmacy_logo`, `pharmacy_link`, `pharmacy_email`, `pharmacy_service_tel`, `pharmacy_authorization_identication`, `pharmacy_owner_id`, `reg_date`, `access_status`, `advertstatus`) VALUES
(2, 'viva ', '3717923.png', 'www.go.com', 'a@gmail.com', '017896', '1234', 8, '2017-06-07 08:48:41', 'granted', 'valid');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_branches`
--

CREATE TABLE IF NOT EXISTS `pharmacy_branches` (
  `branchid` varchar(250) NOT NULL,
  `pharmacyid` int(250) NOT NULL,
  `tel_contact_no` varchar(250) NOT NULL,
  `province` varchar(1000) NOT NULL,
  `branch_district` varchar(250) NOT NULL,
  `branch_sector` varchar(250) NOT NULL,
  `branch_cell` varchar(250) NOT NULL,
  `branch_village` varchar(250) NOT NULL,
  `latitude` float(10,6) NOT NULL,
  `longitude` float(15,10) NOT NULL,
  `establishement_date` date NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'active',
  `date_of_closure` date NOT NULL,
  `branch_site_image` varchar(1000) NOT NULL,
  `closest_common_known_place` varchar(1000) NOT NULL,
  `rightclosestplace` varchar(1000) NOT NULL,
  `leftclosestplace` varchar(1000) NOT NULL,
  `service_start_time` time NOT NULL,
  `service_end_time` time NOT NULL,
  `working_day_info` varchar(250) NOT NULL,
  PRIMARY KEY (`branchid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacy_branches`
--

INSERT INTO `pharmacy_branches` (`branchid`, `pharmacyid`, `tel_contact_no`, `province`, `branch_district`, `branch_sector`, `branch_cell`, `branch_village`, `latitude`, `longitude`, `establishement_date`, `status`, `date_of_closure`, `branch_site_image`, `closest_common_known_place`, `rightclosestplace`, `leftclosestplace`, `service_start_time`, `service_end_time`, `working_day_info`) VALUES
('huhuhhmu_2_2', 2, '789456222332', 'huey', 'huye', 'hhhahahha', 'lango', 'mukoni', -2.645448, 29.3217849731, '2017-06-08', 'active', '0000-00-00', 'RADIANT.jpg', 'UAP.png', 'MISUR.jpg', 'MEDIPLAN.jpg', '19:08:00', '20:56:00', 'lango'),
('sohututa_0_2', 2, '0789456123', 'southern', 'huye', 'tumba', 'tumba', 'taba', 0.000000, 0.0000000000, '2017-06-08', 'active', '0000-00-00', 'britam.jpg', 'MISUR.jpg', 'RSSB.png', 'MMI.png', '01:00:00', '02:02:00', 'hdhdhdhd'),
('uijkkjkj_4_2', 2, '0789456123', 'southern', 'huyedistrict', 'tumba4444', 'tumbasector', 'tabavilage', 0.000000, 0.0000000000, '2017-06-08', 'active', '0000-00-00', 'MISUR.jpg', 'MEDIPLAN.jpg', 'RADIANT.jpg', 'MEDIPLAN.jpg', '01:00:00', '02:02:00', 'hdhdhdhd');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_drugs`
--

CREATE TABLE IF NOT EXISTS `pharmacy_drugs` (
  `drug_id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_names` varchar(250) NOT NULL,
  `pricing_description` varchar(250) NOT NULL,
  `pharmacy_id` varchar(250) NOT NULL,
  `recording_date` date NOT NULL,
  `exp_date` date NOT NULL,
  `info_status` varchar(250) NOT NULL DEFAULT 'valid',
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`drug_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `pharmacy_drugs`
--

INSERT INTO `pharmacy_drugs` (`drug_id`, `drug_names`, `pricing_description`, `pharmacy_id`, `recording_date`, `exp_date`, `info_status`, `quantity`) VALUES
(10, 'paracetamole', 'combined', '2', '2017-06-07', '2017-06-01', 'valid', 1),
(11, 'paracetamole', 'combined', '2', '2017-06-07', '2017-06-01', 'valid', 1),
(12, 'paracetamole', 'combined', '2', '2017-06-07', '2017-06-01', 'valid', 1),
(13, 'paracetamole', 'combined', '2', '2017-06-07', '2017-06-01', 'valid', 1),
(14, 'quinine', 'per unity', '2', '2017-06-07', '2017-06-01', 'valid', 1),
(15, 'lfkfkkf', 'per unity', '2', '2017-06-08', '2017-06-16', 'valid', 2),
(16, 'quinine', 'combined', '2', '2017-06-08', '2017-06-14', 'valid', 3),
(17, 'hhhhhh', 'per unity', '2', '2017-06-09', '2017-06-14', 'valid', 47888),
(18, 'jhjhjhjb', 'per unity', '2', '2017-06-09', '0004-04-04', 'valid', 7);

-- --------------------------------------------------------

--
-- Table structure for table `price_records`
--

CREATE TABLE IF NOT EXISTS `price_records` (
  `pricing_id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_id` int(11) NOT NULL,
  `drug_amount` int(11) NOT NULL,
  `Price_date` datetime NOT NULL,
  `price_status` varchar(250) NOT NULL DEFAULT 'vaild',
  `price_change_date` datetime NOT NULL,
  `pharmacyid` int(250) NOT NULL,
  PRIMARY KEY (`pricing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sale_temp`
--

CREATE TABLE IF NOT EXISTS `sale_temp` (
  `drugid` int(11) NOT NULL,
  `drug_name` varchar(250) NOT NULL,
  `drug_pice` varchar(250) NOT NULL,
  `quantity` int(11) NOT NULL,
  `worker_id` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(250) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `telephone` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(250) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `reg_date` datetime NOT NULL,
  `accesssatus` varchar(250) NOT NULL DEFAULT 'valid',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `firstname`, `lastname`, `telephone`, `username`, `password`, `user_email`, `reg_date`, `accesssatus`) VALUES
(1, 'kaz', 'ora', '0788', 'kal', '2a8914fd82ddbcf1f2af6635967a8bfb', 'al@gmail.com', '2017-06-07 19:00:53', 'valid'),
(3, 'lala', 'lala', '0785692', 'lala', '2e3817293fc275dbee74bd71ce6eb056', 'lala@gmail.com', '2017-04-10 09:55:04', ''),
(5, 'kaka', 'kaka', '1234', 'kaka', '5541c7b5a06c39b267a5efae6628e003', 'kaka@gmail.com', '2017-04-10 14:07:47', ''),
(6, 'honore', 'mwiseneza', '0726199797', 'admin', 'fe3691bfbfb168ccadfb74fa1f891583', 'hmwiseneza@gmail.com', '2017-04-10 22:00:52', 'valid'),
(7, 'gikwerere', 'gigig', 'gdgdgd', 'gigi', 'ec0c8fe7ad80dfe93c0de35448b1d581', 'www.gi@gmail.com', '2017-04-11 16:20:36', 'valid'),
(8, 'mlambo', 'nyararaia', '178955556', 'nyarara', 'd6581d542c7eaf801284f084478b5fcc', 'mlambo@gmail.com', '2017-04-30 06:21:25', ''),
(9, 'ganza', 'respice', '0726276280', 'ganza', 'e12badcbf08c94515148592d74cec465', 'respinho2014@gmail.com', '2017-05-06 18:26:12', 'valid'),
(10, 'gikwere', 'steven', '7894515', '12345', '827ccb0eea8a706c4c34a16891f84e7b', 'gmsteven@gmail.com', '2017-05-17 16:09:30', ''),
(11, 'teo', 'kazol', '07895', 'haha', '25f9e794323b453885f5181f1b624d0b', 'ha@gmail.com', '2017-06-07 19:19:32', 'valid');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
