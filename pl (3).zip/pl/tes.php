<!DOCTYPE html>
<html>
<head>
<title>Pharmacy Locator</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
<script src="js/simpleCart.min.js"> </script>	
</head>
<body>
      <?php 
require('dbcon/dbcon.php');
session_start();
  ?>    <!-- header-section-starts -->
	<div class="header">
		<div class="menu-bar">
			<div class="container">
				<div class="login-section">
					<ul>
						<li><a href="register.php">Register</a> </li> |
                        <li><a class="active" href="login.php">Login</a>  </li> |
						<li><a href="#">Help</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<!-- content-section-starts -->
	<div class="content">
	<div class="container">
		<div class="login-page">
			   <div class="account_grid">
                    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
			   <div class="col-md-6 login-left wow fadeInLeft" data-wow-delay="0.4s">
			  	 <h3>NEW USERS</h3>
				<?php 
 $im="SELECT * FROM pharmacies,pharmacy_branches WHERE pharmacy_branches.pharmacyid = pharmacies.pharmacy_id AND pharmacy_branches.branchid = 'hfhcjhkf_1_2' ";
$imsql=mysqli_query($con,$im);
        while($imrec=mysqli_fetch_array($imsql))
        {
         $branch_site_image=$imrec['branch_site_image'];
        $rightclosestplace=$imrec['rightclosestplace'];
        $leftclosestplace=$imrec['leftclosestplace'];
        $closest_common_known_place=$imrec['closest_common_known_place'];   
          echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>PHARMACY IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$branch_site_image' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							 							
							   </div>";  
        }                            
                            
                            
                            ?>
                   nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbvnbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbvnbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbvnbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv    nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv nbdbvdvdbvdbv
			   </div>
<!--                   LOGIN FORM-->
<div class="col-md-6 login-right wow fadeInRight" data-wow-delay="0.4s">
			  	<h3>REGISTERED USERS</h3>
				<p>If you have an account with us, please log in.</p>
				<form method="post" action="#">
				  <div>
					<span>Email Address<label>*</label></span>
					<input type="text" name="email"> 
				  </div>
				  <div>
					<span>Password<label>*</label></span>
					<input type="password" name="password"> 
				  </div>
				  <a class="forgot" href="#">Forgot Your Password?</a>
				  <input type="submit" value="Login" name="lgn">
			    </form>
			   </div>	
			   <div class="clearfix"> </div>
			 </div> 
            <div class="account_grid">
                    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
			   <div class="col-md-6 login-left wow fadeInLeft" data-wow-delay="0.4s">
			  	 <h3>Health Insurrance</h3>
				 <?php 
 $im="SELECT * FROM pharmacies,pharmacy_branches WHERE pharmacy_branches.pharmacyid = pharmacies.pharmacy_id AND pharmacy_branches.branchid = 'hfhcjhkf_1_2' ";
$imsql=mysqli_query($con,$im);
        while($imrec=mysqli_fetch_array($imsql))
        {
         $branch_site_image=$imrec['branch_site_image'];
        $rightclosestplace=$imrec['rightclosestplace'];
        $leftclosestplace=$imrec['leftclosestplace'];
        $closest_common_known_place=$imrec['closest_common_known_place'];   
          echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>PHARMACY IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$branch_site_image' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>A REFERENCE IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$closest_common_known_place' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>RIGHT SIDE REFERENCE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$rightclosestplace' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>LEFT SIDE REFERENCE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$leftclosestplace' class='img-responsive' alt='' style='width:170px;height:110;'/></div>";  
        }                            
                            
                            
                            ?>
			   </div>
<!--                   LOGIN FORM-->
<div class="col-md-6 login-right wow fadeInRight" data-wow-delay="0.4s">
			  	<?php 
 $im="SELECT * FROM pharmacies,pharmacy_branches WHERE pharmacy_branches.pharmacyid = pharmacies.pharmacy_id AND pharmacy_branches.branchid = 'hfhcjhkf_1_2' ";
$imsql=mysqli_query($con,$im);
        while($imrec=mysqli_fetch_array($imsql))
        {
         $branch_site_image=$imrec['branch_site_image'];
        $rightclosestplace=$imrec['rightclosestplace'];
        $leftclosestplace=$imrec['leftclosestplace'];
        $closest_common_known_place=$imrec['closest_common_known_place'];   
          echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>PHARMACY IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$branch_site_image' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>A REFERENCE IMAGE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$closest_common_known_place' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>RIGHT SIDE REFERENCE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$rightclosestplace' class='img-responsive' alt='' style='width:170px;height:110;'/></div>"; 
            echo"<div class='res-img-2 nth-grid1 wow bounceIn 'data-wow-delay='0.4s'>
							   <p> <center><b>LEFT SIDE REFERENCE</b></center></p>
        <img src='pharmacy/branchimages_uploads/$leftclosestplace' class='img-responsive' alt='' style='width:170px;height:110;'/></div>";  
        }                            
                            
                            
                            ?>
			   </div>	
			   <div class="clearfix"> </div>
			 </div>
		   </div>
</div>
<div class="clearfix"></div>
		<?php include_once('footer.html')?>
</body>
</html>