<?php?>
 <div class="row">
                
                 <div class="col-md-12">
                      <div class="col-md-1">                   <!--new drugs  Modal-->        
<div class="panel-body">
<div class="modal fade" id="mypharmacyprofil" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="mypharmacyprofil"><?php echo "<b><center>".$pharmacy_name."</center></b>";?></h4></div><div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
   <?php 
   //getting the user id
  
 echo"<center>
 <img src='../users/logoes/{$pharmacy_logo}' style='width:120px;height:100px;'/></center><br>
 
 &nbsp;&nbsp;Pharmacy Email<b>:$pharmacy_email</b><br>
&nbsp;&nbsp;Pharmacy Tel<b>:$pharmacy_service_tel</b><br>
 &nbsp;&nbsp;Pharmacy Identification NO<b>:$pharmacy_authorization_identication</b><br>
&nbsp;&nbsp; Sign Up  Date<b>: $reg_date</b>
 " 
?> 
   
    
    <br>
    
    </div>

                                   
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<!--                                            <button type="Submit" class="btn btn-primary">Save Company</button>-->
                                        <?php echo"<a href='index.php?edit={$userid}'class='btn btn-default'><i class='fa fa-edit'></i></a>"?>
                                            
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div></div> 
    <div class="col-md-1">
        <div class="panel-body">
   
                            <div class="modal fade" id="mystore" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Main Store Status and Branch drug Store status</h4>
                                        </div>
                                        <div class="modal-body">
                                              <form role="form">
<div class="form-group has-success">
        
<label>Bill Id:</label>
    <input type="text" name="bill_id"class="form-control" placeholder="bill_id of the sold items ">    
    <br>
     <center> 

    <span class="col-lg-4  input-group custom-search-form">

<span class="input-group-btn">
<button type="submit" name="save_return" class="btn btn-lg btn-success btn-block">
Record Return
                                </button>
    
                            </span>
                        </span></center>
    </div>

 </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <!-- End returns model  -->
                </div>
  <div class="col-md-2">                   <!--new drugs  Modal-->        
<div class="panel-body">
<div class="modal fade" id="myModalinsurrance" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalinsurrance">Record Insurrence companies in partinership</h4></div><div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
 <label>Select Insurrence Company</label>
    <select type="text" name="drug_name" class="form-control" required>
    <option></option>
        <option></option>
    
    </select>      
    
    <br>
    
    </div>

                                   
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <button type="Submit" class="btn btn-primary">Save Company</button>
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div></div>
 
                     <div class="col-md-2">                   <!--new drugs  Modal-->        
<div class="panel-body">
<div class="modal fade" id="myModaladd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModaladd">Record New Drugs</h4></div><div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
 <label>Drug Name:</label>
    <input type="text" name="drug_name" class="form-control" placeholder="bill_id of the sold items " required>       
   
    <label>Drug price:</label>
    <input type="text" name="drug_price" class="form-control" placeholder="price drug" required>
    <label>Pricing description:</label>
       <select class="form-control" name="desc" required>
    <option>per unity</option>
    <option>combined</option>
    </select>
    <label>Experation Date:</label>
    <input type="date" name="exp_date" class="form-control" placeholder="expiration date " required>  
    <label>Quantity:</label>
    <input type="number" name="quantity" class="form-control" placeholder="quantity" required>     
    </div>
               
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit"  name="save_drug" class="btn btn-primary">Save changes</button>
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div></div>
                           <div class="col-md-2">
<!--                           saving branch into the database -->
<?php
$m="";                                                      
if(isset($_POST['savebranch']))
{
$lt=""; $lg=""; error_reporting(0); 
$latlong=explode(',',$_POST['latlong']);
$lt=$latlong[0]; $lg=$latlong[1];
echo 'lati'.$lt.'<br />';
echo 'long'.$lg.'<br />';
$pharmacycounter= "SELECT * FROM `pharmacy_branches` WHERE pharmacyid = $pharmacy_id";
$sqlpharmacies=mysqli_query($con,$pharmacycounter)or die(mysqli_error());
$counter=mysqli_num_rows($sqlpharmacies);    
$dates=date('Y-m-d');    
$telcontact=$_POST['telcontact'];
$province=$_POST['province'];    
$district=$_POST['district'];
$sector=$_POST['sector'];
$cell=$_POST['cell'];
$village=$_POST['village'];
$servicestarttime=$_POST['starttime'];
$serviceendtime=$_POST['endtime'];
$daysinfo=$_POST['daysinfo'];
 $a=$province[0].$province[1];
 $b=$district[0].$district[1];
 $c=$sector[0].$sector[1];
$d=$village[0].$village[1];
$branchid=$a.$b.$c.$d._.$counter._.$pharmacy_id;
    $m=$branchid;    
$branchimage_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
    
for($i = 0 ;$i < count($tmp_name_array); $i++){ if(move_uploaded_file($tmp_name_array[$i],"branchimages_uploads/".$branchimage_array[$i])){
    echo $branchimage_array[$i]."is uploaded successfully ";

}
                                            else{
echo "Data not saved and uploading".$branchimage_array[$i]."failed<br>";
                                            }
                                           }
    echo $branchid."<br>".$telcontact."<br>".$province.$dates."<br>".$branchimage_array[3];
    
  $binserts="INSERT  into `pharmacy_branches`
(branchid,pharmacyid,tel_contact_no,province,branch_district,branch_sector,branch_cell,branch_village,latitude,longitude,establishement_date,branch_site_image,closest_common_known_place,rightclosestplace,leftclosestplace,service_start_time,service_end_time,working_day_info) 
VALUES
('$branchid','$pharmacy_id','$telcontact','$province','$district','$sector','$cell','$village','$lt','$lg','$dates','$branchimage_array[0]','$branchimage_array[1]','$branchimage_array[2]','$branchimage_array[3]','$servicestarttime','$serviceendtime','$daysinfo')";
    $bresult = mysqli_query($con,$binserts)or die(mysqli_error());    
    if($bresult)
    {
        echo "<i class='fa fa-info' style='color:red;'>Branch is created</i>";
        echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";
    }
    else
        $m="error";                                   
}
                                
                               ?>
                          <?php echo"<font color='red'><center><b>".$m."</b></center></font>";?>      
                               
                         <div class="panel-body">
                           
                            <div class="modal fade" id="myModalbranch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Create a new branch </h4>
                                        </div>
                                        <div class="modal-body">
<form role="form" method="post" enctype="multipart/form-data">
<div class="form-group has-success">
   
 <label>Branch Service tel_contact:</label>
    <input type="text" name="telcontact" class="form-control" placeholder="service telephone number" required>       
   
    <label>Province:</label>
    <input type="text" name="province" class="form-control" placeholder="district where is located" required>
    <label>Branch District name:</label>
    <input type="text" name="district" class="form-control" placeholder="district where is located" required>
    <label>Branch sector name:</label>
    <input type="text" name="sector" class="form-control" placeholder="sector where it is located" required>
    <label>Branch cell:</label>
    <input type="text" name="cell"class="form-control" placeholder="cell where it is located" required>
    <label>Branch village:</label>
    <input type="text" name="village"class="form-control" placeholder="cell where it is located" required>
     <label>A Branch working site Image:</label>
    <input type="file" name="file_array[]" class="form-control" placeholder="cell where it is located" required>
    <label>The Closest Common Known place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Right side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Left side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Service  Time</label>
 <label>Start</label>   
 <input type="time" name="starttime"class="form-control" placeholder="cell where it is located" required>
 <label>End Time</label>
    <input type="time" name="endtime"class="form-control" placeholder="cell where it is located" required> 
    <label>Working days</label>
    <input type="text" name="daysinfo"class="form-control" placeholder="eg: monday up friday" required>
           
     <input type="text" name="latlong" id="demo" value="">                
    </div>

                                    
                                        <div class="modal-footer">
 <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" name="savebranch" class="btn btn-primary">Save Branch</button>
                                            
                                        </div>
                                                                </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div>
<!--    getting latitude and longitude                           -->
                               <script>
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.value = position.coords.latitude + 
    "," + position.coords.longitude;
}
</script>
                               
                               
                     </div>
    <div class="col-md-2">
        <div class="panel-body">                   
                <div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModalLabel">Assign Drugs to Branches</h4>
                                        </div>
                                        <div class="modal-body">
                                                     <form role="form">
<div class="form-group has-success">
    <label>Drug ID</label>
    <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>
    
<label>Quantity</label>
    <input type="text" name="search_place_field"class="form-control" placeholder="number of items"> 
    <label>Destination Branch</label>
   <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>   
    <br>
    
    </div>

                                    
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           <button type="submit" name="assign" class="btn btn-lg btn-primary ">
Assign drugs
                                </button>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div>
                     </div> 
                   
<div class="col-md-2">
<?php 
if(isset($_POST['save_employee']))
  {
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$password=$_POST['password'];
$email=$_POST['email'];
$emptel=$_POST['emptel'];
$assbranch=$_POST['assbranch'];
$username=$_POST['username'];
$workeridno=$_POST['workeridno']; 
    $branchiassigned=array();
    $branchiassigned=explode('.',$assbranch);
    $branchid=$branchiassigned[0];
    
    
$bwinsert="INSERT INTO branch_workers (worker_first_name,worker_last_name,worker_id_no,worker_username,worker_password,workers_email,worker_tel,data_of_employement,branch_id)VALUES('$fname','$lname','$workeridno','$username','$password','$email','$emptel','$dates','$branchid')";
$bwresult = mysqli_query($con,$bwinsert)or die(mysqli_error()); 
  if($bwresult) 
  {
   echo "<i class='fa fa-info' style='color:red;'>Employee was added</i>";
        echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";   
  }
}
                         
?>
    <div class="panel-body">
  <div class="modal fade" id="newemployee" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalLabel">Add an Employee To a branch</h4>
</div><div class="modal-body">
<form role="form" method="post" >
<div class="form-group has-success">
 <label>Branch Employee First name:</label>
    <input type="text" name="fname"class="form-control" placeholder="branch worker firstname " required> 
    <label>Branch Employee Last name:</label>
    <input type="text" name="lname"class="form-control" placeholder="branch worker last name" required> 
    <label>Employee Id no:</label>
    <input type="text" name="workeridno"class="form-control" placeholder="branch worker last name" maxlength="16" required>   
    <label>Branch Employee username:</label>
    <input type="text" name="username"class="form-control" placeholder="branch worker last name" required> 
    <label>Branch Employee password:</label>
    <input type="text" name="password"class="form-control" placeholder="branch worker last name" required> 
    <label>Branch Employee email:</label>
    <input type="text" name="email"class="form-control" placeholder=" worker email" required>
    <label>Branch Employee tel:</label>
    <input type="text" name="emptel"class="form-control" placeholder=" worker tel" required>
    <label>Assign Branch:</label>
<!--    retrieving braches-->
<select type="text" name="assbranch"class="form-control" placeholder="branch worker last name" required>
<?php  
$branch="";
$sql="SELECT * 
FROM  `pharmacy_branches` WHERE pharmacyid='$pharmacy_id'";
$branchquery=mysqli_query($con,$sql);
if($branchquery)
{
while($row=mysqli_fetch_array($branchquery))
   {
$branchid=$row["branchid"];
$branch_district=$row["branch_district"];
$branch_sector=$row["branch_sector"];
$branch_cell=$row["branch_cell"];
$branch.='<option>'.$branchid.".".$branch_district.".".$branch_sector.".".$branch_cell.'</option>';
     echo "<option>$branch</option>";
   }}
     
    ?>
    
    </select>    
   </div>
   <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" name="save_employee" class="btn btn-lg btn-primary">
Add Employees
                                </button> 
                                        </div>
</form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <!-- End returns model  -->
                </div>
                </div>
            </div>
?>