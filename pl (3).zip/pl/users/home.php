<!DOCTYPE html>
<html>
<head>
<title>Pharmacy Locator</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
<script src="js/simpleCart.min.js"> </script>	
</head>
<body>
      <?php     
   // <!-- HEADER END-->
    require('../dbcon/dbcon.php');
include("auth.php");
$message="";
    // getting the user id to inserted into pharmacies as a forein key
    $owner=$_SESSION['username'];
    $userid=""; $firstname=""; $lastname=""; $username=""; $user_email=""; $reg_date="";
    $sq = "SELECT * FROM `users` WHERE username='$owner'";
	 $mfetch = mysqli_query($con,$sq) or die(mysql_error());
     $fetch=mysqli_fetch_array($mfetch);
    $userid=$fetch['userid'];
    $firstname=$fetch['firstname'];
    $lastname=$fetch['lastname'];
    $telephone=$fetch['telephone'];
   $username=$fetch['username'];
   $user_email=$fetch['user_email'];
   $reg_date=$fetch['reg_date'];
    if (isset($_REQUEST['reg_pharmacy_btn']))
    {
    $pharmacyname = stripslashes($_REQUEST['pharmacyname']);
    $pharmacyname = mysqli_real_escape_string($con,$pharmacyname); 
    $pharmacylogo = $_FILES['pharmacylogo']['name'];
    $pharmacylogo_size =$_FILES['pharmacylogo']['size'];
        $extensions =array('.png','.gif','.jpg','.jpeg','.JPEG','.JPG','.PNG','.PDF','.pdf','.PNG');  
    $extension =strrchr($_FILES['pharmacylogo']['name'],'.'); 
	$pharmacy_link = stripslashes($_REQUEST['pharmacy_link']);
	$pharmacy_link = mysqli_real_escape_string($con,$pharmacy_link);
    $pharmacyemail = stripslashes($_REQUEST['pharmacyemail']);
	$pharmacyemail = mysqli_real_escape_string($con,$pharmacyemail);
    $service_tel = stripslashes($_REQUEST['service_tel']);
	$service_tel = mysqli_real_escape_string($con,$service_tel);
    $pharmacyid = stripslashes($_REQUEST['pharmacyid']);
	$pharmacyid = mysqli_real_escape_string($con,$pharmacyid);
	$reg_date = date("Y-m-d H:i:s");
if(!in_array($extension,$extensions))
{  
    $message='You must make use of file in the following forma type png, gif, jpg,jpeg'; 
    
}  
 else if($pharmacylogo_size >=50000000)
{
     
  $message='The file size exceeds the allowed size, please upload a file not bigger than 5MB.';
    
}
    else{
       
        
$pharmacylogos=$_FILES['pharmacylogo']['tmp_name'];
//$filelocation='logoes/'$pharmacylogos;        
$query = "INSERT into `pharmacies` (pharmacy_name,
pharmacy_logo,pharmacy_link,pharmacy_email,pharmacy_service_tel,pharmacy_authorization_identication,pharmacy_owner_id,reg_date) VALUES ('$pharmacyname','$pharmacylogo','$pharmacy_link','$pharmacyemail','$service_tel','$pharmacyid','$userid','$reg_date')";
        $result = mysqli_query($con,$query);
if ($result)
{
if(move_uploaded_file($pharmacylogos,'logoes/'.$_FILES['pharmacylogo']['name']))
{
    $message="File uploaded!and data Inserted Corrrectely!!";
    echo"<script>function redirect(){
window.location='pharmacy_profil.php';
}setInterval(redirect,1000);</script>";
    
}

}
        else
        {
            $message="what is this really";
            echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,2000);</script>";
        }
    
    }}
$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$row=mysqli_num_rows($result);
    if($row==1){
      header("Location: ../pharmacy/?");  
    }
//$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
//$result = mysqli_query($con,$query) or die(mysqli_error()); 
//$row=mysqli_num_rows($result);
//    if($row==1){
//      header("Location: ../pharmacy/?");  
//    } 
?>
    <!-- header-section-starts -->
	<div class="header">
		<div class="menu-bar">
			<div class="container">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;">&nbsp;<?php echo "WELCOME"."&nbsp;". ucfirst($lastname); ?></span>
                            </a>
				<div class="login-section">
					<ul>
						<li><a  class="active" href="register.php">Home</a> </li> |<li><a href="register.php">Register My Pharmacy</a> </li> |
                        <li><a href="logout.php">Logout</a>  </li> |
						<li><a href="#">info</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<!-- content-section-starts -->
	<div class="content">
	<div class="container">
		<div class="login-page">
			    <div class="account_grid">
                    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
			   <div class="col-md-4 login-left wow fadeInLeft" data-wow-delay="0.4s">
			  	 <h3>PERSONAL INFORMATION</h3>
				 <p>FIRST NAME:<?php echo "<b>".strtoupper($firstname)."</b>"; ?><br><br>
                    LAST NAME:<?php echo "<b>".$lastname."</b>"; ?><br><br>
                    TELEPHONE No:<?php echo "<b>".$telephone."</b>"; ?><br><br>
                    USERNAME:<?php echo "<b>".$username."</b>"; ?><br><br>
                    PERSONAL EMAIL:<?php echo "<b>".$user_email."</b>"; ?><br><br>
                    REGISTRATION DATE:<?php echo "<b>".$reg_date."</b>"; ?><br>
                               
                               <?php
                               echo"<br><a href='index.php?edit={$userid}'class='acount-btn'>Update my info</a>";
                               ?></p>
				 
			   </div>
<!--                   LOGIN FORM-->
<div class="col-md-8 login-right wow fadeInRight" data-wow-delay="0.4s">
			  	<h3>REGISTER YOUR PHARMACY</h3>
				<form method="POST" action="#" enctype="multipart/form-data">
				  <div>
					<span>Pharmacy Name<label>*</label></span>
					<input type="text" name="pharmacyname"> 
				  </div>
                    <div>
					<span>Pharmacy Logo<label>*</label></span>
					<input type="file" name="pharmacylogo"> 
				  </div>
                    <div>
					<span>Pharmacy website link</span>
					<input type="text" name="pharmacy_link"> 
				  </div>
				  <div>
					<span>Service email<label>*</label></span>
					<input type="email" name="pharmacyemail"> 
				  </div>
                    <div>
					<span>Service Telephone<label>*</label></span>
					<input type="text" name="service_tel"> 
				  </div>
                    <div>
					<span>Pharmacy Identification number<label>*</label></span>
					<input type="text" name="pharmacyid"> 
				  </div>
				  <center><input type="submit" value="Register" name="reg_pharmacy_btn"></center>
			    </form>
			   </div>	
			   <div class="clearfix"> </div>
			 </div>
		   </div>
</div></div>
<div class="clearfix"></div>
		<?php include_once('../footer.html')?>
</body>
</html>