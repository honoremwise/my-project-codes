<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Pharmacy Locator</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     
</head>
<body>
    <header>
        <section class="menu-section">
<div class="container">
<div class="row">
<div class="col-md-12">
 <div class="navbar-collapse collapse ">
<ul id="menu-top" class="nav navbar-nav navbar-right">
<li><a href="index.php">My account</a></li>
<li><a class="menu-top-active"  href="register_pharmacy.php">Create Pharmacy Page</a></li>
   
<li><a href="logout.php">LOGout </a></li>
<li><a href="blank.php">HELP</a></li>
        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    </header>
     <?php     
   // <!-- HEADER END-->
    require('../dbcon/dbcon.php');
include("auth.php");
$message="";
    // getting the user id to inserted into pharmacies as a forein key
    $owner=$_SESSION['username'];
    $sq = "SELECT * FROM `users` WHERE username='$owner'";
	 $mfetch = mysqli_query($con,$sq) or die(mysql_error());
     $fetch=mysqli_fetch_array($mfetch);
    $userid=$fetch['userid'];
    $firstname=$fetch['firstname'];
    $lastname=$fetch['lastname'];
    
    if (isset($_REQUEST['reg_pharmacy_btn'])){
     echo"what is this23 ";   
	$pharmacyname = stripslashes($_REQUEST['pharmacyname']);
    $pharmacyname = mysqli_real_escape_string($con,$pharmacyname); 
    $pharmacylogo = $_FILES['pharmacylogo']['name'];
    $pharmacylogo_size =$_FILES['pharmacylogo']['size'];
        $extensions =array('.png','.gif','.jpg','.jpeg','.JPEG','.JPG','.PNG','.PDF','.pdf','.PNG');  
    $extension =strrchr($_FILES['pharmacylogo']['name'],'.'); 
	$pharmacy_link = stripslashes($_REQUEST['pharmacy_link']);
	$pharmacy_link = mysqli_real_escape_string($con,$pharmacy_link);
    $pharmacyemail = stripslashes($_REQUEST['pharmacyemail']);
	$pharmacyemail = mysqli_real_escape_string($con,$pharmacyemail);
    $service_tel = stripslashes($_REQUEST['service_tel']);
	$service_tel = mysqli_real_escape_string($con,$service_tel);
    $pharmacyid = stripslashes($_REQUEST['pharmacyid']);
	$pharmacyid = mysqli_real_escape_string($con,$pharmacyid);
	$reg_date = date("Y-m-d H:i:s");

if(!in_array($extension,$extensions))
{  
    $message='You must make use of file in the following forma type png, gif, jpg,jpeg'; 
    
}  
 else if($pharmacylogo_size >=50000000)
{
     
  $message='The file size exceeds the allowed size, please upload a file not bigger than 5MB.';
    
}
    else{
       
        
$pharmacylogos=$_FILES['pharmacylogo']['tmp_name'];
//$filelocation='logoes/'$pharmacylogos;        
$query = "INSERT into `pharmacies` (pharmacy_name,
pharmacy_logo,pharmacy_link,pharmacy_email,pharmacy_service_tel,pharmacy_authorization_identication,pharmacy_owner_id,reg_date) VALUES ('$pharmacyname','$pharmacylogo','$pharmacy_link','$pharmacyemail','$service_tel','$pharmacyid','$userid','$reg_date')";
        $result = mysqli_query($con,$query);
if ($result)
{
if(move_uploaded_file($pharmacylogos,'logoes/'.$_FILES['pharmacylogo']['name']))
{
    $message="File uploaded!and data Inserted Corrrectely!!";
    echo"<script>function redirect(){
window.location='pharmacy_profil.php';
}setInterval(redirect,1000);</script>";
    
}

}
        else
        {
            $message="mysqli_error()";
            echo"<script>function redirect(){
window.location='register_pharmacy.php';
}setInterval(redirect,1000);</script>";
        }
    
    }}
    echo"what is this ";
        
?>
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="assets/img/logo.png" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;">&nbsp;<?php echo strtoupper($firstname)."&nbsp;".ucfirst($lastname); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <a class="media-left" href="#">
                                        <img src="assets/img/64-64.jpg" alt="" class="img-rounded" />
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo $_SESSION['username']; ?> </h4>
                                        <h5>Pharmacy Owner</h5>

                                    </div>
                                </div>
                                <hr />
                                <h5><strong>Personal Bio : </strong></h5>
                                Anim pariatur cliche reprehen derit.
                                <hr />
                                <a href="#" class="btn btn-info btn-sm">Full Profile</a>&nbsp; <a href="login.html" class="btn btn-danger btn-sm">Logout</a>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
   
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    
                  <div class="col-md-12">
                      <k class="page-head-line"><center>Pharmacy Registration Form </center></k>
                    </div>
                  
                </div>
<div class="row">
<div class="col-md-3"></div> 
<div class="col-md-6">
    
<div class="panel panel-success">
    
<div class="panel-body">
<form role="form" action="#" method="post" enctype="multipart/form-data">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?> 
    <div class="form-group has-success">
<label class="control-label" for="success">Pharmacy Name</label>
<input type="text" name="pharmacyname"class="form-control" id="success" />
                                        </div>
    <div class="form-group has-success">
<label class="control-label" for="success">Pharmacy Logo</label>
<input type="file" name="pharmacylogo" class="form-control" id="success"/>
                                        </div> 
    <div class="form-group has-success">
<label class="control-label" for="success">Pharmacy Website Link</label>
<input type="text" name="pharmacy_link" class="form-control" id="success" />
                                        </div>  
<div class="form-group has-success">
<label class="control-label" for="success">Valid Email</label>
<input type="text" name="pharmacyemail" class="form-control" id="success" />
                                        </div>    
<div class="form-group has-success">
<label class="control-label" for="success">Service Tel No:</label>
<input type="text" name="service_tel" class="form-control" id="success" />
                                        </div>
<div class="form-group has-success">
<label class="control-label" for="success">Pharmacy Identification Number</label>
<input type="text" class="form-control" id="success" name="pharmacyid"/>
                                        </div>
    <div class="form-group has-success">

<button type="submit" class="btn btn-lg btn-info btn-block" id="success" name="coordinates" value="browse location"><i class="fa fa-refresh"></i>Get Geolocation</button>
       
                                        </div>

<div class="form-group has-success">
 <center>  
<button type="submit" name="reg_pharmacy_btn" class="btn btn-lg btn-success btn-block" id="success" style="width:50%;">Register</button>
    </center> 
   
                                        </div>

                                    </form>

                        </div>
                            </div>
                        </div>
                    <div class="col-md-3"></div>
                </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
   <?php include_once('../footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>