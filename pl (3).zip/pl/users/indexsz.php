<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Pharmacie Locator</title>
     <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
     
</head>
<body>
    <header>
        <section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
<ul id="menu-top" class="nav navbar-nav navbar-right">
<li><a class="menu-top-active" href="index.php">MY account</a></li>
<li><a href="register_pharmacy.php">Create pharmacy page</a></li>
     <li><a href="logout.php">Logout </a></li>
    <li><a href="blank.php">Help</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    </header>
    <?php     
require_once('../dbcon/dbcon.php');
include_once("auth.php");
    $user=$_SESSION['username'];
$userid=""; $firstname=""; $lastname=""; $username=""; $user_email=""; $reg_date="";
$query = "SELECT users.userid,users.firstname,users.lastname,users.telephone,users.username,users.user_email,users.reg_date FROM users where users.username='$user'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$rows=mysqli_num_rows($result);
    if($rows==1)
    {
$rec=mysqli_fetch_array($result);
$userid=$rec['userid'];
$firstname=$rec['firstname'];
$lastname=$rec['lastname'];
$telephone=$rec['telephone'];
$username=$rec['username'];
$user_email=$rec['user_email'];
$reg_date=$rec['reg_date'];
}
$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$row=mysqli_num_rows($result);
    if($row==1){
      header("Location: ../pharmacy/?");  
    }
$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$row=mysqli_num_rows($result);
    if($row==1){
      header("Location: ../pharmacy/?");  
    }
    

?>
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">

                    <img src="assets/img/logo.png" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;">&nbsp;<?php echo  $_SESSION['username']; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                     <div class="media-body">
                                        <h4 class="media-heading"><?php  echo $_SESSION['username']; ?> </h4>
                                        <h5><br><b>Pharmacies Locator user</b></h5>

                                    </div>
                                </div>
                                
                                
                               <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
   
    <!-- MENU SECTION END--> 
<div class="content-wrapper">
        <div class="container">
            <div class="row">

            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success">
                        On this Platform you can find  pharmacies by inputting the location where you want to check to know what are open ones ,closed ones insurrence companies they work with,and more information about them ,But also you can get the closest pharmacies by pressing the button and obtain the information about these pharmacies.
                    </div>
                </div>

            </div>
<!--            inserted row mine-->
            <div class="row">
                <div class="col-md-4">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-primary">
                       
                        <div class="panel-body">
                            
                            
                           <b> 
                           first name:<?php echo $firstname; ?><br>
                            last name:<?php echo $lastname; ?><br>
                            Telephone:<?php echo $telephone; ?><br>
                            Username:<?php echo $username; ?><br>
                            email:<?php echo $user_email; ?><br>
                            Registered since:<?php echo $reg_date; ?><br>
                               
                               <?php
                               echo"<center><a href='index.php?edit={$userid}'class='btn btn-primary'>Update</a></center>"
                               ?>
                                                             
                            </b>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
                <div class="col-md-8">
                    <div class="panel panel-primary">
                        
                        <div class="panel-heading">
                            <center><n style="font-size:1em">
                              Closest Pharmacies  
                                </n></center>
                                                        
                        </div>
                         <form role="form">
<div class="form-group has-primary">
    
<span class="col-lg-6 input-group custom-search-form">
<input type="search" name="search_place_field"class="form-control" placeholder="Input a Healtth insurrance to get a list of pharmacies ">
<span class="input-group-btn">
<button class="btn btn-primary" name="search_btn"type="submit" >
<i class="fa fa-search" style="font-size=2em;">&nbsp;By Health Insurrance</i>
                                </button>
                            </span>
                        </span></div>

                    </form> 
<div class="panel-body">
            
  
<form role="form">
1
<br>
    2
    <br>1
<br>
    2
    <br>1
<br>
    2
    <br>

                                    </form>
    
                        </div>
                            </div>

    
                         
   

                            
                    
                    <!-- End  Basic Table  -->
                </div>
                     
            </div>
               <!--          end  inserted row mine-->
              </div>
        </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include_once('../footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
