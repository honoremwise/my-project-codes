<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy;UR Students Project in academic year 2016-2017 | Topic : <a href="#" target="_blank">Pharmacy Locator web and mobile application</a>
                </div>

            </div>
        </div>
    </footer>