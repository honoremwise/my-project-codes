<!DOCTYPE html>
<html>
<head>
<title>PHARMACY LOCATOR</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
<script src="js/simpleCart.min.js"> </script>	
</head>
<body>
     <?php 
    
      // HEADER END-->
  
require('dbcon/dbcon.php');
// If form submitted, insert values into the database.
     $message="";
if (isset($_REQUEST['btn_create_account'])){
        // removes backslashes
	$firstname = stripslashes($_REQUEST['fname']);
        //escapes special characters in a string
	$firstname = mysqli_real_escape_string($con,$firstname); 
	$lastname = stripslashes($_REQUEST['lname']);
	$lastname = mysqli_real_escape_string($con,$lastname);
	$telephone = stripslashes($_REQUEST['tel']);
	$telephone = mysqli_real_escape_string($con,$telephone);
    $username = stripslashes($_REQUEST['username']);
	$username = mysqli_real_escape_string($con,$username);
    $password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
    $confpass = stripslashes($_REQUEST['confpass']);
    $confpass = mysqli_real_escape_string($con,$confpass);
    $email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	$reg_date = date("Y-m-d H:i:s");
    if($password==$confpass)
    {
$query = "INSERT into `users` (firstname,lastname,telephone,username,password,user_email,reg_date)
VALUES ('$firstname','$lastname','$telephone','$username', '".md5($password)."', '$email', '$reg_date')";
        $result = mysqli_query($con,$query);
        if($result){
            $message =" user account created correctly";
        }
    else
    {
    $message="no user account created!";
    }
    }
    else {
        $message="entered password mismacthed!";
    }}                      
?>
        <!-- header-section-starts -->
	<div class="header">
			<div class="menu-bar">
			<div class="container">
				<div class="login-section">
					<ul>
						<li><a href="index.php">Home</a>  </li> |
                        <li><a class="active" href="#">Register</a> </li> |
                        <li><a href="login.php">Login</a>  </li> |
						<li><a href="#">Help</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<!-- content-section-starts -->
	<div class="content">
	<div class="main">
	   <div class="container">
		  <div class="register">
		  	  <form method="post" action="#"> 
				 <div class="register-top-grid">
					<center><h3>USER ACCOUNT CREATION FORM</h3></center>
                     <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
					 <div class="wow fadeInLeft" data-wow-delay="0.4s">
						<span>First Name<label>*</label></span>
						<input type="text" name="fname"> 
					 </div>
					 <div class="wow fadeInRight" data-wow-delay="0.4s">
						<span>Last Name<label>*</label></span>
						<input type="text" name="lname"> 
					 </div>
                     <div class="wow fadeInRight" data-wow-delay="0.4s">
						<span>Telephone No<label>*</label></span>
						<input type="text" name="tel"> 
					 </div>
					 <div class="wow fadeInLeft" data-wow-delay="0.4s">
						 <span>Email Address<label>*</label></span>
						 <input type="text" name="email"> 
					 </div>
                     <div class="wow fadeInLeft" data-wow-delay="0.4s">
						 <span>User name<label>*</label></span>
						 <input type="text" name="username"> 
					 </div>
					
					 </div>

				     <div class="register-bottom-grid">
						    
							 <div class="wow fadeInLeft" data-wow-delay="0.4s">
								<span>Password<label>*</label></span>
								<input type="text" name="password">
							 </div>
							 <div class="wow fadeInRight" data-wow-delay="0.4s">
								<span>Confirm Password<label>*</label></span>
								<input type="text" name="confpass">
							 </div>
					 </div> 
                  <div class="register-bottom-grid">
						    
		<center><input type="submit" name="btn_create_account" value="Submit" class="btn btn-danger"style="font-size:1.2em;"></center>
							
					 </div>

				</form>
								
		   </div>
	     </div>
	    </div> </div>

<div class="clearfix"></div>
			<?php include_once('footer.html')?>

</body>
</html>