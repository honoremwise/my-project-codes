<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>test</title> 
    </head>
<script src="js/jquery.min.js"></script>
<!--google map api    -->
<!--still not find it    <script src="js/jquery.js"></script>-->

<!--  <script async defer src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap"--><script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBdAXGeAzLivzpjW24uOjwXEM3GWgQ5BMk&callback=initMap"
  type="text/javascript"></script>
    
   
<script>
    x = navigator.geolocation;
    x.getCurrentPosition(success, failure);
        function success(position){
            //fetch coordinates
         var mylat= position.coords.latitude;
        var mylong= position.coords.longitude;
            $('#lat').html(mylat);
            $('#long').html(mylong);
          //Google-API-ready latitude and longitude string 
         var coords =new google.maps.LatLng(mylat, mylong);
//              // setting up the google map
            var mapOptions = {
                zoom:16,
                center: coords,
                mapTypeId: google.maps.MapTypeId.ROADMAP
                            }
//            // creating the map
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        var marker =new google.maps.Marker({map:map,position:coords});
        }
        function failure(){
           $('#lat').html("<p> It didn't work,co-ordinates not available!<p>"); 
        }
    </script>
	<style>
        #map{
            width:400px;
            height: 400px;
        }
    </style> 
<body>
<div id="map">
</div> 
<div id="lat"></div>
<div id="long">
    
    </div>
    <?php
    echo date("Y:m:d");?>
    
                        
<!--  getting coordinates-->
   
<!--    end-->
				
</body>
</html>