<!DOCTYPE html>
<html>
<head>
<title>Pharmacy Locator</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
<script src="js/simpleCart.min.js"> </script>	
</head>
<body>
      <?php 
require('dbcon/dbcon.php');
session_start();
    $message="";
    $username="";
    $password="";
// If form submitted, check values  from the database.
if (isset($_POST['lgn'])){ 
            // removes backslashes
	$username = stripslashes($_REQUEST['email']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	//Checking is user existing in the database or not
    if($username!="" && $password!="")
    {
$branchquery = "SELECT * FROM `branch_workers` WHERE username='$username'
and worker_password='$password'";
$branch_result = mysqli_query($con,$branchquery) or die(mysqli_error());
	$branchrecs = mysqli_num_rows($branch_result);
       
// to trying to login as  user from different tble but stack
$query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysqli_error());
	$rows = mysqli_num_rows($result);
        
        if($rows==1)
        {
	    $_SESSION['username'] = $username;
            // Redirect user to users folder home.php
            if($_SESSION['username']!='admin')
            {
            header("Location: users/?");   
            }
            else
            {
	     header("Location: admin/?"); 
            }
         }
         if($branchrecs==1)
        {
             $_SESSION['username'] = $username;
            if($_SESSION['username']=='admin')
            {
            header("Location: pharmacy/branch_admin.php");   
            }
            else 
            {
	     header("Location: pharmacy/branch.php"); 
            }
          } 
else{
	$message="incorrect creditentials";
	}
    }
    else if ($username=="" && $password==""){
        $message="please fill your authentications first";
    }}
    ?>
    <!-- header-section-starts -->
	<div class="header">
		<div class="menu-bar">
			<div class="container">
				<div class="login-section">
					<ul>
						<li><a href="register.php">Register</a> </li> |
                        <li><a class="active" href="login.php">Login</a>  </li> |
						<li><a href="#">Help</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<!-- content-section-starts -->
	<div class="content">
	<div class="container">
		<div class="login-page">
			    <div class="dreamcrub">
			   	     <ul class="previous">
                	<li><a href="index.php">Go to Home Page</a></li>
                </ul>
                <div class="clearfix"></div>
			   </div>
			   <div class="account_grid">
                    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
			   <div class="col-md-6 login-left wow fadeInLeft" data-wow-delay="0.4s">
			  	 <h3>NEW USERS</h3>
				 <p>By creating pharmacy locator account ,As a pharmacist you will be able to record your pharmacy and all its branches, manage its sales  make an easy publicity to milions of users that uses this aplication to reach easily to pharmacists..</p>
				 <a class="acount-btn" href="register.php">Create an Account</a>
			   </div>
<!--                   LOGIN FORM-->
<div class="col-md-6 login-right wow fadeInRight" data-wow-delay="0.4s">
			  	<h3>REGISTERED USERS</h3>
				<p>If you have an account with us, please log in.</p>
				<form method="post" action="#">
				  <div>
					<span>Email Address<label>*</label></span>
					<input type="text" name="email"> 
				  </div>
				  <div>
					<span>Password<label>*</label></span>
					<input type="password" name="password"> 
				  </div>
				  <a class="forgot" href="#">Forgot Your Password?</a>
				  <input type="submit" value="Login" name="lgn">
			    </form>
			   </div>	
			   <div class="clearfix"> </div>
			 </div>
		   </div>
</div>
<div class="clearfix"></div>
		<?php include_once('footer.html')?>
</body>
</html>