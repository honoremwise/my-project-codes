<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Pharmacie Locator</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     
</head>
<body>
     <?php //include_once('../header.php');
    // <!-- HEADER END-->
    require('../dbcon/dbcon.php');
include("auth.php");?>
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="assets/img/logo.png" />
                </a>
            </div>
            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;">&nbsp;<?php echo $_SESSION['username']; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    
                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo $_SESSION['username']; ?> </h4>
                                        <h5><b><br>SYSTEM Administrator</b></h5>
                                    </div>
                                </div>
                              <center>
                                
                                <a href="logout.php" class="btn btn-primary btn-sm">My profile</a>&nbsp;
                                  <a href="logout.php" class="btn btn-danger btn-sm">Logout</a></center>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    
    <!-- MENU SECTION END--> 
<div class="content-wrapper">
        <div class="container">
            <div class="row">
            </div>
           
<!--            inserted row mine-->
            <div class="row">
                
                 
                    
  <div class="col-md-6">                   <!--new drugs  Modal-->        
<div class="panel-body">
      <?php
    $id="";
    $name="";
    if(isset($_GET['editpharmacy']))
{
$id=$_GET['editpharmacy'];
        //to retrieve data
 $selectinsux = "SELECT * FROM `pharmacies` WHERE pharmacy_id = $id ";
$insuresultx = mysqli_query($con,$selectinsux) or die(mysql_error()); 
$line=mysqli_fetch_array($insuresultx);
        $name=$line['pharmacy_name'];
        $pharmacy_logo=$line['pharmacy_logo'];
        $pharmacy_link=$line['pharmacy_link'];
        $pharmacy_email=$line['pharmacy_email'];
        $pharmacy_service_tel=$line['pharmacy_service_tel'];
        $access_status=$line['access_status'];
        $advertstatus=$line['advertstatus'];  
} 
    //to hide from the home page
if(isset($_POST['unpost']))
      {
       $idtohide=$id;
$unpostqry = "UPDATE `pharmacies` SET advertstatus = 'unpost' WHERE pharmacy_id = $idtohide";
$chekunpostqry = mysqli_query($con,$unpostqry) or die(mysql_error()); 
if($chekunpostqry)
{
    echo "<center>{$name}access status hiden  successfully</center>";
     echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,3000);</script>";
}   
          
      }
    //repost
    if(isset($_POST['repost']))
      {
       $idtohide=$id;
$unpostqry = "UPDATE `pharmacies` SET advertstatus = 'grant' WHERE pharmacy_id = $idtohide";
$chekunpostqry = mysqli_query($con,$unpostqry) or die(mysql_error()); 
if($chekunpostqry)
{
    echo "<center>{$name}access status hiden  successfully</center>";
     echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,3000);</script>";
}   
          
      }
    //to reflesh a page
if(isset($_POST['backstep']))
    {
echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";
}
    // reacord acces
    if(isset($_POST['regrant']))
    {
      $updatepha = "UPDATE `pharmacies` SET access_status = 'Granted' WHERE pharmacy_id = $id ";
$phaupdate = mysqli_query($con,$updatepha) or die(mysql_error()); 
if($phaupdate)
{
    echo "<center>{$name}access status was desabled successfully</center>";
     echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,3000);</script>";
}
     
    }
    // block pharmacy access
if(isset($_POST['revoke']))
    {
      $updatepha = "UPDATE `pharmacies` SET access_status = 'revoked' WHERE pharmacy_id = $id ";
$phaupdate = mysqli_query($con,$updatepha) or die(mysql_error()); 
if($phaupdate)
{
    echo "<center>{$name}access status was desabled successfully</center>";
     echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,3000);</script>";
}
     
    }
    //delete pharmacy
    if(isset($_POST['delbtn']))
    {
//  the delfunction is used to delete all recording of a certain id      
include('delfunction.php');
del('pharmacy_branches','pharmacyid',$id);
del('branch_drug_store','pharmacy_id',$id);
del('drug_assignments','pharmacy_id',$id);
del('price_records','pharmacyid',$id);            
$x=del('pharmacies','pharmacy_id',$id);   
        if($x=='yes')
    {
        echo"<center>successfully done<center>";
   echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,3000);</script>";     
        
    }
}
    //data management end
    ?>
 <div class="modal fade" id="myModalload" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalLabel"><center><?php echo $name ?></center></h4></div><div class="modal-body">
     
<form role="form" method="post" action="#">
<div class="form-group has-primary">    
        <?php echo "<img src='../users/logoes/{$pharmacy_logo}'style='width:100px; height:70px;'/>";?>
    <br>
 <label>Pharmacy Name:</label>
    <input type="text" name="pharmacy" class="form-control" value="<?php echo $name;?>" > 
    <label>Pharmacy Tel contact Addresse:</label>
    <input type="text"  class="form-control" value="<?php echo $pharmacy_service_tel;?>" > 
    <label>Pharmacy Email addresse:</label>
    <input type="text"  class="form-control" value="<?php echo $pharmacy_email;?>" >  
    <label>Pharmacy Web site:</label>
    <input type="text" class="form-control" value="<?php echo $pharmacy_link;?>" >
    <label>Home page adverts :</label>
    <input type="text" name="vstatus"class="form-control" value="<?php echo $advertstatus;?>" > 
    <label>Access Status :</label>
    <input type="text" name="vstatus"class="form-control" value="<?php echo $access_status;?>" >  
      </div>  
 <div class="modal-footer">
<center><input type="submit" class="btn btn-default" name="unpost" value="HIDE">
    <input type="submit" class="btn btn-default" name="repost" value="REPOST">
<input type="submit" class="btn btn-default" name="revoke" value="REVOKE"><input type="submit" class="btn btn-default" name="regrant" value="REGRANT"> 
    <input type="submit" class="btn btn-default" name="delbtn" value="DELETE">
    <input type="submit" class="btn btn-default" name="backstep" value="CANCEL">
     </center>
                                   </div>
    </form>
        </div></div>
</div>
</div>
    </div>
               </div> 
            </div>
                <div class="row">
        <div class="col-md-12">
    <div class="panel-body">
 <div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><a href="insurrance.php" title="go to Insurrance Management" class="close">y</a></button>
 <a href="insurrance.php" title="go to Insurrance Management" class="fa fa-bars" style='font-size:1.2em;color:#000000'>&nbsp;&nbsp;Go Health Insurrance</a>    
<h4 class="modal-title" id="myModalLabel"><center>Pharmacies  Management(Access and Advertisement) panel</center></h4></div><div class="modal-body">
    <?php //echo"<font color='red'><center><b>".$message."</b></center></font>";?>
                                <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
        <th> Logo</th>
         <th> Name</th>
        <th> Link</th>
        <th> Email</th>
        <th> Service Tel</th>
        <th>Identification Id</th>
            <th>Home visibility</th>
         <th>Access Status</th> 
         <th>Option</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
$pharmaciesquery = "SELECT * FROM `pharmacies`";
$pharmaciesresult = mysqli_query($con,$pharmaciesquery) or die(mysql_error()); 
while($pharmaciesrec=mysqli_fetch_array($pharmaciesresult))
{
    $pharmacy_id=$pharmaciesrec['pharmacy_id'];
    $pharmacy_name=$pharmaciesrec['pharmacy_name'];
    $pharmacy_logo=$pharmaciesrec['pharmacy_logo'];
    $pharmacy_link=$pharmaciesrec['pharmacy_link'];
    $pharmacy_email=$pharmaciesrec['pharmacy_email'];
    $pharmacy_service_tel=$pharmaciesrec['pharmacy_service_tel'];
    $advertstatus=$pharmaciesrec['advertstatus'];
$pharmacy_authorization_identication=$pharmaciesrec['pharmacy_authorization_identication'];
    $pharmacy_owner_id=$pharmaciesrec['pharmacy_owner_id']; 
    $reg_date=$pharmaciesrec['reg_date'];
    $access_status=$pharmaciesrec['access_status'];
echo"<tr><td><img src='../users/logoes/{$pharmacy_logo}'style='width:100px; height:70px;'/></td><td>$pharmacy_name</td><td>$pharmacy_link</td><td>$pharmacy_email</td><td>$pharmacy_service_tel</td><td>$pharmacy_authorization_identication</td><td>$advertstatus</td><td>$access_status</td>
    <td><a href='home.php?editpharmacy={$pharmaciesrec['pharmacy_id']}'class='btn btn-default' title='Edit details'><i class='fa fa-tasks'></i></a></td></tr>";
} 
                                  if(isset($_GET['editpharmacy']))
                                      
{
 $s=$_GET['editpharmacy'];
$selectinsuxy = "SELECT * FROM `pharmacies` WHERE pharmacy_id = $id ";                $insuresultxy = mysqli_query($con,$selectinsuxy) or die(mysql_error()); 
$read=mysqli_fetch_array($insuresultxy);
    $name=$read['pharmacy_name'];
   echo"<center><k style='font-size:1.2em;color:red'>You have choosen&nbsp;{$name} Do you want to continue with this record&nbsp;?</k><i class='fa fa-check' data-toggle='modal' data-target='#myModalload'> &nbsp; or &nbsp;<a href='home.php'><k style='font-size:1.2em;color:red' class='fa fa-times'></k></a></i></center>";
}  
?>
                                        
                                    </tbody>
                                </table>
                         </div>


            </div></div>

                    </div></div>
     
                    
           
            </div>
            
    </div>
               <!--          end  inserted row mine-->
              </div>
   
      
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include_once('../footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
