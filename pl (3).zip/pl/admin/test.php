<?php
//include('delfunction.php');
//$id=2;
//$x=del('insurrence_companies','insurrence_id',$id);
//$x;
//if($x=='0record')
//{
//    echo"empty";
//}
//if($x=='yes')
//{
//echo"data deleted";
//}

//echo del('pharmacy_drugs','pharmacy_id',$id); 
//echo del('pharmacy_drugs','pharmacy_id',$id); 
//echo del('pharmacy_branches','branchid',$id); 
//is_string($id);
//if(is_string($id))
//{
//    echo "string";
//}
//else
//    echo "not string";


// $qry =  "SELECT * FROM `pharmacy_drugs` WHERE pharmacy_id = 1";
//$result = mysqli_query($con,$qry) or die(mysql_error());
//$count=mysqli_num_rows($result); 
//    if($result)
//    {
//        echo "wow";
//    }
//  $deletepricerecord = "DELETE FROM `price_records` WHERE pharmacyid = $id ";
//$deletedrugrecord = "DELETE FROM `pharmacy_drugs` WHERE pharmacy_id = $id "; $deletedbranch = "DELETE FROM `pharmacy_branches` WHERE pharmacyid = $id ";
//$deletedassignment = "DELETE FROM `drug_assignments` WHERE pharmacy_id = $id ";$deletedassignment = "DELETE FROM `branch_drug_store` WHERE pharmacy_id = $id "; //$deletedassignment = "DELETE FROM `branch_workers` WHERE pharmacy_id = $id "; 
        //$deletepharmacy = "DELETE FROM `pharmacies` WHERE pharmacy_id = $id ";  
//try creating some functions


?>
<?php
//function del($table,$colum,$reference){
//include('../dbcon/dbcon.php'); 
// if(!is_string($reference))
//{   
//$qry = "SELECT * FROM `$table` WHERE $colum = $reference";
//$result = mysqli_query($con,$qry) or die(mysql_error());
//$count=mysqli_num_rows($result); 
//    if($count > 0)
//     {
// $deletepricerecord = "DELETE FROM `$table` WHERE $colum = $reference";
//$delquery = mysqli_query($con,$deletepricerecord) or die(mysql_error()); 
//        if($delquery)
//        {
//         return "deleted";
//        }
//        else{
//            return " not deleted";
//        }
//     }
//     else{
//         return "no record found";
//     }
// }
//    else
//    {
//    $qry = "SELECT * FROM `$table` WHERE $colum = '$reference'";
//$result = mysqli_query($con,$qry) or die(mysql_error());
//$count=mysqli_num_rows($result); 
//    if($count > 0)
//     {
// $deletepricerecord = "DELETE FROM `$table` WHERE $colum = '$reference'";
//$delquery = mysqli_query($con,$deletepricerecord) or die(mysql_error()); 
//        if($delquery)
//        {
//         return "deleted";
//        }
//        else{
//            return " not deleted";
//        }
//     }
//     else{
//         return "no record found";
//     }    
//        
//    }
//}
////function to select
//function sel($table,$colum,$reference){
//include('../dbcon/dbcon.php'); 
// if(!is_string($reference))
//{   
//$qry = "SELECT * FROM `$table` WHERE $colum = $reference";
//$result = mysqli_query($con,$qry) or die(mysql_error());
//$count=mysqli_num_rows($result); 
//        if($count==1)
//        {
// $retrieve=mysqli_fetch_array($result);           
//        $result=$retrieve['']    
//     return $result;
//        }
//        else{
//            return " not record found";
//        }
//     }
//    else
//    {
//$qry = "SELECT * FROM `$table` WHERE $colum = '$reference'";
//$result = mysqli_query($con,$qry) or die(mysql_error());
//$count=mysqli_num_rows($result); 
//    if($count==1)
//     {
//     $retrieve=mysqli_fetch_array($result);           
//        $result=$retrieve[''] 
//        }
//        else{
//            return " not no record";
//        }
//     }        
//    }

$date='2017:06:07';
$date1='2017:07:07';$date3='2017:09:07';
if($date1 >$date and $date1 < $date3)
{
    echo "date1greateryeyey";
}
else
{
    echo"smaller";
}
//$date=date("Y:m:d");
//echo $date;
?>

