<?php
function del($table,$colum,$reference){
include('../dbcon/dbcon.php'); 
 if(!is_string($reference))
{   
$pqry = "SELECT * FROM `$table` WHERE $colum = $reference";
$presult = mysqli_query($con,$pqry) or die(mysql_error());
$pcount=mysqli_num_rows($presult); 
    if($pcount > 0)
     {
 $pdeletepricerecord = "DELETE FROM `$table` WHERE $colum = $reference";
$pdelquery = mysqli_query($con,$pdeletepricerecord) or die(mysql_error()); 
        if($pdelquery)
        {
         return "yes";
        }
        else{
            return "not";
        }
     }
     else{
         return "0record";
     }
 }
    else
    {
    $fqry = "SELECT * FROM `$table` WHERE $colum = '$reference'";
$fresult = mysqli_query($con,$fqry) or die(mysql_error());
$fcount=mysqli_num_rows($fresult); 
    if($fcount > 0)
     {
 $fdeletepricerecord = "DELETE FROM `$table` WHERE $colum = '$reference'";
$fdelquery = mysqli_query($con,$fdeletepricerecord) or die(mysql_error()); 
        if($fdelquery)
        {
         return "yes";
        }
        else{
            return "not";
        }
     }
     else{
         return "0record";
     }    
        
    }
}
?>