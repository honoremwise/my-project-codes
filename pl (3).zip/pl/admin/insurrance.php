<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Pharmacie Locator</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     
</head>
<body>
     <?php //include_once('../header.php');
    // <!-- HEADER END-->
    require('../dbcon/dbcon.php');
include("auth.php");
$message="";
if (isset($_REQUEST['save_drug'])){
        // removes backslashes
	$drug_name = stripslashes($_REQUEST['drug_name']);
        //escapes special characters in a string
	$drug_name = mysqli_real_escape_string($con,$drug_name); 
	$drug_price = stripslashes($_REQUEST['drug_price']);
	$drug_price = mysqli_real_escape_string($con,$drug_price);
	$exp_date = stripslashes($_REQUEST['exp_date']);
	$exp_date = mysqli_real_escape_string($con,$exp_date);
    $drug_description = stripslashes($_REQUEST['drug_descr']);
	$drug_description = mysqli_real_escape_string($con,$drug_description);
    $price_description = stripslashes($_REQUEST['price_description']);
	$price_description = mysqli_real_escape_string($con,$price_description);
$query = "INSERT into `drugs` (drug_name,experation_date,drug_description,price_decription,drug_price)
VALUES ('$drug_name','$exp_date','$drug_description', '$price_description','$drug_price')";
        $result = mysqli_query($con,$query);
        if($result){
            $message =" Drug recorded correctly!";
        }
    else
    {
    $message="drug not recorded!";
    }
    }

?>
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="assets/img/logo.png" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;">&nbsp;<?php echo $_SESSION['username']; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    
                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo $_SESSION['username']; ?> </h4>
                                        <h5><b><br>SYSTEM Administrator</b></h5>

                                    </div>
                                </div>
                              <center>
                                
                                <a href="logout.php" class="btn btn-primary btn-sm">My profile</a>&nbsp;
                                  <a href="logout.php" class="btn btn-danger btn-sm">Logout</a></center>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    
    <!-- MENU SECTION END--> 
<div class="content-wrapper">
        <div class="container">
            <div class="row">
            </div>
           
<!--            inserted row mine-->
            <div class="row">
    
<?php
    $messager="";
    if(isset($_POST['save_insurrance']))
    {
$insurrance=$_POST['insurrance'];
$Description=$_POST['insurrancedesc'];
$email=$_POST['email'];
 $picture =$_FILES['logo']['name'];
    $photo_size =$_FILES['logo']['size'];
$extensions =array('.png','.gif','.jpg','.jpeg','.JPEG','.JPG','.PNG');  
$extension =strrchr($_FILES['logo']['name'],'.'); 
$pictures=$_FILES['logo']['tmp_name'];
        if(!in_array($extension,$extensions))
{  
$messager="<i class='fa fa-info'>You must make use of file in the following forma type png, gif, jpg,jpeg</i>";
echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>";  
}  
 else if($photo_size>=50000000)
{
  $messager="<i class='fa fa-info'>The file size exceeds the allowed size, please upload a file not bigger than 5MB.</i>";
echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>";      
}
 else if(move_uploaded_file($pictures,'insurrances/'.$_FILES['logo']['name']))
{
  $d=date("Y:d:m");   
$queryins = "INSERT into `insurrence_companies` (company_name,company_logo,companydescirption,registration_date,companyemail)
VALUES ('$insurrance','$picture','$Description','$d','$email')";
        $resultin = mysqli_query($con,$queryins);
        if($resultin){

     $messager="<i class='fa fa-info'>Health inssurrance added successfully!</i>";
    echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>";
}
    else
    {
 $messager="<i class='fa fa-info'>Something is wrong with insertion...</i>";
echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>"; 
    
 
 }
}
        else
        $messager="<i class='fa fa-info'>Health insurrance can not be registered withouth a picture!</i>" ;  
    echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>";
    }
      $id="";
    $company_name="";
    if(isset($_GET['taskoption']))
{
$id=$_GET['taskoption'];
        //to retrieve data
 $selectinsux = "SELECT * FROM `insurrence_companies` WHERE insurrence_id = $id ";
$insuresultx = mysqli_query($con,$selectinsux) or die(mysql_error()); 
$line=mysqli_fetch_array($insuresultx);      
  $insurrence_id=$line['insurrence_id'];
    $company_name=$line['company_name'];
    $company_logo=$line['company_logo'];
    $companydescirption=$line['companydescirption'];
    $visibilitystatus=$line['visibilitystatus'];
    $companyemail=$line['companyemail'];       
} 
 if(isset($_POST['unpost']))
      {
       $idtohide=$id;
$unpostqry = "UPDATE `insurrence_companies` SET visibilitystatus = 'invalid' WHERE 	insurrence_id = $idtohide";
$chekunpostqry = mysqli_query($con,$unpostqry) or die(mysql_error()); 
if($chekunpostqry)
{
    echo "<center>{$company_name}access status hiden  successfully</center>";
     echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,3000);</script>";
}   
          
      }
    //repost
    if(isset($_POST['repost']))
      {
       $idtohide=$id;
$unpostqry = "UPDATE `insurrence_companies` SET visibilitystatus = 'valid' WHERE insurrence_id = $idtohide";
$chekunpostqry = mysqli_query($con,$unpostqry) or die(mysql_error()); 
if($chekunpostqry)
{
    echo "<center>{$company_name}access status hiden  successfully</center>";
     echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,3000);</script>";
}   
          
      }
    //to reflesh a page
if(isset($_POST['backstep']))
    {
echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>";
}
    //delete pharmacy
    if(isset($_POST['delbtn']))
    {
    //$id = $_GET['yesedit'];
   include('delfunction.php');     
$x=del('insurrence_companies','insurrence_id',$id);
$x;
if($x=='0record')
{
    echo"empty";
}
if($x=='yes')
{
echo"<center>data deleted</center>";
echo"<script>function redirect(){
window.location='insurrance.php';
}setInterval(redirect,1000);</script>";    
}
}
    //data management end
                   
                
                
                
                ?>
     <div class="modal fade" id="myModalload" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalLabel"><center><?php echo $company_name ?></center></h4></div><div class="modal-body">
     
<form role="form" method="post" action="#">
<div class="form-group has-primary">    
        <?php echo "<img src='insurrances/{$company_logo}'style='width:100px; height:70px;'/>";?>
    <br>
 <label>Company Name:</label>
    <input type="text" name="pharmacy" class="form-control" value="<?php echo $company_name;?>" > 
 <label>Company Email addresse:</label>
    <input type="text"  class="form-control" value="<?php echo $companyemail;?>" >  
    <label>Description:</label>
    <input type="text" class="form-control" value="<?php echo $companydescirption;?>" >
      </div>  
 <div class="modal-footer">
<center><input type="submit" class="btn btn-default" name="unpost" value="HIDE">
    <input type="submit" class="btn btn-default" name="repost" value="REPOST">
<!--<input type="submit" class="btn btn-default" name="revoke" value="REVOKE"><input type="submit" class="btn btn-default" name="regrant" value="REGRANT"> -->
    <input type="submit" class="btn btn-default" name="delbtn" value="DELETE">
    <input type="submit" class="btn btn-default" name="backstep" value="CANCEL">
     </center>
                                   </div>
    </form>
        </div></div>
</div>
</div>
                
                
                <div class="row">
  <div class="col-md-12">
    <div class="col-md-6">
    <div class="modal-content">
        <div class="modal-header">
<h4 class="modal-title" id="myModalLabel"><center>Record Health Insurrance Company</center></h4>
        </div><div class="modal-body">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
<form role="form" method="post" action="?" enctype="multipart/form-data">
<div class="form-group has-primary">  
<label>Insurrance Logo:</label>
    <input type="file" name="logo" class="form-control" placeholder="price drug" required>  
    <label>Insurrance Name:</label>
    <input type="text" name="insurrance" class="form-control" placeholder="Eg RSSB " required>       
       
    <label>Description:</label>
    <input type="text" name="insurrancedesc" class="form-control" placeholder="your health protection is our focus" required>  
    <label>Email contact:</label>
    <input type="email" name="email" class="form-control" placeholder="your health protection is our focus" required>  
   
    </div>
<div class="modal-footer">
    <center>
<button type="submit" class="btn btn-primary" name="save_insurrance">SAVE </button></center>
                                        </div>
    </form>
        </div></div></div>  <div class="col-md-6">
    <div class="modal-content"><div class="modal-header">
<!--<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>-->
<h4 class="modal-title" id="myModalLabel"><center>Health Insurrance Companies</center></h4></div><div class="modal-body">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
 <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Insurrance Logo</th>
                                            <th>Name</th>
                                            <th>Advert Status</th> 
                                            <th>Option</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
$selectinsu = "SELECT * FROM `insurrence_companies`";
$insuresult = mysqli_query($con,$selectinsu) or die(mysql_error()); 
while($line=mysqli_fetch_array($insuresult))
{
    $insurrence_id=$line['insurrence_id'];
    $company_name=$line['company_name'];
    $company_logo=$line['company_logo'];
    $companydescirption=$line['companydescirption'];
    $visibilitystatus=$line['visibilitystatus'];
    $user_email=$line['companyemail'];
    echo" <tr><td><img src='insurrances/{$company_logo}'style='width:100px; height:70px;'/></td><td>$company_name</td><td>$visibilitystatus</td>
    <td><a href='insurrance.php?taskoption={$line['insurrence_id']}'class='btn btn-default' title='Edit details'><i class='fa fa-tasks'></i></a></td>  
    </tr>";
} 
                                         if(isset($_GET['taskoption']))
                                      
{
 $s=$_GET['taskoption'];
$selectinsuxy = "SELECT * FROM `insurrence_companies` WHERE insurrence_id = $s ";                $insuresultxy = mysqli_query($con,$selectinsuxy) or die(mysql_error()); 
$read=mysqli_fetch_array($insuresultxy);
    $name=$read['company_name'];
   echo"<center><k style='font-size:1.2em;color:red'>You have choosen&nbsp;{$name} Do you want to continue with this record&nbsp;?</k><i class='fa fa-check' data-toggle='modal' data-target='#myModalload'> &nbsp; or &nbsp;<a href='insurrance.php'><k style='font-size:1.2em;color:red' class='fa fa-times'></k></a></i></center>";
} 
?>
</tbody>
</table>
            </div></div>
                    </div></div>
                    
            </div> 
            </div>
            
    </div>
               <!--          end  inserted row mine-->
              </div>
   
      
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include_once('../footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
