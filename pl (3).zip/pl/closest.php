<!DOCTYPE html>
<html>
<head>
<title>PHARMACY LOCATOR</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script src="js/simpleCart.min.js"> </script>	
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body onload="getLocation()">
    <?php require('dbcon/dbcon.php');?>
    
    <!-- header-section-starts -->
	<div class="header">
		<div class="menu-bar">
			<div class="container">
				<div class="login-section">
					<ul>
						<li><a class="active" href="index.php">Home</a>  </li>|
                        <li><a href="register.php">Register</a> </li> |
                        <li><a href="login.php">Login</a>  </li> |
						
						<li><a href="#">Help</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="banner wow fadeInUp" id="Home">
		    <div class="container">
				<div class="banner-info">
					<div class="banner-info-head text-center wow fadeInLeft" data-wow-delay="0.5s">
						<h1><i class="fa fa-paper-plane-o fa-1x"></i>&nbsp;&nbsp;Welcome To Pharmacy Locator</h1>
						<div class="line">
							
						</div>
					</div>
					<div class="form-list wow fadeInRight">
                        <center>
<!--                            searching field-->
						 <form action="#" method="post">
	          <input type="search" placeholder="filter pharmacies by place eg:huye " class="text" style="width:50%;"/>
	            <button type="submit" name="searchbyplace" class="btn btn-default btn-lg"><i class="fa fa-search" style="font-size:100%;color:red;"></i></button>&nbsp;&nbsp;
	        </form>
                  </center>
						</div>					
				</div>
			</div>
		</div>
	</div>
	<div class="popular-restaurents" id="Popular-Restaurants">
			<div class="container">
				<h3><center>Pharmacies Closer To you</center></h3><br>
				<div class="col-md-12 top-cuisines wow bounceIn" data-wow-delay="0.4s">

<!--                 closest pharmacies   -->
                </div>
    <div class="col-md-12 top-cuisines wow bounceIn" data-wow-delay="0.4s" > 
<?php
        $latitude="";$longitude="";
                         					//</div>"; }}
 if(isset($_POST['checklglat']))
        {
$latlong=$_POST['latlong'];
 $lt=""; $lg=""; 
error_reporting(0); 
$latlong=explode(',',$_POST['latlong']);
$lt=$latlong[0]; $lg=$latlong[1];          
$sqlfordistance="SELECT * FROM pharmacies,pharmacy_branches WHERE pharmacy_branches.pharmacyid = pharmacies.pharmacy_id";
            $sqldist=mysqli_query($con,$sqlfordistance);
        while($rec=mysqli_fetch_array($sqldist))
        {
            $branchid=$rec['branchid'];
            $pharmacyid=$rec['pharmacyid'];
            $tel_contact_no=$rec['tel_contact_no'];
            $latitudefromtb=$rec['latitude'];
            $longitudefromtb=$rec['longitude'];
            $branch_site_image=$rec['branch_site_image'];
            $service_start_time=$rec['service_start_time'];
            $service_end_time=$rec['service_end_time'];
            $working_day_info=$rec['working_day_info'];
            $pharmacy_name=$rec['pharmacy_name'];
            $pharmacy_logo=$rec['pharmacy_logo'];
            $pharmacy_link=$rec['pharmacy_link'];
            $email=$rec['pharmacy_email'];
            $province=$rec['province'];
            $branch_district=$rec['branch_district'];        
  function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  $theta = $lon1 - $lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);
  if ($unit == "K") {
    return ($miles * 1.609344);
  } else if ($unit == "N") {
      return ($miles * 0.8684);
    }
      else if ($unit == "M") {
      return ($miles * 1609.34);
    } else {
        return $miles;
      }
}
echo"<form><div class='col-md-6 top-cuisine-grids'>
					<div class='offer'>
								<div class='offer-image'>	
				<img src='../users/logoes/{$pharmacy_logo}'class='img-responsive' alt='$pharmacy_name' style='width:100%px;'/>    
								</div>
								<div class='offer-text'>
						<h4>".strtoupper($pharmacy_name)." PHARMACY($branch_district)</h4>
<p class='fa fa-tasks'><b><u> SERVICE SCHEDULE</u></b></p>
                                    
<p class='fa fa-clock-o'>&nbsp;$service_start_time AM  To &nbsp;$service_end_time PM, </p><br>
<p class='fa fa-calendar'>&nbsp;$working_day_info</p>
<br>
<p class='fa fa-mobile'>&nbsp;$tel_contact_no</p>
<br>
<p class='fa fa-envelope'>&nbsp;$email</p>
<br>
<p class='fa fa-globe'>&nbsp;<a href='$pharmacy_link'>$pharmacy_link</a></p>
                                    <p>
<p class='fa fa-road'>&nbsp;".distance($lt,$lg,$latitudefromtb,$longitudefromtb, "M")."&nbsp;Meters</p><p> FROM HERE "."</p>
 <a href='fulldetails.php?fullinfos={$rec['branchid']}' title='viw more about this Pharmacy'>
 <input type='button' value='view...'></a>
									<span></span>
								</div>
								<div class='clearfix'></div>
							</div>
                       
                         					</div></form>"; 
        }
        
        
        
        
            
            
        } 
       
        ?>

				</div>
				<div class="clearfix"></div>
			</div>
		</div>
<!--  getting coordinates-->
    <script>
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.value = position.coords.latitude + 
    "," + position.coords.longitude;
}
</script>
<!--    end-->
			<div class="service-section">
			<div class="service-section-top-row">
				<div class="service-section-bottom-row">
				<div class="container">
                   <?php
                    echo "what";
 $sld="SELECT * FROM `insurrence_companies`";
  $inqueryd=mysql_query($sld);
   $insucounterd=mysql_num_rows($inqueryd);
  if($insucounterd > 0)
  {
   echo"<div class='col-md-3 service-section-bottom-grid wow bounceIn' data-wow-delay='0.2s'>
						<div class='icon'>
							<img src='images/icon1.jpg' class='img-responsive' alt=''/>
						</div>
						<div class='icon-data'>
							<h4>SAHAM</h4>
							<p>EX Corar health insurrance ,view closest pharmacies... </p>
						</div>
						<div class='clearfix'></div>
					</div>";   
  }?>
  
					<div class="clearfix"></div>
				</div>
			</div>
        </div>
    </div>
		
		<?php include_once('footer.html')?>

</body>
</html>