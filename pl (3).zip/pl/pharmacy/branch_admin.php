<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Pharmacie Locator</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     
</head>
<body>
    <?php require('../dbcon/dbcon.php');
include("auth.php");?>
    <?php
    $dates="";
    $user=$_SESSION['username'];
    $pharmacy_name="";$pharmacy_service_tel="";
    $pharmacy_logo="";$pharmacy_authorization_identication="";
    $pharmacy_link="";$reg_date="";
    $pharmacy_email="";$pharmacy_id="";
 $userqry="SELECT * FROM users where username='$user'";                              
$out=mysqli_query($con,$userqry) or die(mysqli_error());
  $line=mysqli_fetch_array($out);
  $userid=$line['userid'];                                                
  // getting pharmacy data                             
$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$rows=mysqli_num_rows($result);
$rec=mysqli_fetch_array($result);
  $pharmacy_id=$rec['pharmacy_id'];  
 $pharmacy_name=$rec['pharmacy_name'];
 $pharmacy_logo=$rec['pharmacy_logo'];
 $pharmacy_link=$rec['pharmacy_link'];
 $pharmacy_email=$rec['pharmacy_email'];
 $pharmacy_service_tel=$rec['pharmacy_service_tel'];
 $pharmacy_authorization_identication=$rec['pharmacy_authorization_identication'];
 $reg_date=$rec['reg_date'];
     ?>
     
     <?php //include_once('../header.php');
    
   // <!-- HEADER END-->
    
$message="";
//if (isset($_REQUEST['save_drug'])){
//        // removes backslashes
//	$drug_name = stripslashes($_REQUEST['drug_name']);
//        //escapes special characters in a string
//	$drug_name = mysqli_real_escape_string($con,$drug_name); 
//	$drug_price = stripslashes($_REQUEST['drug_price']);
//	$drug_price = mysqli_real_escape_string($con,$drug_price);
//	$exp_date = stripslashes($_REQUEST['exp_date']);
//	$exp_date = mysqli_real_escape_string($con,$exp_date);
//    $drug_description = stripslashes($_REQUEST['drug_descr']);
//	$drug_description = mysqli_real_escape_string($con,$drug_description);
//    $price_description = stripslashes($_REQUEST['price_description']);
//	$price_description = mysqli_real_escape_string($con,$price_description);
//$query = "INSERT into `drugs` (drug_name,experation_date,drug_description,price_decription,drug_price)
//VALUES ('$drug_name','$exp_date','$drug_description', '$price_description','$drug_price')";
//        $result = mysqli_query($con,$query);
//        if($result){
//            $message =" Drug recorded correctly!";
//        }
//    else
//    {
//    $message="drug not recorded!";
//    }
//    }

?>
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="assets/img/logo.png" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;"><?php echo $_SESSION['username']; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <div class="media-body">
                                        <h4 class="media-heading">User:<?php echo"<b>".ucfirst($_SESSION['username'])."</b>"; ?> </h4>
                                        <h5>Pharmacy owner</h5>

                                    </div>
                                </div>
                                <hr />
                                
                                <a href="#" class="btn btn-info btn-sm"><k data-toggle="modal" data-target="#myModalbranch">
                          Full Profil 
                            </k></a>&nbsp; <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    
    <!-- MENU SECTION END--> 
<div class="content-wrapper">
        <div class="container">
            <div class="row">
            </div>
            <div class="row">
<div class="col-md-12">
                    
  <div class="col-md-2">                   <!--new drugs  Modal-->        
</div>  
                 
                           <div class="col-md-2">
<!--                           saving branch into the database -->                                           
                         <div class="panel-body">
 <div class="modal fade" id="myModalbranch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel">MY PERSONAL INFORMATION</h4>
                                        </div>
                                        <div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
 <label>Branch Service tel_contact:</label>
    <input type="text" name="telcontact" class="form-control" placeholder="service telephone number" required>       
   
    <label>Branch District name:</label>
    <input type="text" name="district" class="form-control" placeholder="district where is located" required>
    <label>Branch sector name:</label>
    <input type="text" name="sector" class="form-control" placeholder="sector where it is located" required>
    <label>Branch cell:</label>
    <input type="text" name="cell"class="form-control" placeholder="cell where it is located" required>
           
                     
    </div>

                                    
                                        <div class="modal-footer">
 <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" name="savebranch" class="btn btn-primary">Save Branch</button>
                                            
                                        </div>
                                                                </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div>
                     </div>
    <div class="col-md-2">
        <div class="panel-body">                   
        <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModals">
                         Bill Management
                            </button>
                            <div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModalLabel"><center>....</center></h4>
                                        </div>
                                        <div class="modal-body">
                                                     <form role="form">
<div class="form-group has-success">
    <label>Bill id</label><br>
    <label>Buyer tel</label>
    <label>Date</label><br><label>item id</label><label>name</label><label>price</label><label>Quantity</label>
        
    <br>
    
    </div>

                                    
                                        <div class="modal-footer">
<center><button type="submit" name="assign" class="btn btn-lg btn-default ">
Print bill
                                </button></center>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div>
                     </div> 
                     
    <div class="col-md-2">
        <div class="panel-body">
    <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#mystore">
                        Access Management 
                            </button>
                            <div class="modal fade" id="mystore" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Main Store Status and Branch drug Store status</h4>
                                        </div>
                                        <div class="modal-body">
                                              <form role="form">
<div class="form-group has-success">
        
<label>Bill Id:</label>
    <input type="text" name="bill_id"class="form-control" placeholder="bill_id of the sold items ">    
    <br>
     <center> 

    <span class="col-lg-4  input-group custom-search-form">

<span class="input-group-btn">
<button type="submit" name="save_return" class="btn btn-lg btn-success btn-block">
Record Return
                                </button>
    
                            </span>
                        </span></center>
    </div>

 </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <!-- End returns model  -->
                </div>
                </div>
            </div>
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                         <div class="modal-content"><div class="modal-header">
<h4 class="modal-title" id="myModalinsurrance"><center>Drug Management Panel</center></h4></div><div class="modal-body">
                            <form role="form">
<div class="form-group has-success">
    <label>Select Drug</label>
    <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>
      
<label>Check price</label>
    <input type="text" name="search_place_field"class="form-control" placeholder="number of items"> 
<label>Quantity</label>
  <input type="text" name="search_place_field"class="form-control" placeholder="number of items">
     <label>Attach a bill</label>
    <select name="search_place_field"class="form-control">
        <option>bill#456</option>
        <option>bill#456</option><option>bill#456</option>
    </select>
    
    <br>
    
    </div>

                                    
                                        <div class="modal-footer">
<center><button type="submit" name="assign" class="btn btn-lg btn-default ">
Record sale
                                </button></center>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                        </div> 
                    <div class="col-md-2"></div>
            </div> 
            </div>
            
    </div>
               <!--          end  inserted row mine-->
             
    </div>

      
    <!-- CONTENT-WRAPPER SECTION END-->
   <center> <?php include_once('../footer.php');?></center>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
