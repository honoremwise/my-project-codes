<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Pharmacie Locator</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />     
</head>
<body onload="getLocation()">
    <section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
<ul id="menu-top" class="nav navbar-nav navbar-right">
<li><a class="menu-top-active" href="home.php">Home</a></li>
    <li><a href="sales_report.php">Sales</a>
      </li>
    <li><a href="logout.php">Logout </a></li>
    <li><a href="blank.php">Help</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    
    <?php require('../dbcon/dbcon.php');
include("auth.php");?>
    <?php
    $dates="";
    $user=$_SESSION['username'];
    $userid="";
    $pharmacy_id="";
 $userqry="SELECT * FROM users where username='$user'";                              
$out=mysqli_query($con,$userqry) or die(mysqli_error());
  $line=mysqli_fetch_array($out);
  $userid=$line['userid'];
  $firstname=$line['firstname'];
    $lastname=$line['lastname'];
    $telephone=$line['telephone'];
    $user_email=$line['user_email'];
    $reg_date=$line['reg_date'];
    $username=$line['username'];
    // getting pharmacy data                             
$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$rows=mysqli_num_rows($result);
$rec=mysqli_fetch_array($result);
  $pharmacy_id=$rec['pharmacy_id'];  
 $pharmacy_name=$rec['pharmacy_name'];
 $pharmacy_logo=$rec['pharmacy_logo'];
 $pharmacy_link=$rec['pharmacy_link'];
 $pharmacy_email=$rec['pharmacy_email'];
 $pharmacy_service_tel=$rec['pharmacy_service_tel'];
 $pharmacy_authorization_identication=$rec['pharmacy_authorization_identication'];
 $reg_date=$rec['reg_date'];
$message="";
if (isset($_REQUEST['save_drug'])){
        // removes backslashes
	$drug_name = stripslashes($_REQUEST['drug_name']);
        //escapes special characters in a string
	$drug_name = mysqli_real_escape_string($con,$drug_name); 
	$drug_price = stripslashes($_REQUEST['drug_price']);
	$drug_price = mysqli_real_escape_string($con,$drug_price);
	$exp_date = stripslashes($_REQUEST['exp_date']);
	$exp_date = mysqli_real_escape_string($con,$exp_date);
    $price_description = stripslashes($_REQUEST['desc']);
	$price_description = mysqli_real_escape_string($con,$price_description);
    $quantity = stripslashes($_REQUEST['quantity']);
	$quantity = mysqli_real_escape_string($con,$quantity);
    $dates= date("Y-m-d");
$query = "INSERT into `pharmacy_drugs` (drug_names,pricing_description,pharmacy_id,recording_date,exp_date,quantity)
VALUES ('$drug_name','$price_description','$pharmacy_id','$dates','$exp_date','$quantity')";
        $resultsave = mysqli_query($con,$query);
        if($resultsave){
            $message =" Drug recorded correctly!";
            echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";
            
        }
    else
    {
    $message="drug not recorded!";
    }
    }
//if(isset($_POST['edpersonal']))
//{
   // echo "wow";
//$edfname=$_POST['edfname'];
//$edlname=$_POST['edlname'];
//$edtel=$_POST['edtel'];
//$edemail=$_POST['edemail'];
//$eduser=$_POST['eduser'] 
//$pers_updateqry = "UPDATE `users` SET firstname = '$edfname', lastname='$edlname' ,telephone = '$edtel' ,username= '$eduser'  WHERE userid = $userid";
//$chekpersonalup = mysqli_query($con,$pers_updateqry) or die(mysql_error()); 
//if($chekpersonalup)
//{
//    echo "<center>Personal Successfully changed</center>";
//     echo"<script>function redirect(){
//window.location='home.php';
//}setInterval(redirect,3000);</script>";
//}           
//}
?>
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">
                   <img src="assets/img/logo.png" />
                </a>
           </div>
           <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">
                       <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;">&nbsp;<?php echo $_SESSION['username'];?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <div class="media-body">
                                        <h4 class="media-heading">User:<?php echo"<b>".ucfirst($_SESSION['username'])."</b>";?> </h4>
                                        <h5>Pharmacy Manager</h5>
                                    </div>
                                </div>
                                <hr />
<a href="#" class="btn btn-info btn-sm"><k data-toggle="modal" data-target="#myprofil">
                        Full Profile
</k></a>&nbsp; <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    
    <!-- MENU SECTION END--> 
<div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
<div class="modal-content"><div class="modal-header">
<!--
<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModaltask">
Tasks </button>
-->
</div><div class="modal-body">
<form role="form" method="post">
<?php 
   //getting the user id
  
// echo"<i class='fa fa-warning fa-2x' style='color:red'></i>Drugs are about to Reach expiration date
// ";
//echo"<i class='fa fa-flask fa-3x' style='color:red'></i>5 Drugs about to finish in the Main store 
// <br>"; 
//        echo"<center><i class='fa fa-info' style=''></i>View More.. 
// </center>"; 
?>

                                   
                                       
     </form>
                                      
                                    </div>
            </div>
           <!--user name update model begin                    -->         
<div class="modal fade" id="changemyPorfile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="changemyPorfile"><center>Navigation Model</center></h4></div><div class="modal-body">

     <button class="btn btn-default" data-toggle="modal" data-target="#newemployee">
                       Employee</button>
    
                                        </div>
                                    </div>
                                </div>
                            </div> 
<!--user name update model end                    -->
<!-- tasks model begin                   -->          
 <div class="modal fade" id="myModaltask" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModaltask"><center>Record New Drugssssd</center></h4></div><div class="modal-body">

     <button class="btn btn-default" data-toggle="modal" data-target="#newemployee">
                       Employee</button>
   
    <button class="btn btn-info " data-toggle="modal" data-target="#myModals">
                            Allocations   </button>
    
<button class="btn btn-info " data-toggle="modal" data-target="#myModalbranch">
                       My  Branches </button>

<button class="btn btn-info " data-toggle="modal" data-target="#myModaladd">
                            Add Drug </button>
 <button class="btn btn-info" data-toggle="modal" data-target="#myModalinsurrance">
                           Insurrance </button>
 <button class="btn btn-default" data-toggle="modal" data-target="#myModaltask">
 Tasks </button>
    <button class="btn btn-default" data-toggle="modal" data-target="#mystore">
                     Drug store 
                            </button>  
        
   <button class="btn btn-default" data-toggle="modal" data-target="#mypharmacyprofil">
                            Profil </button> 
                                        </div>
                                    </div>
                                </div>
                            </div>                    
<!--tasks model end            -->
<!--            full profil model begin-->
            
            <div class="modal fade" id="mypharmacyprofil" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="mypharmacyprofil"><?php echo "<b><center>".$pharmacy_name."</center></b>";?></h4></div><div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
   <?php 
   //getting the user id
  
 echo"<center>
 <img src='../users/logoes/{$pharmacy_logo}' style='width:120px;height:100px;'/></center><br>
 
 &nbsp;&nbsp;Pharmacy Email<b>:$pharmacy_email</b><br>
&nbsp;&nbsp;Pharmacy Tel<b>:$pharmacy_service_tel</b><br>
 &nbsp;&nbsp;Pharmacy Identification NO<b>:$pharmacy_authorization_identication</b><br>
&nbsp;&nbsp; Sign Up  Date<b>: $reg_date</b>
 " 
?> 
   
    
    <br>
    
    </div>

                                   
                                        <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<!--                                            <button type="Submit" class="btn btn-primary">Save Company</button>-->
                                        <?php echo"<a href='index.php?edit={$userid}'class='btn btn-default'><i class='fa fa-edit'></i></a>"?>
                                            
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--            full profile model end-->
<!--            store status model begin-->
    <div class="modal fade" id="mystore" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel"><center>Drug  Store Info </center></h4>
                                        </div>
 <div class="modal-body">
<div class="modal-body">
<div class="table-responsive">
<table class="table table-hover">
                                    <thead>
                                                     <?php  
$pharmacydrugs="SELECT * 
FROM  `pharmacy_drugs` WHERE pharmacy_id='$pharmacy_id'";
$pharmacydrugsqry=mysqli_query($con,$pharmacydrugs);
$pharmacydrugcount=mysqli_num_rows($pharmacydrugsqry);    
if($pharmacydrugcount > 0)
{?>
  <?php                                                  
  echo'<tr><th>Drug</th><th>Pricing</th><th>Experation info</th><th>Quantity</th><th>Option</th>
</tr>
                                             
';?>
  </thead>
                                    <tbody> 
<form role="form" method="post" >                                        
     <?php
while($drow=mysqli_fetch_array($pharmacydrugsqry))
   {
$drug_id=$drow["drug_id"];
$drug_names=$drow["drug_names"];
$pricing_description=$drow["pricing_description"];
$recording_date=$drow["recording_date"];
$exp_date=$drow["exp_date"];
$info_status=$drow["info_status"];
$quantity=$drow["quantity"];
echo" <tr>
<td>$drug_names</td>
<td>$pricing_description</td>
<td>$exp_date</td><td>$quantity</td>
<td>
<a href='branch_info.php?viewmore={$drow["drug_id"]}'class='btn btn-info btn-sm' title='view more info'><i class='fa fa-info'>&nbsp;</i></a>|<a href='branch_info.php?update={$drow["drug_id"]}'class='btn btn-info btn-sm' title='Employee info'><i class='fa fa-edit'>&nbsp;&nbsp;</i></a>&nbsp;&nbsp;||&nbsp;<a href='branch_info.php?deletedrug={$drow["drug_id"]}'class='btn btn-danger btn-sm' title='Employee info'><i class='fa fa-trash'>&nbsp;&nbsp;</i></a>
</td>
</tr>";    
     
   }}
    else
    {
        echo"<center> data avaible </center>";
    }
     
    ?>
<div class="form-group has-success">

     
   </div>
</form>
   
          </tbody>
                                </table>                 
                                        
                                       
                                    
                            </div></div>
                                        </div>
                                        <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button class="fa fa-book btn btn-info" data-toggle="modal" data-target="#myModaladd" title="Report">Report
                             </button>
                                        </div>
                                    </div>
                                </div>
                            </div>        
<!--            store status infos model end-->
<!--            model for publishing insurrance company begin-->
                    <?php
                      if(isset($_POST['saveins']))
    {
    $insurrance=$_POST['insurrance'];
   $dates=date("Y:m:d");    
    $dispacher=array();
    $insurrance=explode('.',$insurrance);
    $neededid=$insurrance[0]; 
                          echo $neededid;
    $insinsert="INSERT INTO insurrence_companies_pharmacies (insurrence_company_id,pharmacy_id,date_recorded) VALUES ('$neededid',' $pharmacy_id','$dates')";    
     $inresult = mysqli_query($con,$insinsert)or die(mysqli_error());    
    if($inresult)
    { 
echo "<center>querry ok</center>";
    echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";                   
  }
                          else{
                              $x=mysql_error();
                            echo "<center>{$x}</center>";
    echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";   
                          }
                      }
                          
                    ?>
                    
                    
   <div class="modal fade" id="myModalinsurrance" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalinsurrance">Record Insurrence companies in partinership</h4></div><div class="modal-body">
<form role="form" method="post" action="#">
<div class="form-group has-success">
    
    
    

     <?php  
$insurrance="";
$sqlin="SELECT * FROM  `insurrence_companies`";
$insquery=mysqli_query($con,$sqlin);
if($insquery)
{
while($insrow=mysqli_fetch_array($insquery))
   {
$insurrence_id=$insrow["insurrence_id"];
$company_name=$insrow["company_name"];
$insurrance.='<option>'.$insurrence_id.".".$company_name.'</option>';
     
   }}
        ?>
     
     
<!--    $drug_name=$_POST['drug_name'];-->
    
     
     
 <label>Select Insurrence Company</label>
    <select type="text" name="insurrance" class="form-control" required>
    <option></option>
        <option><?php echo $insurrance; ?></option>
    
    </select>      
    
    <br>
        </div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="Submit" class="btn btn-primary" name="saveins">Save Company</button>
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>         
<!--    publish insurrance companies end        -->
<!--            model to add new drgs begin-->
 <div class="modal fade" id="myModaladd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModaladd"><center>Record New Drugs</center></h4></div><div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
 <label>Drug Name:</label>
    <input type="text" name="drug_name" class="form-control" placeholder="bill_id of the sold items " required>       
   
    <label>Drug price:</label>
    <input type="text" name="drug_price" class="form-control" placeholder="price drug" required>
    <label>Pricing description:</label>
       <select class="form-control" name="desc" required>
    <option>per unity</option>
    <option>combined</option>
    </select>
    <label>Experation Date:</label>
    <input type="date" name="exp_date" class="form-control" placeholder="expiration date " required>  
    <label>Quantity:</label>
    <input type="number" name="quantity" class="form-control" placeholder="quantity" required>     
    </div>
               
                                        <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit"  name="save_drug" class="btn btn-primary">Save changes</button>
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>           
<!--    add drugs into the data base        -->
<!--            codes for creating a new branch-->
            <!--                           saving branch into the database -->
<?php
$m="";                                                      
if(isset($_POST['savebranch']))
{
$lt=""; $lg=""; error_reporting(0); 
$latlong=explode(',',$_POST['latlong']);
$lt=$latlong[0]; $lg=$latlong[1];
echo 'lati'.$lt.'<br />';
echo 'long'.$lg.'<br />';
$pharmacycounter= "SELECT * FROM `pharmacy_branches` WHERE pharmacyid = $pharmacy_id";
$sqlpharmacies=mysqli_query($con,$pharmacycounter)or die(mysqli_error());
$counter=mysqli_num_rows($sqlpharmacies);    
$dates=date('Y-m-d');    
$telcontact=$_POST['telcontact'];
$province=$_POST['province'];    
$district=$_POST['district'];
$sector=$_POST['sector'];
$cell=$_POST['cell'];
$village=$_POST['village'];
$servicestarttime=$_POST['starttime'];
$serviceendtime=$_POST['endtime'];
$daysinfo=$_POST['daysinfo'];
 $a=$province[0].$province[1];
 $b=$district[0].$district[1];
 $c=$sector[0].$sector[1];
$d=$village[0].$village[1];
$branchid=$a.$b.$c.$d._.$counter._.$pharmacy_id;
    $m=$branchid;    
$branchimage_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
    
for($i = 0 ;$i < count($tmp_name_array); $i++){ if(move_uploaded_file($tmp_name_array[$i],"branchimages_uploads/".$branchimage_array[$i])){
    echo $branchimage_array[$i]."is uploaded successfully ";

}
                                            else{
echo "Data not saved and uploading".$branchimage_array[$i]."failed<br>";
                                            }
                                           }
    echo $branchid."<br>".$telcontact."<br>".$province.$dates."<br>".$branchimage_array[3];
    
  $binserts="INSERT  into `pharmacy_branches`
(branchid,pharmacyid,tel_contact_no,province,branch_district,branch_sector,branch_cell,branch_village,latitude,longitude,establishement_date,branch_site_image,closest_common_known_place,rightclosestplace,leftclosestplace,service_start_time,service_end_time,working_day_info) 
VALUES
('$branchid','$pharmacy_id','$telcontact','$province','$district','$sector','$cell','$village','$lt','$lg','$dates','$branchimage_array[0]','$branchimage_array[1]','$branchimage_array[2]','$branchimage_array[3]','$servicestarttime','$serviceendtime','$daysinfo')";
    $bresult = mysqli_query($con,$binserts)or die(mysqli_error());    
    if($bresult)
    {
        echo "<i class='fa fa-info' style='color:red;'>Branch is created</i>";
        echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";
    }
    else
        $m="error";                                   
}
                                
                               ?>
                          <?php echo"<font color='red'><center><b>".$m."</b></center></font>";?>  
            
<!--            new branch model-->
            <div class="modal fade" id="myModalbranch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Create a new branch </h4>
                                        </div>
                                        <div class="modal-body">
<form role="form" method="post" enctype="multipart/form-data">
<div class="form-group has-success">
   
 <label>Branch Service tel_contact:</label>
    <input type="text" name="telcontact" class="form-control" placeholder="service telephone number" required>       
   
    <label>Province:</label>
    <input type="text" name="province" class="form-control" placeholder="district where is located" required>
    <label>Branch District name:</label>
    <input type="text" name="district" class="form-control" placeholder="district where is located" required>
    <label>Branch sector name:</label>
    <input type="text" name="sector" class="form-control" placeholder="sector where it is located" required>
    <label>Branch cell:</label>
    <input type="text" name="cell"class="form-control" placeholder="cell where it is located" required>
    <label>Branch village:</label>
    <input type="text" name="village"class="form-control" placeholder="cell where it is located" required>
     <label>A Branch working site Image:</label>
    <input type="file" name="file_array[]" class="form-control" placeholder="cell where it is located" required>
    <label>The Closest Common Known place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Right side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Left side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Service  Time</label>
 <label>Start</label>   
 <input type="time" name="starttime"class="form-control" placeholder="cell where it is located" required>
 <label>End Time</label>
    <input type="time" name="endtime"class="form-control" placeholder="cell where it is located" required> 
    <label>Working days</label>
    <input type="text" name="daysinfo"class="form-control" placeholder="eg: monday up friday" required>
    <label>Geographical coordinates on google map(latitude and longitude) </label>       
     <input type="text" name="latlong" id="demo" value="" class="form-control">                
    </div>

                                    
                                        <div class="modal-footer">
 <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" name="savebranch" class="btn btn-primary">Save Branch</button>
                                            
                                        </div>
                                                                </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--            new branch model-->
<!--            drug assignment model-->
              <div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModalLabel">Assign Drugs to Branches</h4>
                                        </div>
                                        <div class="modal-body">
                                                     <form role="form">
<div class="form-group has-success">
    <label>Drug ID</label>
    <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>
    
<label>Quantity</label>
    <input type="text" name="search_place_field"class="form-control" placeholder="number of items"> 
    <label>Destination Branch</label>
   <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>   
    <br>
    
    </div>

                                    
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           <button type="submit" name="assign" class="btn btn-lg btn-primary ">
Assign drugs
                                </button>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--            drug assignment-->
<!--            php codes for add employee-->
            <?php 
if(isset($_POST['save_employee']))
  {
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$password=$_POST['password'];
$email=$_POST['email'];
$emptel=$_POST['emptel'];
$assbranch=$_POST['assbranch'];
$username=$_POST['username'];
$workeridno=$_POST['workeridno']; 
    $branchiassigned=array();
    $branchiassigned=explode('.',$assbranch);
    $branchid=$branchiassigned[0];
    
    
$bwinsert="INSERT INTO branch_workers (worker_first_name,worker_last_name,worker_id_no,username,worker_password,workers_email,worker_tel,data_of_employement,branch_id)VALUES('$fname','$lname','$workeridno','$username','$password','$email','$emptel','$dates','$branchid')";
$bwresult = mysqli_query($con,$bwinsert)or die(mysqli_error()); 
  if($bwresult) 
  {
   echo "<i class='fa fa-info' style='color:red;'>Employee was added</i>";
        echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";   
  }
}
                         
?>
            
<!--            add employee model-->
             <div class="modal fade" id="newemployee" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalLabel">Add an Employee To a branch</h4>
</div><div class="modal-body">
<form role="form" method="post" >
<div class="form-group has-success">
 <label>Branch Employee First name:</label>
    <input type="text" name="fname"class="form-control" placeholder="branch worker firstname " required> 
    <label>Branch Employee Last name:</label>
    <input type="text" name="lname"class="form-control" placeholder="branch worker last name" required> 
    <label>Employee Id no:</label>
    <input type="text" name="workeridno"class="form-control" placeholder="branch worker last name" maxlength="16" required>   
    <label>Branch Employee username:</label>
    <input type="text" name="username"class="form-control" placeholder="branch worker last name" required> 
    <label>Branch Employee password:</label>
    <input type="text" name="password"class="form-control" placeholder="branch worker last name" required> 
    <label>Branch Employee email:</label>
    <input type="text" name="email"class="form-control" placeholder=" worker email" required>
    <label>Branch Employee tel:</label>
    <input type="text" name="emptel"class="form-control" placeholder=" worker tel" required>
    <label>Assign Branch:</label>
<!--    retrieving braches-->
<select type="text" name="assbranch"class="form-control" placeholder="branch worker last name" required>
<?php  
$branch="";
$sql="SELECT * 
FROM  `pharmacy_branches` WHERE pharmacyid='$pharmacy_id'";
$branchquery=mysqli_query($con,$sql);
if($branchquery)
{
while($row=mysqli_fetch_array($branchquery))
   {
$branchid=$row["branchid"];
$branch_district=$row["branch_district"];
$branch_sector=$row["branch_sector"];
$branch_cell=$row["branch_cell"];
$branch.='<option>'.$branchid.".".$branch_district.".".$branch_sector.".".$branch_cell.'</option>';
     echo "<option>$branch</option>";
   }}
     
    ?>
    
    </select>    
   </div>
   <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" name="save_employee" class="btn btn-lg btn-primary">
Add Employees
                                </button> 
                                        </div>
</form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--models-->
                    <div class="col-md-12"><br></div>          
                <div class="row">
<div class="col-md-3">
    <div class="modal-content">
<div class="modal-header"> <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModaltask">
Tasks </button> <center>Brouse images in a respective order</center>  </div>
 
         <?php 
    $bid="";
     if(isset($_GET['editbranch']))
        {
         $bid=$_GET['editbranch'];
    // echo "wp".$id;
     $sql="SELECT * 
FROM  `pharmacy_branches` WHERE branchid='$bid'";
$branchquery=mysqli_query($con,$sql);
if($branchquery)
{
 while($row=mysqli_fetch_array($branchquery))
   {
     $branch_site_image=$row["branch_site_image"];
$closest_common_known_place=$row["closest_common_known_place"];
$rightclosestplace=$row["rightclosestplace"];
$leftclosestplace=$row["leftclosestplace"];
// echo"<center>
// <img src='../users/logoes/{$pharmacy_logo}' style='width:120px;height:100px;'/></center><br>
// 
// &nbsp;&nbsp;Pharmacy Email<b>:$pharmacy_email</b><br>
//&nbsp;&nbsp;Pharmacy Tel<b>:$pharmacy_service_tel</b><br>
// &nbsp;&nbsp;Pharmacy Identification NO<b>:$pharmacy_authorization_identication</b><br>
//&nbsp;&nbsp; Sign Up  Date<b>: $reg_date</b>
// " 

?> 
 <?php
 echo"
 <center>Branch Location
<img src='branchimages_uploads/{$branch_site_image}' style='width:120px;height:100px;'/></center>";         
echo"<center>Right closest 
<img src='branchimages_uploads/{$rightclosestplace}' style='width:120px;height:100px;'/></center>";        
echo"<center>Left closest
<img src='branchimages_uploads/{$leftclosestplace}' style='width:120px;height:100px;'/></center>"; echo"<center>Famous closest
<img src='branchimages_uploads/{$closest_common_known_place}' style='width:120px;height:100px;'/></center>";                                      
          ?>
        
<!--<div class="form-group has-success">-->
   <form role="form" method="post" action="editimage.php" enctype="multipart/form-data">                                    
 <input type="text" name="id" value="<?php echo $bid?>" hidden="hidden">
  <input type="file" name="picture">
<input type="submit" name="save1" value="Branch img">
            <!--    </div>-->
</form>  
<form role="form" method="post" action="editimage.php" enctype="multipart/form-data">
<input type="text" name="id" value="<?php echo $bid?>" hidden="hidden">     
 <input type="file" name="file_array[]">
<input type="submit" name="save2" value="Saveimage2">
            <!--    </div>-->
</form>  
 <form role="form" method="post" action="editimage.php" enctype="multipart/form-data">                      <input type="text" name="id" value="<?php echo $bid?>" hidden="hidden">      <input type="file" name="file_array[]">
<input type="submit" name="save3" value="Saveimage3">
            <!--    </div>-->
</form>
 <form role="form" method="post" action="editimage.php" enctype="multipart/form-data"> 
    <input type="text" name="id" value="<?php echo $bid?>" hidden="hidden">     
 <input type="file" name="file_array[]">
<input type="submit" name="save4" value="editimage.php">
            <!--    </div>-->
</form> 




                        

                                    </div>
                </div>
                    <div class="col-md-8">
                     
       <div class="modal-content">
<div class="modal-header">
<center><h4 class="modal-title" id="myModalLabel">Edit Branches' Information</h4></center>
</div><div class="modal-body">
   <div class="table-responsive">
                                <table class="table table-hover">
  <?php 
$branchid=$row["branchid"];
$branch_district=$row["branch_district"];
$branch_sector=$row["branch_sector"];
$branch_cell=$row["branch_cell"];
$tel_contact_no=$row["tel_contact_no"];
$province=$row["province"];
$branch_village=$row["branch_village"];
$date_of_closure=$row["date_of_closure"];
$service_start_time=$row["service_start_time"];
$service_end_time=$row["service_end_time"];
$working_day_info=$row["working_day_info"];
     }}}
if(isset($_POST['savebranchupdates']))
 {
 $btelno=$_POST['btelno'];$bprovince=$_POST['bprovince'];$bdistrict=$_POST['bdistrict'];$bsector=$_POST['bsector'];$bcell=$_POST['bcell'];$bvillage=$_POST['bvillage'];$bwork=$_POST['bwork'];$bstarth=$_POST['bstarth'];$bends=$_POST['bends'];
$updatebr="UPDATE pharmacy_branches SET tel_contact_no='$btelno',province='$bprovince',branch_district='$bdistrict',
branch_sector='$bsector',branch_cell='$bcell',branch_village='$bvillage',service_start_time='$bstarth',service_end_time='$bends',working_day_info='$bwork' WHERE branchid ='$branchid'";
$sqlbupd=mysqli_query($con,$updatebr) or die(mysqli_error());
    if($sqlbupd)
    {
   echo"<script>
window.location='home.php';
</script>";
    }
    else
    {
            echo mysqli_error();
        echo"<script>function redirect(){
window.location='home.php';
}</script>";
    
    }
    
}
        if(isset($_POST['saveImagechupdates']))
        {
$branchimage_array_update = $_FILES['file_array']['name'];
$tmp_name_array_update = $_FILES['file_array']['tmp_name'];
$type_array_update = $_FILES['file_array']['type'];
$size_array_update = $_FILES['file_array']['size'];
$error_array_update = $_FILES['file_array']['error'];
    
for($i = 0 ;$i < count($tmp_name_array); $i++){ if(move_uploaded_file($tmp_name_array[$i],"branchimages_uploads/".$branchimage_array[$i])){
    echo $branchimage_array[$i]."is uploaded successfully ";

}}
        
        }

        
            
        
        
        
        
            
        
                                        ?>
<!--
            <label>A Branch working site Image:</label>
    <input type="file" name="file_array[]" class="form-control" placeholder="cell where it is located" required>
    <label>The Closest Common Known place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Right side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Left side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>                         
-->
                                    
<form role="form" method="post" action="?">
<div class="form-group has-success">
<label>Branch Service No </label>    
<input type="text" name="btelno" class="form-control" value="<?php echo $tel_contact_no ?>"><label>Branch Province Location </label>    
<input type="text" name="bprovince" class="form-control" value="<?php echo $province ?>">
<label>Branch District Location </label>    
<input type="text" name="bdistrict" class="form-control" value="<?php echo $branch_district?>">
<label>Branch Sector Location </label>    
<input type="text" name="bsector" class="form-control" value="<?php echo $branch_sector ?>">
<label>Branch Cell Location </label>    
<input type="text" name="bcell" class="form-control" value="<?php echo $branch_cell ?>">
    <label>Branch Village Location </label>    
<input type="text" name="bvillage" class="form-control" value="<?php echo $branch_village ?>"> 
      <label>Branch Working Days </label>    
<input type="text" name="bwork" class="form-control" value="<?php echo $working_day_info ?>"> 
<label>Start service hours </label>    
<input type="text" name="bstarth" class="form-control" value="<?php echo $service_start_time ?>">
    <label>End service hours </label>    
<input type="text" name="bends" class="form-control" value="<?php echo $service_end_time ?>">
     
   </div>
    <div class="modal-footer">

<button type="submit" name="savebranchupdates" class="btn btn-default ">
Save Branch Update
                                </button>
                                        </div>
</form>
<!--   //406186c5b109-->

         
                                </table>                 
                                        
                                       
                                    
                            </div>
                        </div>
                    </div>
                    <!-- End  Hover Rows  -->
                </div>                                     </div>
                                    </div>
                 
        
            
    </div>
<!--    this is the model that shows the user profil-->
            <?php
            if(isset($_POST['edpersonal']))
{
    echo "wow";
$edfname=$_POST['edfname'];
$edlname=$_POST['edlname'];
$edtel=$_POST['edtel'];
$edemail=$_POST['edemail'];
$eduser=$_POST['eduser']; 
$pers_updateqry = "UPDATE `users` SET firstname = '$edfname', lastname='$edlname' ,telephone = '$edtel'   WHERE userid = $userid";
$chekpersonalup = mysqli_query($con,$pers_updateqry) or die(mysql_error()); 
if($chekpersonalup)
{
    echo "<center>Personal Successfully changed</center>";
     echo"<script>function redirect(){
window.location='?';
}setInterval(redirect,1000);</script>";
}           
}

            ?>
            
         <div class="col-md-12">
        <div class="panel-body">
<div class="modal fade" id="myprofil" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
<div class="modal-dialog"><div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<center><h4 class="modal-title" id="myModalLabel">You have been Registered since<?php echo $reg_date; ?></h4></center>
</div>
<div class="modal-body">
<form role="form" method="post" action="?">
<div class="form-group has-success">
    <label>Your first name</label>
<input type="text" name="edfname" class="form-control" value="<?php echo $firstname ?>">
    <label>Your Last name</label>
<input type="text" name="edlname" class="form-control" value="<?php echo $lastname ?>">  
    <label>Your Telephone Address</label>
<input type="text" name="edtel" class="form-control" value="<?php echo $telephone ?>"> <label>Your Email Address</label>
<input type="text" name="edemail" class="form-control" value="<?php echo $user_email ?>"> 
    <label>Your Username</label>
<input type="text" name="eduser" class="form-control" value="<?php echo $username ?>" disabled> 

</div>
<div class="modal-footer">
    <center>
        
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
<input type="submit" name="edpersonal"class="btn btn-default" value="Save Updates"><input type="submit" name="lv"class="btn btn-danger" value="Leave system">
 <button class="btn btn-danger " data-toggle="modal" data-target="#changemyPorfile" name="usernameupdate">Change Creditentials   </button>    
    </center>
                                            
                                        </div>
 
   

 </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <!-- End returns model  -->
                        <!--          end  inserted row mine-->
             
    </div></div></div>
<!--    to generate the current location longitude and latude-->
                               <script>
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.value = position.coords.latitude + 
    "," + position.coords.longitude;
}
</script>
      
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include_once('../footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
