<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Pharmacie Locator</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME ICONS  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
     
</head>
<body>
    <?php require('../dbcon/dbcon.php');
include("auth.php");?>
    <?php
    $dates="";
    $user=$_SESSION['username'];
    $userid="";
    $pharmacy_name="";$pharmacy_service_tel="";
    $pharmacy_logo="";$pharmacy_authorization_identication="";
    $pharmacy_link="";$reg_date="";
    $pharmacy_email="";$pharmacy_id="";
 $userqry="SELECT * FROM branch_workers where username='$user'";                      
$out=mysqli_query($con,$userqry) or die(mysqli_error());
  $line=mysqli_fetch_array($out);
  $userid=$line['worker_id'];                                                
  // getting pharmacy data                             
$query = "SELECT * FROM pharmacies where pharmacy_owner_id='$userid'";
$result = mysqli_query($con,$query) or die(mysqli_error()); 
$rows=mysqli_num_rows($result);
$rec=mysqli_fetch_array($result);
  $pharmacy_id=$rec['pharmacy_id'];  
 $pharmacy_name=$rec['pharmacy_name'];
 $pharmacy_logo=$rec['pharmacy_logo'];
 $pharmacy_link=$rec['pharmacy_link'];
 $pharmacy_email=$rec['pharmacy_email'];
 $pharmacy_service_tel=$rec['pharmacy_service_tel'];
 $pharmacy_authorization_identication=$rec['pharmacy_authorization_identication'];
 $reg_date=$rec['reg_date'];
  $message="";  
 if (isset($_REQUEST['save_drug'])){
        // removes backslashes
	$drug_name = stripslashes($_REQUEST['drug_name']);
        //escapes special characters in a string
	$drug_name = mysqli_real_escape_string($con,$drug_name); 
	$drug_price = stripslashes($_REQUEST['drug_price']);
	$drug_price = mysqli_real_escape_string($con,$drug_price);
	$exp_date = stripslashes($_REQUEST['exp_date']);
	$exp_date = mysqli_real_escape_string($con,$exp_date);
    $price_description = stripslashes($_REQUEST['desc']);
	$price_description = mysqli_real_escape_string($con,$price_description);
    $quantity = stripslashes($_REQUEST['quantity']);
	$quantity = mysqli_real_escape_string($con,$quantity);
    $dates= date("Y-m-d");
$query = "INSERT into `pharmacy_drugs` (drug_names,pricing_description,pharmacy_id,recording_date,exp_date,quantity)
VALUES ('$drug_name','$price_description','$pharmacy_id','$dates','$exp_date','$quantity')";
        $resultsave = mysqli_query($con,$query);
        if($resultsave){
  $query = "INSERT into `price_records` (drug_names,pricing_description,pharmacy_id,recording_date,exp_date,quantity)
VALUES ('$drug_name','$price_description','$pharmacy_id','$dates','$exp_date','$quantity')";          
            
            $message =" Drug recorded correctly!";
            echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";
            
        }
    else
    {
    $message="drug not recorded!";
    }
    }
if(isset($_POST['savebill']))
    {
 $buyernames=$_POST['bnames'];
$btel=$_POST['btel'];
$insurranceid=$_POST['insurranceid'];
$insurrancename=$_POST['insurrance_name'];
       
$createbill="INSERT INTO branch_bills (branch_worker_id,buyer_tel_no,	healthinsurrance,healthinsurranceid,buyer) VALUES('$userid','$btel','$insurrancename','$insurranceid','$buyernames')";
    
    $billsql=mysqli_query($con,$createbill)or die(mysqli_error());
    if($billsql)
    {
        echo"data recorded successfuly";
        echo"<script>function redirect(){
window.location='branch.php';
}setInterval(redirect,1000);</script>";
    }
    else
    {
    echo mysqli_error();
    }
    }
    
    
     ?>
<!--    models begin-->
 <!--user name update model begin                    -->         
<div class="modal fade" id="changemyPorfile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="changemyPorfile"><center>Navigation Model</center></h4></div><div class="modal-body">

     <button class="btn btn-default" data-toggle="modal" data-target="#newemployee">
                       New Bill</button>
    
                                        </div>
                                    </div>
                                </div>
                            </div> 
<!--user name update model end                    -->
<!-- tasks model begin                   -->          
 <div class="modal fade" id="myModaltask" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModaltask"><center>PHARMACY SALES TASK MODEL</center></h4></div><div class="modal-body">

     <button class="btn btn-default" data-toggle="modal" data-target="#newemployee">
                      new bill</button>
   
    <button class="btn btn-info " data-toggle="modal" data-target="#myModals">
                            Allocations   </button>
    
<button class="btn btn-info " data-toggle="modal" data-target="#myModalbranch">
                       My  Branches </button>

<button class="btn btn-info " data-toggle="modal" data-target="#myModaladd">
                            Add Drug </button>
 <button class="btn btn-info" data-toggle="modal" data-target="#myModalinsurrance">
                           Insurrance </button>
 <button class="btn btn-default" data-toggle="modal" data-target="#myModaltask">
 Tasks </button>
    <button class="btn btn-default" data-toggle="modal" data-target="#mystore">
                     Drug store 
                            </button>  
        
   <button class="btn btn-default" data-toggle="modal" data-target="#mypharmacyprofil">
                            Profil </button> 
                                        </div>
                                    </div>
                                </div>
                            </div>                    
<!--tasks model end            -->
<!--            full profil model begin-->
            
            <div class="modal fade" id="mypharmacyprofil" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="mypharmacyprofil"><?php echo "<b><center>".$pharmacy_name."</center></b>";?></h4></div><div class="modal-body">
<form role="form" method="post">
<div class="form-group has-success">
   <?php 
   //getting the user id
  
 echo"<center>
 <img src='../users/logoes/{$pharmacy_logo}' style='width:120px;height:100px;'/></center><br>
 
 &nbsp;&nbsp;Pharmacy Email<b>:$pharmacy_email</b><br>
&nbsp;&nbsp;Pharmacy Tel<b>:$pharmacy_service_tel</b><br>
 &nbsp;&nbsp;Pharmacy Identification NO<b>:$pharmacy_authorization_identication</b><br>
&nbsp;&nbsp; Sign Up  Date<b>: $reg_date</b>
 " 
?> 
   
    
    <br>
    
    </div>

                                   
                                        <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<!--                                            <button type="Submit" class="btn btn-primary">Save Company</button>-->
                                        <?php echo"<a href='index.php?edit={$userid}'class='btn btn-default'><i class='fa fa-edit'></i></a>"?>
                                            
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--            full profile model end-->
<!--            store status model begin-->
    <div class="modal fade" id="mystore" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel"><center>Drug  Store Info </center></h4>
                                        </div>
 <div class="modal-body">
<div class="modal-body">
<div class="table-responsive">
<table class="table table-hover">
                                    <thead>
                                                     <?php  
$pharmacydrugs="SELECT * 
FROM  `pharmacy_drugs` WHERE pharmacy_id='$pharmacy_id'";
$pharmacydrugsqry=mysqli_query($con,$pharmacydrugs);
$pharmacydrugcount=mysqli_num_rows($pharmacydrugsqry);    
if($pharmacydrugcount > 0)
{?>
  <?php                                                  
  echo'<tr><th>Drug</th><th>Pricing</th><th>Experation info</th><th>Quantity</th><th>Option</th>
</tr>
                                             
';?>
  </thead>
                                    <tbody> 
<form role="form" method="post" >                                        
     <?php
while($drow=mysqli_fetch_array($pharmacydrugsqry))
   {
$drug_id=$drow["drug_id"];
$drug_names=$drow["drug_names"];
$pricing_description=$drow["pricing_description"];
$recording_date=$drow["recording_date"];
$exp_date=$drow["exp_date"];
$info_status=$drow["info_status"];
$quantity=$drow["quantity"];
echo" <tr>
<td>$drug_names</td>
<td>$pricing_description</td>
<td>$exp_date</td><td>$quantity</td>
<td>
<a href='branch_info.php?viewmore={$drow["drug_id"]}'class='btn btn-info btn-sm' title='view more info'><i class='fa fa-info'>&nbsp;</i></a>|<a href='branch_info.php?update={$drow["drug_id"]}'class='btn btn-info btn-sm' title='Employee info'><i class='fa fa-edit'>&nbsp;&nbsp;</i></a>&nbsp;&nbsp;||&nbsp;<a href='branch_info.php?deletedrug={$drow["drug_id"]}'class='btn btn-danger btn-sm' title='Employee info'><i class='fa fa-trash'>&nbsp;&nbsp;</i></a>
</td>
</tr>";    
     
   }}
    else
    {
        echo"<center> data avaible </center>";
    }
     
    ?>
<div class="form-group has-success">

     
   </div>
</form>
   
          </tbody>
                                </table>                 
                                        
                                       
                                    
                            </div></div>
                                        </div>
                                        <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button class="fa fa-book btn btn-info" data-toggle="modal" data-target="#myModaladd" title="Report">Report
                             </button>
                                        </div>
                                    </div>
                                </div>
                            </div>        
<!--            store status infos model end-->
<!--            model for publishing insurrance company begin-->
                    <?php
                      if(isset($_POST['saveins']))
    {
    $insurrance=$_POST['insurrance'];
   $dates=date("Y:m:d");    
    $dispacher=array();
    $insurrance=explode('.',$insurrance);
    $neededid=$insurrance[0]; 
                          echo $neededid;
    $insinsert="INSERT INTO insurrence_companies_pharmacies (insurrence_company_id,pharmacy_id,date_recorded) VALUES ('$neededid',' $pharmacy_id','$dates')";    
     $inresult = mysqli_query($con,$insinsert)or die(mysqli_error());    
    if($inresult)
    { 
echo "<center>querry ok</center>";
    echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";                   
  }
                          else{
                              $x=mysql_error();
                            echo "<center>{$x}</center>";
    echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";   
                          }
                      }
                          
                    ?>
                    
                    
   <div class="modal fade" id="myModalinsurrance" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalinsurrance">Record Insurrence companies in partinership</h4></div><div class="modal-body">
<form role="form" method="post" action="#">
<div class="form-group has-success">
    
    
    

     <?php  
$insurrance="";
$sqlin="SELECT * FROM  `insurrence_companies`";
$insquery=mysqli_query($con,$sqlin);
if($insquery)
{
while($insrow=mysqli_fetch_array($insquery))
   {
$insurrence_id=$insrow["insurrence_id"];
$company_name=$insrow["company_name"];
$insurrance.='<option>'.$insurrence_id.".".$company_name.'</option>';
     
   }}
        ?>
     
     
<!--    $drug_name=$_POST['drug_name'];-->
    
     
     
 <label>Select Insurrence Company</label>
    <select type="text" name="insurrance" class="form-control" required>
    <option></option>
        <option><?php echo $insurrance; ?></option>
    
    </select>      
    
    <br>
        </div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="Submit" class="btn btn-primary" name="saveins">Save Company</button>
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>         
<!--    publish insurrance companies end        -->
<!--            model to add new drgs begin-->
 <div class="modal fade" id="myModaladd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;"><div class="modal-dialog">
<div class="modal-content"><div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModaladd"><center>Record New Drugs</center></h4></div><div class="modal-body">
<form role="form" method="post">
    <?php echo $userid."dgdgghdgh";?>
<div class="form-group has-success">
    <?php echo"<font color='red'><center><b>".$message."</b></center></font>";?>
 <label>Drug Name:</label>
    <input type="text" name="drug_name" class="form-control" placeholder="bill_id of the sold items " required>       
   
    <label>Drug price:</label>
    <input type="text" name="drug_price" class="form-control" placeholder="price drug" required>
    <label>Pricing description:</label>
       <select class="form-control" name="desc" required>
    <option>per unity</option>
    <option>combined</option>
    </select>
    <label>Experation Date:</label>
    <input type="date" name="exp_date" class="form-control" placeholder="expiration date " required>  
    <label>Quantity:</label>
    <input type="number" name="quantity" class="form-control" placeholder="quantity" required>     
    </div>
               
                                        <div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit"  name="save_drug" class="btn btn-primary">Save changes</button>
                                        </div>
     </form>
                                        </div>
                                    </div>
                                </div>
                            </div>           
<!--    add drugs into the data base        -->
<!--            codes for creating a new branch-->
            <!--                           saving branch into the database -->
<?php
$m="";                                                      
if(isset($_POST['savebranch']))
{
$lt=""; $lg=""; error_reporting(0); 
$latlong=explode(',',$_POST['latlong']);
$lt=$latlong[0]; $lg=$latlong[1];
echo 'lati'.$lt.'<br />';
echo 'long'.$lg.'<br />';
$pharmacycounter= "SELECT * FROM `pharmacy_branches` WHERE pharmacyid = $pharmacy_id";
$sqlpharmacies=mysqli_query($con,$pharmacycounter)or die(mysqli_error());
$counter=mysqli_num_rows($sqlpharmacies);    
$dates=date('Y-m-d');    
$telcontact=$_POST['telcontact'];
$province=$_POST['province'];    
$district=$_POST['district'];
$sector=$_POST['sector'];
$cell=$_POST['cell'];
$village=$_POST['village'];
$servicestarttime=$_POST['starttime'];
$serviceendtime=$_POST['endtime'];
$daysinfo=$_POST['daysinfo'];
 $a=$province[0].$province[1];
 $b=$district[0].$district[1];
 $c=$sector[0].$sector[1];
$d=$village[0].$village[1];
$branchid=$a.$b.$c.$d._.$counter._.$pharmacy_id;
    $m=$branchid;    
$branchimage_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
    
for($i = 0 ;$i < count($tmp_name_array); $i++){ if(move_uploaded_file($tmp_name_array[$i],"branchimages_uploads/".$branchimage_array[$i])){
    echo $branchimage_array[$i]."is uploaded successfully ";

}
                                            else{
echo "Data not saved and uploading".$branchimage_array[$i]."failed<br>";
                                            }
                                           }    
  $binserts="INSERT  into `pharmacy_branches`
(branchid,pharmacyid,tel_contact_no,province,branch_district,branch_sector,branch_cell,branch_village,latitude,longitude,establishement_date,branch_site_image,closest_common_known_place,rightclosestplace,leftclosestplace,service_start_time,service_end_time,working_day_info) 
VALUES
('$branchid','$pharmacy_id','$telcontact','$province','$district','$sector','$cell','$village','$lt','$lg','$dates','$branchimage_array[0]','$branchimage_array[1]','$branchimage_array[2]','$branchimage_array[3]','$servicestarttime','$serviceendtime','$daysinfo')";
    $bresult = mysqli_query($con,$binserts)or die(mysqli_error());    
    if($bresult)
    {
        echo "<i class='fa fa-info' style='color:red;'>Branch is created</i>";
        echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,1000);</script>";
    }
    else
        $m="error";                                   
}
                                
                               ?>
                          <?php echo"<font color='red'><center><b>".$m."</b></center></font>";?>  
            
<!--            new branch model-->
            <div class="modal fade" id="myModalbranch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myModalLabel">Create a new branch </h4>
                                        </div>
                                        <div class="modal-body">
<form role="form" method="post" enctype="multipart/form-data">
<div class="form-group has-success">
   
 <label>Branch Service tel_contact:</label>
    <input type="text" name="telcontact" class="form-control" placeholder="service telephone number" required>       
   
    <label>Province:</label>
    <input type="text" name="province" class="form-control" placeholder="district where is located" required>
    <label>Branch District name:</label>
    <input type="text" name="district" class="form-control" placeholder="district where is located" required>
    <label>Branch sector name:</label>
    <input type="text" name="sector" class="form-control" placeholder="sector where it is located" required>
    <label>Branch cell:</label>
    <input type="text" name="cell"class="form-control" placeholder="cell where it is located" required>
    <label>Branch village:</label>
    <input type="text" name="village"class="form-control" placeholder="cell where it is located" required>
     <label>A Branch working site Image:</label>
    <input type="file" name="file_array[]" class="form-control" placeholder="cell where it is located" required>
    <label>The Closest Common Known place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Right side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Left side neighboring house or place Image:</label>
    <input type="file" name="file_array[]"class="form-control" placeholder="cell where it is located" required>
    <label>Service  Time</label>
 <label>Start</label>   
 <input type="time" name="starttime"class="form-control" placeholder="cell where it is located" required>
 <label>End Time</label>
    <input type="time" name="endtime"class="form-control" placeholder="cell where it is located" required> 
    <label>Working days</label>
    <input type="text" name="daysinfo"class="form-control" placeholder="eg: monday up friday" required>
    <label>Geographical coordinates on google map(latitude and longitude) </label>       
     <input type="text" name="latlong" id="demo" value="" class="form-control">                
    </div>

                                    
                                        <div class="modal-footer">
 <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" name="savebranch" class="btn btn-primary">Save Branch</button>
                                            
                                        </div>
                                                                </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--            new branch model-->
<!--            drug assignment model-->
              <div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h4 class="modal-title" id="myModalLabel">Assign Drugs to Branches</h4>
                                        </div>
                                        <div class="modal-body">
                                                     <form role="form">
<div class="form-group has-success">
    <label>Drug ID</label>
    <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>
    
<label>Quantity</label>
    <input type="text" name="search_place_field"class="form-control" placeholder="number of items"> 
    <label>Destination Branch</label>
   <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>   
    <br>
    
    </div>

                                    
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           <button type="submit" name="assign" class="btn btn-lg btn-primary ">
Assign drugs
                                </button>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--            drug assignment-->
<!--            php codes for add employee-->
        
<!--            add employee model-->
             <div class="modal fade" id="newemployee" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="myModalLabel">Create New bill</h4>
</div><div class="modal-body">
<form role="form" action="branch.php" method="post">
<div class="form-group has-success">
<label>Buyer Names:</label>
    <input type="text" name="bnames"class="form-control" placeholder="ex:john"> 
    <label>Buyer Tel no:</label>
    <input type="text" name="btel"class="form-control" placeholder="tel no of the buyer"> 
    <label>Health insurrance Name:</label>
    <input type="text" name="insurrance_name"class="form-control" placeholder="tel no of the buyer"> 
    <label>Health insurrance ID:</label>
    <input type="text" name="insurranceid"class="form-control" placeholder="tel no of the buyer">
   
 
    </div>
<? echo $userid;?>
                                    
                                        <div class="modal-footer">
   <center> <button type="submit" name="savebill" class="btn btn-lg btn-default ">
Create
                                </button></center>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--models-->    
    
    
    
    
    <!--    models end-->
    
    
    
     
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="assets/img/logo.png" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                <span class="glyphicon glyphicon-user" style="font-size: 25px;"><?php echo $_SESSION['username']; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-settings">
                                <div class="media">
                                    <div class="media-body">
                                        <h4 class="media-heading">User:<?php echo"<b>".ucfirst($_SESSION['username'])."</b>"; ?> </h4>
                                        <h5>Pharmacy Branch</h5>

                                    </div>
                                </div>
                                <hr />
                                
                                <a href="#" class="btn btn-info btn-sm"><k data-toggle="modal" data-target="#myModalbranch">
                          Full Profil 
                            </k></a>&nbsp; <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>

                            </div>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    
    <!-- MENU SECTION END--> 
<div class="content-wrapper">
        <div class="container">
            <div class="row">
            </div>
            <div class="row">
<div class="col-md-12">
 
                </div>
            </div>
                <div class="row">
<div class="col-md-4">
<div class="modal-content"><div class="modal-header">
   <K class="btn btn-info" data-toggle="modal" data-target="#myModaltask">
Tasks </K> 
    
<h4 class="modal-title" id="myModalinsurrance"><center>Current sales info</center></h4></div><div class="modal-body">
<div class="table-responsive">
<table class="table table-hover">
                                    <thead>
                                                     <?php  
$pharmacydrugs="SELECT * 
FROM  `sale_temp` WHERE worker_id='$pharmacy_id'";
$pharmacydrugsqry=mysqli_query($con,$pharmacydrugs);
$pharmacydrugcount=mysqli_num_rows($pharmacydrugsqry);    
if($pharmacydrugcount > 0)
{?>
  <?php                                                  
  echo'<tr><th>Drug</th><th>Pricing</th><th>Experation info</th><th>Quantity</th><th>Option</th>
</tr>
                                             
';?>
  </thead>
                                    <tbody> 
<form role="form" method="post" >                                        
     <?php
while($drow=mysqli_fetch_array($pharmacydrugsqry))
   {
$drug_id=$drow["drug_id"];
$drug_names=$drow["drug_names"];
$pricing_description=$drow["pricing_description"];
$recording_date=$drow["recording_date"];
$exp_date=$drow["exp_date"];
$info_status=$drow["info_status"];
$quantity=$drow["quantity"];
echo" <tr>
<td>$drug_names</td>
<td>$pricing_description</td>
<td>$exp_date</td><td>$quantity</td>
<td>
<a href='branch_info.php?viewmore={$drow["drug_id"]}'class='btn btn-info btn-sm' title='view more info'><i class='fa fa-info'>&nbsp;</i></a>|<a href='branch_info.php?update={$drow["drug_id"]}'class='btn btn-info btn-sm' title='Employee info'><i class='fa fa-edit'>&nbsp;&nbsp;</i></a>&nbsp;&nbsp;||&nbsp;<a href='branch_info.php?deletedrug={$drow["drug_id"]}'class='btn btn-danger btn-sm' title='Employee info'><i class='fa fa-trash'>&nbsp;&nbsp;</i></a>
</td>
</tr>";    
     
   }}
    else
    {
        echo"<center> data avaible </center>";
        echo $userid;
    }
     
    ?>
<div class="form-group has-success">

     
   </div>
</form>
   
          </tbody>
                                </table>                 
                                        
                                       
                                    
                            </div>
                                        </div>
                                    </div>                      

                </div>
                    <div class="col-md-6">
                         <div class="modal-content"><div class="modal-header">
<h4 class="modal-title" id="myModalinsurrance">

    <?php $latestbill="SELECT * FROM branch_bills WHERE branch_worker_id='$userid' ORDER BY branch_bill_id DESC";
    $latestbillqry=mysqli_query($con,$latestbill);
    $counterlastest=mysqli_num_rows($latestbillqry);
    if($counterlastest !=0)
    {
    $fetchbil=mysqli_fetch_array($latestbillqry);
        $branch_bill_id=$fetchbil['branch_bill_id'];
        $buyer=ucfirst($fetchbil['buyer']);
        echo"<center><K style='color:#360404'>current bill is:".$branch_bill_id."&nbsp;&nbsp; for :"."$buyer</center></K>"; 
        
    }
    
    ?> 
    
                             </h4>
                                                         
                             </div><div class="modal-body">
                            <form role="form">
<div class="form-group has-success">
    <label>Select Drug</label>
    <select name="search_place_field"class="form-control">
        
        <option>#456</option>
    </select>
      
<label>Check price</label>
    <input type="text" name="search_place_field"class="form-control" placeholder="number of items"> 
<label>Quantity</label>
  <input type="text" name="search_place_field"class="form-control" placeholder="number of items">
     <label>Attach a bill</label>
    <select name="search_place_field"class="form-control">
        <option>bill#456</option>
        <option>bill#456</option><option>bill#456</option>
    </select>
    
    <br>
    
    </div>

                                    
                                        <div class="modal-footer">
<center><button type="submit" name="assign" class="btn btn-lg btn-default ">
Record sale
                                </button></center>
                                        </div>
                                                         </form>
                                        </div>
                                    </div>
                        </div>
                    <div class="col-md-2">
                    
                    <div class="modal-content"><div class="modal-header">
<h4 class="modal-title" id="myModalinsurrance">
    quick infos

    <?php //$latestbill="SELECT * FROM branch_bills WHERE branch_worker_id='$userid' ORDER BY branch_bill_id DESC";
   // $latestbillqry=mysqli_query($con,$latestbill);
    //$counterlastest=mysqli_num_rows($latestbillqry);
   // if($counterlastest !=0)
    //{
   // $fetchbil=mysqli_fetch_array($latestbillqry);
    //    $branch_bill_id=$fetchbil['branch_bill_id'];
    //    $buyer=ucfirst($fetchbil['buyer']);
     //   echo"<center><K style='color:#360404'>current bill is:".$branch_bill_id."&nbsp;&nbsp; for :"."$buyer</center></K>"; 
        
   // }
    
    ?> 
    
                             </h4>
                             
                             
                             </div><div class="modal-body">
                          <form>
                             
    <input type="text" name="search_place_field"class="form-control" placeholder="input drug id ">  
                              <button type="submit" name="drugid" value="drug id" class="btn btn-info fa fa-search btn lg"></button>
                                 <label></label>
                             </form>
                                        </div>
                                    </div>
                    </div>
                    
            </div> 
            </div>
            
    </div>
               <!--          end  inserted row mine-->
         
    </div>

      
    <!-- CONTENT-WRAPPER SECTION END-->
   <center> <?php include_once('../footer.php');?></center>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
