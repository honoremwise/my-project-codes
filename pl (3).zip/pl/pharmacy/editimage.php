<?php
if(isset($_POST['save1']))
{
    $id=$_POST['id'];
   
  $picture =$_FILES['picture']['name'];

    $photo_size =$_FILES['picture']['size'];
$extensions =array('.png','.gif','.jpg','.jpeg','.JPEG','.JPG','.PNG');  
$extension =strrchr($_FILES['picture']['name'],'.');
    $pictures=$_FILES['picture']['tmp_name'];
        
if(!in_array($extension,$extensions))
{ 
     echo $id;
    echo $picture;
    $messager="<i class='fa fa-info'>You must make use of file in the following forma type png, gif, jpg,jpeg</i>";
    echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,6000);</script>";  
    
}  
 else if($photo_size>=50000000)
{
   echo $id;
     $messager="<i class='fa fa-info'>The file size exceeds the allowed size, please upload a file not bigger than 5MB.</i>";
echo"<script>function redirect(){
window.location='home.php';
}setInterval(redirect,6000);</script>";      
}
 else if(move_uploaded_file($pictures,'branchimages_uploads/'.$_FILES['picture']['name']))
{
    
 $imgupdate="UPDATE pharmacy_branches SET branch_site_image = '$picture'";
     $result = mysql_query($imgupdate);
     if($result)
     {
         echo "Branch IMage Updated successfuly";
     }
     
    
}}
?>